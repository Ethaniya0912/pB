// =============================================================================
// PerceptionProbeWindow.cs  |  pB-4 AI 인지 테스트 프로브 v2.1
//
// [4단계 재귀 비판 결과 수정 목록]
//   B4:  패닉 전파 → [인지경유] → [BT강제/효과직접]로 레이블 교정
//        HandlePanicChain() 은 FleeSwarmAction.OnStart() private → 외부 호출 구조상 불가
//   B7:  Gizmo 레이블 "0.3×50m" 삭제 → SoundPerception baseRadius=15f 명시
//   B8:  DrawPersistentGizmos Queue → List + reverse-remove 교체 (GC 절감)
//   B10: DrawRealtimeStatus Repaint() → EditorApplication.update + 0.1s 타이머
//   E3:  다수 AI 선택 지원 — Selection.objects 순회
//   E4:  FireForceCombat() Player 캐시 추가
//   E5:  fear 수정에 Undo.RecordObject() 적용
//
// 설계 원칙:
//   ① 스크립트 1개 — EditorWindow + SceneView Gizmo 통합
//   ② 씬 설정 0 — SceneView.duringSceneGui 자동 구독
//   ③ 7개 프로브 — [인지경유] vs [BT강제] 명확 분류
//   ④ 도형+텍스트 항상 병행
//
// 메뉴: pB-4 → Perception Probe (Ctrl+Shift+P)
// =============================================================================
#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;
using TDA.Character.AI;
using TDA.PB4.AI.Mob;
using TDA.PB4.AI.Perception;
using Unity.Behavior;

namespace TDA.PB4.Editor
{
    public class PerceptionProbeWindow : EditorWindow
    {
        // =====================================================================
        // 프로브 정의
        // [B4 Fix] 패닉 전파 → isPerception=false (BT강제) 로 교정
        //          실제로 HandlePanicChain()을 경유하지 않음 → 효과직접 분류
        // =====================================================================

        private struct ProbeGizmo
        {
            public Vector3 position;
            public float radius;
            public Color color;
            public string label;
            public float expireTime;
        }

        private static readonly (string icon, string name, string key, bool isPerception, string tooltip)[] PROBES =
        {
            ("🔊", "발자국 소리",    "Alt+1", true,
             "[인지경유] SoundEventEmitter.OnSoundEmitted → SoundPerception.HandleSoundEmitted 파이프라인 통과"),
            ("💥", "전투 소음",     "Alt+2", true,
             "[인지경유] Combat 볼륨 0.8. SoundPerception 청각 범위+벽 감쇠 포함"),
            ("😱", "공포 증폭",     "Alt+3", false,
             "[BT강제] brain.fear += deltaAmount. UpdateDecision 강제 호출로 Flee 분기 테스트"),
            ("🧊", "공포+각성 리셋", "Alt+4", false,
             "[BT강제] fear=0 + Awareness=Unaware + LastHeard/Seen 초기화. 테스트 상태 복원"),
            ("💭", "메모리 주입",    "Alt+5", false,
             "[BT강제] LastSeenPosition BB 직접 기록. StalkAction 기억 수색 테스트"),
            ("🌐", "패닉 전파",     "Alt+6", false,   // [B4 Fix] false로 교정
             "[BT강제/효과직접] brain.fear 직접 수정. HandlePanicChain() 경유 불가 (FleeSwarmAction private)"),
            ("🎯", "강제 전투 진입", "Alt+7", false,
             "[BT강제] ForceSetAwareness(Combat) + BB 직접 갱신. Attack 3단계 플로우 테스트"),
        };

        // =====================================================================
        // 상태
        // =====================================================================

        private int _selectedProbe = 0;
        private float _fearDelta = 0.3f;
        private Vector3 _mouseWorldPos;
        private bool _mouseHitValid;
        private Vector2 _logScroll;
        private readonly List<string> _eventLog = new();
        private const int MAX_LOG = 5;

        // [B8 Fix] Queue → List (매 프레임 new Queue 생성 제거)
        private readonly List<ProbeGizmo> _gizmoList = new();
        private const float GIZMO_DURATION = 2.5f;

        // [E4 Fix] Player 캐시
        private GameObject _cachedPlayer;

        // [B10 Fix] Repaint 타이머 (0.1s 간격)
        private double _lastRepaintTime;
        private const double REPAINT_INTERVAL = 0.1;

        // =====================================================================
        // 메뉴
        // =====================================================================

        [MenuItem("pB-4/Perception Probe %#p", false, 200)]
        public static void Open() => GetWindow<PerceptionProbeWindow>("🔬 Perception Probe");

        // =====================================================================
        // 생명주기
        // =====================================================================

        private void OnEnable()
        {
            SceneView.duringSceneGui += OnSceneGUI;
            titleContent = new GUIContent("🔬 Perception Probe");

            // [B10 Fix] EditorApplication.update 타이머 등록
            EditorApplication.update += OnEditorUpdate;
        }

        private void OnDisable()
        {
            SceneView.duringSceneGui -= OnSceneGUI;
            EditorApplication.update -= OnEditorUpdate;
        }

        // [B10 Fix] 0.1s 간격으로만 Repaint
        private void OnEditorUpdate()
        {
            double now = EditorApplication.timeSinceStartup;
            if (now - _lastRepaintTime >= REPAINT_INTERVAL)
            {
                _lastRepaintTime = now;
                Repaint();
            }
        }

        // =====================================================================
        // EditorWindow UI
        // =====================================================================

        private void OnGUI()
        {
            DrawTargetAI();
            EditorGUILayout.Space(6);
            DrawProbeButtons();
            if (_selectedProbe == 2)  // 공포 증폭만 슬라이더
            {
                EditorGUILayout.Space(4);
                DrawFearSlider();
            }
            EditorGUILayout.Space(6);
            DrawRealtimeStatus();
            EditorGUILayout.Space(6);
            DrawEventLog();
        }

        // ── 대상 AI ──
        private void DrawTargetAI()
        {
            EditorGUILayout.LabelField("대상 AI", EditorStyles.boldLabel);

            // [E3 Fix] 다수 AI 선택 지원
            var targets = GetTargetAIs();
            if (targets.Count == 0)
                EditorGUILayout.HelpBox("Hierarchy에서 AICharacterManager 오브젝트를 선택하세요.", MessageType.Info);
            else if (targets.Count == 1)
                EditorGUILayout.LabelField($"  ▶  {targets[0].name}", EditorStyles.helpBox);
            else
                EditorGUILayout.LabelField($"  ▶  {targets.Count}개 선택됨 ({targets[0].name} 외)", EditorStyles.helpBox);
        }

        // ── 프로브 버튼 ──
        private void DrawProbeButtons()
        {
            EditorGUILayout.LabelField("프로브 (Scene View 마우스 위치에 발동)", EditorStyles.boldLabel);
            for (int i = 0; i < PROBES.Length; i++)
            {
                var (icon, name, key, isPerception, tip) = PROBES[i];
                bool selected = _selectedProbe == i;

                Color bg = isPerception
                    ? (selected ? new Color(0.20f, 0.50f, 0.90f) : new Color(0.15f, 0.35f, 0.65f))
                    : (selected ? new Color(0.80f, 0.20f, 0.20f) : new Color(0.55f, 0.15f, 0.15f));

                var style = new GUIStyle(GUI.skin.button)
                {
                    fontStyle = selected ? FontStyle.Bold : FontStyle.Normal,
                    alignment = TextAnchor.MiddleLeft,
                    fixedHeight = 24,
                };

                Color prev = GUI.backgroundColor;
                GUI.backgroundColor = bg;
                string label = $"  {icon} {name}   {key}   {(isPerception ? "[인지경유]" : "[BT강제]")}";
                if (GUILayout.Button(new GUIContent(label, tip), style))
                {
                    _selectedProbe = i;
                    if (_mouseHitValid)
                        FireProbe(i, _mouseWorldPos);
                }
                GUI.backgroundColor = prev;
            }
        }

        private void DrawFearSlider()
        {
            EditorGUILayout.BeginHorizontal();
            EditorGUILayout.LabelField("공포 증폭량", GUILayout.Width(80));
            _fearDelta = EditorGUILayout.Slider(_fearDelta, 0f, 1f);
            EditorGUILayout.EndHorizontal();
        }

        // ── [B10 Fix] 실시간 상태 — Repaint는 EditorUpdate 타이머에서 ──
        private void DrawRealtimeStatus()
        {
            var targets = GetTargetAIs();
            if (targets.Count == 0) return;

            var ai = targets[0];   // 다수 선택 시 첫 번째만 상태 표시
            EditorGUILayout.LabelField($"실시간 상태 — {ai.name}", EditorStyles.boldLabel);

            var brain = ai.GetComponent<MobAIBrain>();
            var perception = ai.GetComponent<AIPerceptionSystem>();
            var btAgent = ai.GetComponent<BehaviorGraphAgent>();

            if (perception != null)
                EditorGUILayout.LabelField($"  AwarenessState : {perception.CurrentAwareness}");
            if (btAgent?.BlackboardReference != null)
            {
                btAgent.BlackboardReference.GetVariable("UtilityWinner", out BlackboardVariable<string> wv);
                EditorGUILayout.LabelField($"  UtilityWinner  : {wv?.Value ?? "---"}");
            }
            if (brain != null)
                EditorGUILayout.LabelField($"  Fear           : {brain.fear:F3}");
            // Repaint()는 여기서 호출하지 않음 — OnEditorUpdate 타이머가 담당
        }

        // ── 이벤트 로그 ──
        private void DrawEventLog()
        {
            EditorGUILayout.LabelField($"이벤트 로그 (최근 {MAX_LOG}개)", EditorStyles.boldLabel);
            _logScroll = EditorGUILayout.BeginScrollView(_logScroll, GUILayout.Height(88));
            foreach (var log in _eventLog)
                EditorGUILayout.LabelField(log, EditorStyles.miniLabel);
            EditorGUILayout.EndScrollView();
        }

        // =====================================================================
        // Scene View Gizmo + 단축키
        // =====================================================================

        private void OnSceneGUI(SceneView sv)
        {
            // 마우스 → 월드 좌표
            Ray ray = HandleUtility.GUIPointToWorldRay(Event.current.mousePosition);
            _mouseHitValid = Physics.Raycast(ray, out RaycastHit hit, 500f);
            if (_mouseHitValid) _mouseWorldPos = hit.point;

            // 커서 Gizmo
            if (_mouseHitValid)
            {
                Handles.color = new Color(0.3f, 1f, 0.9f, 0.8f);
                Handles.DrawWireDisc(_mouseWorldPos, Vector3.up, 0.25f);
                Handles.Label(_mouseWorldPos + Vector3.up * 0.3f,
                    $"← [{PROBES[_selectedProbe].icon} {PROBES[_selectedProbe].name}]");
            }

            // 단축키 감지
            if (Event.current.type == EventType.KeyDown && Event.current.alt && _mouseHitValid)
            {
                int idx = Event.current.keyCode switch
                {
                    KeyCode.Alpha1 => 0,
                    KeyCode.Alpha2 => 1,
                    KeyCode.Alpha3 => 2,
                    KeyCode.Alpha4 => 3,
                    KeyCode.Alpha5 => 4,
                    KeyCode.Alpha6 => 5,
                    KeyCode.Alpha7 => 6,
                    _ => -1
                };
                if (idx >= 0)
                {
                    _selectedProbe = idx;
                    FireProbe(idx, _mouseWorldPos);
                    Event.current.Use();
                    sv.Repaint();
                }
            }

            DrawPersistentGizmos();
        }

        // [B8 Fix] List + reverse-remove — 매 프레임 new Queue 생성 제거
        private void DrawPersistentGizmos()
        {
            float now = (float)EditorApplication.timeSinceStartup;

            for (int i = _gizmoList.Count - 1; i >= 0; i--)
            {
                var g = _gizmoList[i];
                if (g.expireTime < now)
                {
                    _gizmoList.RemoveAt(i);
                    continue;
                }

                float alpha = Mathf.Clamp01((g.expireTime - now) / GIZMO_DURATION);
                Handles.color = new Color(g.color.r, g.color.g, g.color.b, g.color.a * alpha);

                if (g.radius > 0f)
                    Handles.DrawWireDisc(g.position, Vector3.up, g.radius);
                else
                    Handles.DrawSolidDisc(g.position, Vector3.up, 0.2f);

                Handles.Label(g.position + Vector3.up * 0.4f, g.label);
            }
        }

        // =====================================================================
        // 프로브 발동
        // =====================================================================

        private void FireProbe(int idx, Vector3 pos)
        {
            // [E3 Fix] 다수 AI 지원 — 일부 프로브는 전체 선택에 적용
            var targets = GetTargetAIs();
            var primary = targets.Count > 0 ? targets[0] : null;

            switch (idx)
            {
                case 0: FireFootstep(pos); break;
                case 1: FireCombatNoise(pos); break;
                case 2: FireFearBoost(targets); break;  // 전체 선택에 적용
                case 3: FireFearReset(targets); break;  // 전체 선택에 적용
                case 4: FireMemoryInject(pos, primary); break;
                case 5: FirePanicPropagate(pos); break;
                case 6: FireForceCombat(primary); break;
            }
            SceneView.RepaintAll();
        }

        // ── [인지경유] 발자국 소리 ──
        private void FireFootstep(Vector3 pos)
        {
            // SoundPerception.HandleSoundEmitted의 Footstep baseRadius = 15f
            // → OnSoundEvent(pos, 0.3f × 15f = 4.5m) 전달
            // Gizmo는 AI hearingRange 기준 (별개 개념)
            SoundEventEmitter.EmitSound(pos, SoundType.Footstep, 0.3f);
            EnqueueGizmo(pos, 15f, new Color(0.4f, 0.8f, 1f, 0.7f),
                "🔊 Footstep vol=0.3\n(baseRadius=15m)");
            AddLog($"🔊 발자국 at {pos:F1}");
        }

        // ── [인지경유] 전투 소음 ──
        private void FireCombatNoise(Vector3 pos)
        {
            // Combat baseRadius = 40f → OnSoundEvent sourceRadius = 0.8 × 40 = 32m
            SoundEventEmitter.EmitSound(pos, SoundType.Combat, 0.8f);
            EnqueueGizmo(pos, 40f, new Color(1f, 0.3f, 0.3f, 0.6f),
                "💥 Combat vol=0.8\n(baseRadius=40m)");
            AddLog($"💥 전투소음 at {pos:F1}");
        }

        // ── [BT강제] 공포 증폭 — [E3] 다수 AI 지원 + [E5] Undo ──
        private void FireFearBoost(List<AICharacterManager> targets)
        {
            foreach (var ai in targets)
            {
                var brain = ai.GetComponent<MobAIBrain>();
                if (brain == null) continue;

                // [E5 Fix] Undo 지원
                Undo.RecordObject(brain, "Probe: Fear Boost");

                float before = brain.fear;
                brain.fear = Mathf.Clamp01(brain.fear + _fearDelta);
                EditorUtility.SetDirty(brain);

                EnqueueGizmo(ai.transform.position, 0f, new Color(1f, 0.5f, 0.1f, 0.9f),
                    $"😱 Fear {before:F2}→{brain.fear:F2}");
                AddLog($"😱 공포증폭 {ai.name}: {before:F2}→{brain.fear:F2}");
            }
        }

        // ── [BT강제] 공포+각성 리셋 — [E3] 다수 AI 지원 ──
        private void FireFearReset(List<AICharacterManager> targets)
        {
            foreach (var ai in targets)
            {
                var brain = ai.GetComponent<MobAIBrain>();
                var perception = ai.GetComponent<AIPerceptionSystem>();
                var btAgent = ai.GetComponent<BehaviorGraphAgent>();

                if (brain != null)
                {
                    Undo.RecordObject(brain, "Probe: Fear Reset");
                    brain.fear = 0f;
                    EditorUtility.SetDirty(brain);
                }
                perception?.ForceSetAwareness(AwarenessState.Unaware, "ProbeReset");
                btAgent?.SetVariableValue("LastHeardPosition", Vector3.zero);
                btAgent?.SetVariableValue("LastSeenPosition", Vector3.zero);

                EnqueueGizmo(ai.transform.position, 0f, new Color(0.3f, 1f, 0.4f, 0.9f),
                    "🧊 RESET  fear=0\nUnaware + 기억초기화");
                AddLog($"🧊 리셋 {ai.name}");
            }
        }

        // ── [BT강제] 메모리 주입 ──
        private void FireMemoryInject(Vector3 pos, AICharacterManager ai)
        {
            if (ai == null) return;
            var btAgent = ai.GetComponent<BehaviorGraphAgent>();
            btAgent?.SetVariableValue("LastSeenPosition", pos);

            float d = Vector3.Distance(ai.transform.position, pos);
            EnqueueGizmo(pos, 0f, new Color(0.7f, 0.3f, 1f, 0.9f),
                $"💭 LastSeen  ({d:F1}m)");
            AddLog($"💭 메모리주입 {ai.name}: {pos:F1}");
        }

        // ── [BT강제/효과직접] 패닉 전파 ──
        // [B4 Fix] HandlePanicChain() 경유 불가 (FleeSwarmAction.OnStart() private)
        //          → brain.fear 직접 수정. 레이블을 [BT강제]로 교정.
        private void FirePanicPropagate(Vector3 pos)
        {
            const float radius = 5f;
            int count = 0;
            foreach (var col in Physics.OverlapSphere(pos, radius))
            {
                var brain = col.GetComponent<MobAIBrain>();
                if (brain == null) continue;

                Undo.RecordObject(brain, "Probe: Panic Propagate");
                brain.fear = Mathf.Clamp01(brain.fear + 0.3f);
                EditorUtility.SetDirty(brain);
                count++;
            }
            EnqueueGizmo(pos, radius, new Color(1f, 0.6f, 0.1f, 0.6f),
                $"🌐 Panic +0.3  ({count}마리)\n[BT강제/효과직접]");
            AddLog($"🌐 패닉전파 at {pos:F1} → {count}마리");
        }

        // ── [BT강제] 강제 전투 진입 — [E4] Player 캐시 ──
        private void FireForceCombat(AICharacterManager ai)
        {
            if (ai == null) return;

            // [E4 Fix] Player 캐시
            if (_cachedPlayer == null || !_cachedPlayer.activeInHierarchy)
                _cachedPlayer = GameObject.FindGameObjectWithTag("Player");

            var perception = ai.GetComponent<AIPerceptionSystem>();
            var btAgent = ai.GetComponent<BehaviorGraphAgent>();

            perception?.ForceSetAwareness(AwarenessState.Combat, "ProbeForceCombat");

            if (_cachedPlayer != null)
            {
                btAgent?.SetVariableValue("HasTarget", true);
                btAgent?.SetVariableValue("UtilityWinner", "Attack");
                btAgent?.SetVariableValue("Target", _cachedPlayer.transform);
            }

            EnqueueGizmo(ai.transform.position, 0f, new Color(1f, 0.2f, 0.2f, 0.9f),
                "🎯 [COMBAT]  강제 진입");
            AddLog($"🎯 강제전투 {ai.name}"
                   + (_cachedPlayer != null ? $" → {_cachedPlayer.name}" : " (Player 없음)"));
        }

        // =====================================================================
        // 유틸
        // =====================================================================

        // [E3 Fix] Selection.objects 다수 선택 지원
        private static List<AICharacterManager> GetTargetAIs()
        {
            var result = new List<AICharacterManager>();
            foreach (var obj in Selection.objects)
            {
                if (obj is GameObject go)
                {
                    var ai = go.GetComponent<AICharacterManager>();
                    if (ai != null) result.Add(ai);
                }
            }
            return result;
        }

        private void EnqueueGizmo(Vector3 pos, float radius, Color color, string label)
        {
            _gizmoList.Add(new ProbeGizmo
            {
                position = pos,
                radius = radius,
                color = color,
                label = label,
                expireTime = (float)EditorApplication.timeSinceStartup + GIZMO_DURATION,
            });
        }

        private void AddLog(string msg)
        {
            _eventLog.Insert(0, $"[{DateTime.Now:HH:mm:ss}] {msg}");
            if (_eventLog.Count > MAX_LOG)
                _eventLog.RemoveAt(_eventLog.Count - 1);
        }
    }
}
#endif