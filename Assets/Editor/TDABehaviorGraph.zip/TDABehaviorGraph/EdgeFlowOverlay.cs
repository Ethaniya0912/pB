// =============================================================================
// EdgeFlowOverlay.cs  |  TDA Project
// Layer  : Editor Tooling
// Phase  : 4 (흐르는 점 + 스플라인 오버레이)
//
// 역할:
//   BehaviorGraphEditor 위에 투명한 VisualElement 오버레이를 추가하여
//   활성(Running) 엣지에 애니메이션 흐르는 점과 선명한 스플라인 선을 렌더링합니다.
//   기존 Behavior Graph 에디터의 모든 편집 기능을 완전히 보존합니다.
//
// 렌더링 내용:
//   - 비활성 엣지: 희미한 흰색 베지어 선 (1.2px)
//   - 활성 엣지:   청록색 베지어 선 (2.5px) + 흐르는 점 3개
//   - 흐르는 점:   UltraWire Moving Bubbles 패턴 (양끝 페이드, 0.33 간격)
//
// 이중 비판·재검증 반영:
//   [C-02] Edge Reflection 필드명: "Output"/"Input" -> "Start"/"End" 프로퍼티
//   [C-03] Edge worldBound 폴백 제거 -> (0,0) 반환 시 렌더링 스킵
//   [C-06] RefreshFlows 100ms / MarkDirtyRepaint 16ms 주기 분리
//   [C-09] Reflection 캐시: Dictionary<Type,(start,end)> 타입별 관리
//   [D-01] 오버레이 자가복구: DetachFromPanelEvent 감지 후 재연결
//   [D-02] GetValue() try-catch 보호
//   [D-06] 좌표계: overlay를 BehaviorGraphEditor 직접 자식으로 추가
//           -> WorldToLocal()이 올바르게 동작
// =============================================================================
#if UNITY_EDITOR
using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using UnityEditor;
using UnityEngine;
using UnityEngine.UIElements;

namespace TDA.Editor
{
    /// <summary>
    /// Behavior Graph 에디터 캔버스 위에 흐르는 점과 스플라인 선을 오버레이 렌더링합니다.
    /// </summary>
    public sealed class EdgeFlowOverlay : VisualElement
    {
        // =====================================================================
        // 상수
        // =====================================================================

        private const string k_NodeUITypeName = "BehaviorNodeUI";
        private const string k_RunningClass = "NodeStatus_Running";
        private const string k_GraphViewClass = "BehaviorGraphView";

        /// <summary>엣지 위치 갱신 주기 (ms). 패닝/줌 후 좌표 추적.</summary>
        private const int k_RefreshMs = 100;
        /// <summary>애니메이션 단계 및 재그리기 주기 (ms). ~60fps.</summary>
        private const int k_AnimMs = 16;

        private const float k_ActiveLineWidth = 2.5f;
        private const float k_InactiveLineWidth = 1.2f;
        private const float k_DotRadius = 3.5f;
        private const int k_DotCount = 3;
        private const float k_DotSpacing = 1f / k_DotCount;  // ~0.333
        private const float k_FlowSpeed = 0.015f;
        private const float k_BezierHandleRatio = 0.45f;

        private static readonly Color k_ActiveLineColor = new Color(0.00f, 0.80f, 0.60f, 0.85f);
        private static readonly Color k_InactiveLineColor = new Color(1.00f, 1.00f, 1.00f, 0.10f);
        private static readonly Color k_DotColor = new Color(0.00f, 0.90f, 0.63f, 1.00f);

        // =====================================================================
        // 내부 데이터 구조
        // =====================================================================

        /// <summary>렌더링할 엣지 하나의 데이터.</summary>
        private struct FlowEdge
        {
            /// <summary>OutputPort 하단 중심 (오버레이 로컬 좌표).</summary>
            public Vector2 From;
            /// <summary>InputPort 상단 중심 (오버레이 로컬 좌표).</summary>
            public Vector2 To;
            /// <summary>흐르는 점 위상 (0~1). Tick에서 FlowSpeed만큼 증가.</summary>
            public float Phase;
            /// <summary>Running 상태 여부.</summary>
            public bool Active;
        }

        // =====================================================================
        // 필드
        // =====================================================================

        private readonly List<FlowEdge> _flows = new();
        private readonly VisualElement _bge;
        private VisualElement _graphView;

        /// <summary>엣지별 위상 연속성 유지 맵 (엣지 해시 -> phase).</summary>
        private readonly Dictionary<string, float> _phaseMap = new();

        // =====================================================================
        // Reflection 캐시
        // =====================================================================

        /// <summary>
        /// Port.Edges 프로퍼티 캐시 (단일 캐시 유지 - Edges는 Port 단일 타입에서 정의).
        /// </summary>
        private static PropertyInfo s_edgesProp;

        /// <summary>진단 로그 출력 횟수 제한 (첫 3회만 출력).</summary>
        private int _diagLogCount;

        /// <summary>
        /// Edge 타입별 (Start, End) 프로퍼티 캐시 (C-09: 타입별 독립 캐시).
        /// </summary>
        private static readonly Dictionary<Type, (PropertyInfo start, PropertyInfo end)>
            s_edgePropCache = new();

        private static readonly BindingFlags k_BF =
            BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance;

        // =====================================================================
        // 생성자
        // =====================================================================

        /// <summary>
        /// EdgeFlowOverlay를 생성하고 BehaviorGraphEditor에 오버레이로 추가합니다.
        /// </summary>
        /// <param name="bge">BehaviorGraphEditor VisualElement.</param>
        public EdgeFlowOverlay(VisualElement bge)
        {
            _bge = bge ?? throw new ArgumentNullException(nameof(bge));

            // pickingMode = Ignore : 클릭/드래그 이벤트 통과 -> 기존 기능 완전 보존
            pickingMode = PickingMode.Ignore;
            style.position = Position.Absolute;
            style.left = 0;
            style.top = 0;
            style.right = 0;
            style.bottom = 0;

            generateVisualContent += Draw;

            // BehaviorGraphView 탐색
            _graphView = bge.Q<VisualElement>(className: k_GraphViewClass);

            // D-06: BGE 직접 자식으로 추가 -> WorldToLocal() 동일 좌표계
            bge.Add(this);
            BringToFront();

            // D-01: 자가복구
            RegisterCallback<DetachFromPanelEvent>(OnDetached);

            // RefreshFlows 100ms: 포트 위치 갱신
            schedule.Execute(RefreshFlows).Every(k_RefreshMs);
            // Tick 16ms: 위상 진행 + MarkDirtyRepaint
            schedule.Execute(Tick).Every(k_AnimMs);

            Debug.Log("[EdgeFlowOverlay] 초기화 완료.");
        }

        // =====================================================================
        // 자가복구
        // =====================================================================

        /// <summary>분리 감지 후 다음 에디터 프레임에 재연결합니다.</summary>
        private void OnDetached(DetachFromPanelEvent _)
        {
            EditorApplication.delayCall += () =>
            {
                if (_bge?.panel == null || panel != null) return;
                _bge.Add(this);
                BringToFront();
                Debug.Log("[EdgeFlowOverlay] 자가복구 완료.");
            };
        }

        // =====================================================================
        // 틱 / 위치 갱신
        // =====================================================================

        /// <summary>
        /// 16ms마다 실행. 활성 엣지 위상 진행 + 재그리기 요청.
        /// 위치 갱신은 RefreshFlows(100ms)가 담당하므로 여기서는 최소 연산.
        /// </summary>
        private void Tick()
        {
            for (int i = 0; i < _flows.Count; i++)
            {
                if (!_flows[i].Active) continue;
                var f = _flows[i];
                f.Phase = (f.Phase + k_FlowSpeed) % 1f;
                _flows[i] = f;
            }
            MarkDirtyRepaint();
        }

        /// <summary>
        /// 100ms마다 실행. 노드와 엣지를 순회하여 포트 위치를 갱신합니다.
        /// 패닝/줌 후에도 점이 엣지를 정확히 따라가도록 합니다.
        /// </summary>
        private void RefreshFlows()
        {
            if (_graphView == null)
            {
                _graphView = _bge?.Q<VisualElement>(className: k_GraphViewClass);
                if (_graphView == null) return;
            }

            _flows.Clear();

            _graphView.Query<VisualElement>()
                      .Where(e => e.GetType().Name == k_NodeUITypeName)
                      .ForEach(ProcessNode);
        }

        /// <summary>BehaviorNodeUI 하나를 처리하여 _flows에 엣지를 추가합니다.</summary>
        private void ProcessNode(VisualElement nodeUI)
        {
            var inputPort = GetFirstInputPort(nodeUI);
            if (inputPort == null) return; // Start 노드 등 입력 포트 없는 경우 정상 스킵

            bool nodeIsRunning = nodeUI.ClassListContains(k_RunningClass);
            int edgeCountBefore = _flows.Count;

            foreach (var edge in GetEdges(inputPort))
            {
                if (edge == null) continue;

                var (from, to) = GetEdgeEndpoints(edge);

                // C-03: (0,0)이면 실패 → 스킵 (잘못된 좌표로 렌더링 방지)
                if (from == Vector2.zero && to == Vector2.zero) continue;

                // worldBound → 오버레이 로컬 좌표 (D-06: BGE 직접 자식이므로 올바르게 변환)
                from = this.WorldToLocal(from);
                to = this.WorldToLocal(to);

                if (!IsValidVector(from) || !IsValidVector(to)) continue;

                string edgeKey = edge.GetHashCode().ToString();
                _phaseMap.TryGetValue(edgeKey, out float phase);

                bool isActive = nodeIsRunning || edge.ClassListContains(k_RunningClass);

                _flows.Add(new FlowEdge
                {
                    From = from,
                    To = to,
                    Phase = phase,
                    Active = isActive,
                });
            }

            // 진단 로그 (첫 3회만 출력하여 Console 과부하 방지)
            if (_diagLogCount < 3)
            {
                int added = _flows.Count - edgeCountBefore;
                if (added > 0 || nodeIsRunning)
                {
                    Debug.Log(
                        $"[EdgeFlowOverlay] ProcessNode: {nodeUI.GetType().Name} " +
                        $"Running={nodeIsRunning} Port={inputPort.GetType().Name} " +
                        $"엣지추가={added}개 Total={_flows.Count}");
                    _diagLogCount++;
                }
            }
        }

        // =====================================================================
        // 렌더링
        // =====================================================================

        /// <summary>generateVisualContent 콜백. Painter2D로 선과 점을 렌더링합니다.</summary>
        private void Draw(MeshGenerationContext ctx)
        {
            if (_flows.Count == 0) return;

            var p2d = ctx.painter2D;
            p2d.lineCap = LineCap.Round;
            p2d.lineJoin = LineJoin.Round;

            foreach (var flow in _flows)
            {
                DrawEdgeLine(p2d, in flow);
                if (flow.Active)
                    DrawFlowDots(p2d, in flow);
            }
        }

        /// <summary>
        /// 베지어 스플라인 선 렌더링.
        /// 활성=청록 2.5px / 비활성=희미한 흰색 1.2px.
        /// </summary>
        private static void DrawEdgeLine(Painter2D p, in FlowEdge f)
        {
            p.strokeColor = f.Active ? k_ActiveLineColor : k_InactiveLineColor;
            p.lineWidth = f.Active ? k_ActiveLineWidth : k_InactiveLineWidth;

            float dy = (f.To.y - f.From.y) * k_BezierHandleRatio;
            var c1 = new Vector2(f.From.x, f.From.y + dy);
            var c2 = new Vector2(f.To.x, f.To.y - dy);

            p.BeginPath();
            p.MoveTo(f.From);
            p.BezierCurveTo(c1, c2, f.To);
            p.Stroke();
        }

        /// <summary>
        /// 흐르는 점 3개 렌더링 (UltraWire Moving Bubbles 패턴).
        /// 0.33 간격, 양끝 sin 페이드 아웃.
        /// </summary>
        private static void DrawFlowDots(Painter2D p, in FlowEdge f)
        {
            for (int i = 0; i < k_DotCount; i++)
            {
                float t = (f.Phase + i * k_DotSpacing) % 1f;
                var pos = EvaluateBezier(f.From, f.To, t);
                float alpha = Mathf.Sin(t * Mathf.PI);

                if (alpha < 0.05f) continue; // 거의 투명한 점은 스킵

                p.fillColor = new Color(
                    k_DotColor.r, k_DotColor.g, k_DotColor.b,
                    k_DotColor.a * alpha * 0.9f);

                p.BeginPath();
                p.Arc(pos, k_DotRadius, 0f, 360f);
                p.Fill();
            }
        }

        // =====================================================================
        // 베지어 수학
        // =====================================================================

        /// <summary>
        /// 수직 핸들 3차 베지어 B(t) 계산.
        /// Unity Behavior Graph 엣지와 동일한 방식으로 경로를 공유합니다.
        ///   P1 = (P0.x, P0.y + dy*0.45)
        ///   P2 = (P3.x, P3.y - dy*0.45)
        /// </summary>
        private static Vector2 EvaluateBezier(Vector2 p0, Vector2 p3, float t)
        {
            float dy = (p3.y - p0.y) * k_BezierHandleRatio;
            var p1 = new Vector2(p0.x, p0.y + dy);
            var p2 = new Vector2(p3.x, p3.y - dy);

            float u = 1f - t;
            return u * u * u * p0 + 3 * u * u * t * p1 + 3 * u * t * t * p2 + t * t * t * p3;
        }

        // =====================================================================
        // Reflection 헬퍼
        // =====================================================================

        /// <summary>GetFirstInputPort() Reflection 호출.
        /// 수정 (v1→v1.1): static MethodInfo 단일 캐시 → Dictionary&lt;Type,MethodInfo&gt; 타입별 캐시.
        /// 이유: 첫 번째 호출 대상이 StartNodeUI이면 StartNodeUI의 MethodInfo가 캐시되어
        ///       이후 BehaviorNodeUI, ActionNodeUI 등에서 null 반환 문제 발생.
        /// </summary>
        private static readonly Dictionary<Type, MethodInfo> s_inputPortMethods = new();

        private static VisualElement GetFirstInputPort(VisualElement nodeUI)
        {
            try
            {
                var type = nodeUI.GetType();

                // 타입별로 독립 캐시 (null도 캐시하여 불필요한 탐색 방지)
                if (!s_inputPortMethods.TryGetValue(type, out var method))
                {
                    method = FindMethodInHierarchy(type, "GetFirstInputPort", k_BF);
                    s_inputPortMethods[type] = method;
                }

                if (method == null) return null;
                return method.Invoke(nodeUI, null) as VisualElement;
            }
            catch (Exception ex)
            {
                Debug.LogWarning($"[EdgeFlowOverlay] GetFirstInputPort 실패: {ex.Message}");
                return null;
            }
        }

        /// <summary>Port.Edges Reflection 접근 -> IEnumerable&lt;VisualElement&gt;.</summary>
        private static IEnumerable<VisualElement> GetEdges(VisualElement port)
        {
            if (port == null) yield break;

            // CS1626: yield return은 try-catch 블록 안에 있을 수 없으므로
            // Reflection 접근만 try-catch로 감싸고, yield는 블록 밖에서 수행합니다.
            System.Collections.IEnumerable rawEdges = null;
            try
            {
                s_edgesProp ??= FindPropertyInHierarchy(port.GetType(), "Edges", k_BF);
                if (s_edgesProp != null)
                    rawEdges = s_edgesProp.GetValue(port) as System.Collections.IEnumerable;
            }
            catch (Exception ex)
            {
                Debug.LogWarning($"[EdgeFlowOverlay] Port.Edges 실패: {ex.Message}");
                yield break;
            }

            if (rawEdges == null) yield break;

            // try-catch 블록 밖에서 안전하게 yield
            foreach (var obj in rawEdges)
                if (obj is VisualElement ve) yield return ve;
        }

        /// <summary>
        /// Edge.Start(OutputPort) / Edge.End(InputPort) worldBound 중심을 반환합니다.
        /// C-02: "Start"/"End" 프로퍼티 (소스: GraphContextMenuManipulator.cs 379번 줄).
        /// C-03: 실패 시 (zero, zero) 반환 -> 호출부 스킵.
        /// C-09: Dictionary<Type,...>로 타입별 독립 캐시.
        /// D-02: GetValue() 개별 try-catch.
        /// </summary>
        private static (Vector2 from, Vector2 to) GetEdgeEndpoints(VisualElement edge)
        {
            try
            {
                var type = edge.GetType();

                if (!s_edgePropCache.TryGetValue(type, out var props))
                {
                    props = (
                        FindPropertyInHierarchy(type, "Start", k_BF),
                        FindPropertyInHierarchy(type, "End", k_BF)
                    );
                    s_edgePropCache[type] = props;
                }

                VisualElement startPort = null, endPort = null;

                if (props.start != null)
                    try { startPort = props.start.GetValue(edge) as VisualElement; } catch { }
                if (props.end != null)
                    try { endPort = props.end.GetValue(edge) as VisualElement; } catch { }

                if (startPort != null && endPort != null)
                {
                    // Start=OutputPort(출력, 부모노드 하단), End=InputPort(입력, 자식노드 상단)
                    var fb = startPort.worldBound;
                    var tb = endPort.worldBound;
                    return (
                        new Vector2(fb.center.x, fb.yMax),  // OutputPort 하단 중심
                        new Vector2(tb.center.x, tb.yMin)   // InputPort  상단 중심
                    );
                }
            }
            catch (Exception ex)
            {
                Debug.LogWarning(
                    $"[EdgeFlowOverlay] GetEdgeEndpoints 실패: {ex.Message}\n" +
                    "Edge.Start/End 프로퍼티가 변경됐을 수 있습니다.");
            }

            return (Vector2.zero, Vector2.zero);
        }

        private static MethodInfo FindMethodInHierarchy(Type t, string n, BindingFlags f)
        {
            for (; t != null && t != typeof(object); t = t.BaseType)
            { var m = t.GetMethod(n, f); if (m != null) return m; }
            return null;
        }

        private static PropertyInfo FindPropertyInHierarchy(Type t, string n, BindingFlags f)
        {
            for (; t != null && t != typeof(object); t = t.BaseType)
            { var p = t.GetProperty(n, f); if (p != null) return p; }
            return null;
        }

        private static bool IsValidVector(Vector2 v) =>
            !float.IsNaN(v.x) && !float.IsNaN(v.y) &&
            !float.IsInfinity(v.x) && !float.IsInfinity(v.y);

        // =====================================================================
        // 정리
        // =====================================================================

        /// <summary>
        /// 리소스를 정리하고 오버레이를 부모에서 제거합니다.
        /// BehaviorGraphEditorEnhancer가 창 닫힘 시 호출합니다.
        /// </summary>
        public void Dispose()
        {
            _flows.Clear();
            _phaseMap.Clear();
            if (parent != null) RemoveFromHierarchy();
            Debug.Log("[EdgeFlowOverlay] Dispose 완료.");
        }
    }
}
#endif