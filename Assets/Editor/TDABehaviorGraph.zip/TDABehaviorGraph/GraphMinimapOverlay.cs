// =============================================================================
// GraphMinimapOverlay.cs  |  TDA Project (EdgeFlowOverlay.cs에 추가)
// Layer  : Editor Tooling
// Phase  : 5 (PiP 미니맵)
//
// 역할:
//   BehaviorGraphEditor 우하단에 PiP(Picture-in-Picture) 미니맵을 표시합니다.
//   전체 그래프 구조를 한눈에 파악하고, 클릭으로 뷰포트를 이동합니다.
//
// ★ 이 파일의 내용을 EdgeFlowOverlay.cs 파일의 마지막 클래스 닫는 중괄호(})
//   바로 위에 추가하세요. 단, #if UNITY_EDITOR / #endif 블록 안에 넣어야 합니다.
//
// 위치: EdgeFlowOverlay.cs 파일 내 namespace TDA.Editor 블록 안,
//       EdgeFlowOverlay 클래스 다음에 GraphMinimapOverlay 클래스 추가
//
// 의존성:
//   - BehaviorGraphEditorEnhancer.cs 가 생성·보유합니다.
//   - EdgeFlowOverlay.cs 와 같은 파일에 있어야 합니다 (같은 namespace).
// =============================================================================
//
// EdgeFlowOverlay.cs 에 아래 코드를 붙여넣는 위치:
//   } // EdgeFlowOverlay 클래스 끝
//
//   ↓ 여기에 GraphMinimapOverlay 클래스 추가
//
// =============================================================================

#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using System.Reflection;
using UnityEditor;
using UnityEngine;
using UnityEngine.UIElements;

namespace TDA.Editor
{
    /// <summary>
    /// Behavior Graph 에디터 우하단에 PiP 미니맵을 표시하는 VisualElement입니다.
    /// 전체 노드 위치를 축소 표시하고, 클릭 시 해당 위치로 뷰포트를 이동합니다.
    /// </summary>
    public sealed class GraphMinimapOverlay : VisualElement
    {
        // =====================================================================
        // 상수
        // =====================================================================

        private const string k_NodeUITypeName = "BehaviorNodeUI";
        private const string k_RunningClass = "NodeStatus_Running";
        private const string k_FailureClass = "NodeStatus_Failure";
        private const string k_GraphViewClass = "BehaviorGraphView";

        /// <summary>미니맵 패널 너비 (px).</summary>
        private const float k_MapW = 200f;
        /// <summary>미니맵 패널 높이 (px).</summary>
        private const float k_MapH = 130f;
        /// <summary>패널 여백 (px).</summary>
        private const float k_Margin = 10f;
        /// <summary>위치 갱신 주기 (ms). ~10fps.</summary>
        private const int k_RefreshMs = 100;

        // ── 색상 ─────────────────────────────────────────────────────────────
        private static readonly Color k_BgColor = new(0.08f, 0.08f, 0.10f, 0.88f);
        private static readonly Color k_BorderColor = new(0.30f, 0.30f, 0.35f, 0.80f);
        private static readonly Color k_NodeDefault = new(0.35f, 0.35f, 0.40f, 0.90f);
        private static readonly Color k_NodeRunning = new(0.00f, 0.90f, 0.63f, 0.95f);
        private static readonly Color k_NodeFailure = new(0.96f, 0.26f, 0.26f, 0.95f);
        private static readonly Color k_NodeStart = new(0.10f, 0.48f, 0.27f, 0.90f);
        private static readonly Color k_NodeComposite = new(0.35f, 0.17f, 0.60f, 0.90f);
        private static readonly Color k_EdgeLine = new(1.00f, 1.00f, 1.00f, 0.12f);
        private static readonly Color k_ViewportColor = new(1.00f, 1.00f, 1.00f, 0.20f);
        private static readonly Color k_ViewportBorder = new(1.00f, 1.00f, 1.00f, 0.50f);
        private static readonly Color k_HeaderBg = new(0.12f, 0.12f, 0.16f, 0.95f);

        // =====================================================================
        // 내부 상태
        // =====================================================================

        private readonly VisualElement _bge;
        private VisualElement _graphView;

        /// <summary>
        /// 초기화 지연 카운터.
        /// 생성 직후에는 BehaviorNodeUI의 worldBound가 Rect(0,0,0,0)일 수 있으므로
        /// k_InitDelay × k_RefreshMs(ms) 동안 RefreshData를 스킵합니다.
        /// 수정 이유: 스크린샷에서 미니맵이 비어 있었던 원인 — 생성 시점에 노드 좌표 미확정.
        /// </summary>
        private int _initDelayCount;

        /// <summary>초기화 지연 횟수 (10 × 100ms = 1초 대기).</summary>
        private const int k_InitDelay = 10;

        /// <summary>진단 로그 출력 횟수 제한.</summary>
        private int _diagLogCount;

        /// <summary>수집된 노드 미니맵 데이터.</summary>
        private readonly List<MinimapNode> _nodes = new();
        /// <summary>수집된 엣지 미니맵 데이터.</summary>
        private readonly List<(Vector2 from, Vector2 to)> _edges = new();

        /// <summary>전체 노드 WorldBound의 AABB (줌/패닝 무관한 절대 좌표).</summary>
        private Rect _totalBounds;

        // =====================================================================
        // 노드 미니맵 데이터
        // =====================================================================

        private struct MinimapNode
        {
            public Rect WorldBound;
            public Color Color;
            public bool IsRunning;
        }

        // =====================================================================
        // Reflection 캐시
        // =====================================================================

        private static PropertyInfo s_backgroundProp;
        private static MethodInfo s_frameAllMethod;
        private static MethodInfo s_getInputPortMethod_UNUSED; // 하위 호환용 (사용 안 함)

        /// <summary>
        /// 타입별 GetFirstInputPort MethodInfo 캐시.
        /// 수정 이유: static 단일 캐시가 첫 번째 타입(StartNodeUI)의 메서드로 고정되어
        ///            이후 다른 타입 노드에서 null 반환하는 문제 해소.
        /// </summary>
        private static readonly Dictionary<Type, MethodInfo> s_inputPortMethodCache = new();
        private static PropertyInfo s_edgesProp;
        private static readonly Dictionary<Type, (PropertyInfo start, PropertyInfo end)>
            s_edgePropCache = new();
        private static readonly BindingFlags k_BF =
            BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance;

        // =====================================================================
        // 생성자
        // =====================================================================

        /// <summary>
        /// GraphMinimapOverlay를 생성하고 BehaviorGraphEditor에 추가합니다.
        /// </summary>
        /// <param name="bge">BehaviorGraphEditor VisualElement.</param>
        public GraphMinimapOverlay(VisualElement bge)
        {
            _bge = bge ?? throw new ArgumentNullException(nameof(bge));

            // 클릭 이벤트는 받음 (뷰포트 이동을 위해)
            pickingMode = PickingMode.Position;
            style.position = Position.Absolute;

            // 우하단 고정
            style.right = k_Margin;
            style.bottom = k_Margin;
            style.width = k_MapW;
            style.height = k_MapH;

            // 렌더링 콜백
            generateVisualContent += Draw;

            // 클릭 이벤트 (클릭 위치의 노드로 FrameAll)
            RegisterCallback<ClickEvent>(OnClick);

            // 자가복구
            RegisterCallback<DetachFromPanelEvent>(OnDetached);

            // 부모에 추가
            bge.Add(this);
            BringToFront();

            // BehaviorGraphView 탐색
            _graphView = bge.Q<VisualElement>(className: k_GraphViewClass);

            // 갱신 스케줄러
            schedule.Execute(RefreshData).Every(k_RefreshMs);

            Debug.Log("[GraphMinimap] 초기화 완료.");
        }

        // =====================================================================
        // 자가복구
        // =====================================================================

        private void OnDetached(DetachFromPanelEvent _)
        {
            EditorApplication.delayCall += () =>
            {
                if (_bge?.panel == null || panel != null) return;
                _bge.Add(this);
                BringToFront();
            };
        }

        // =====================================================================
        // 데이터 갱신
        // =====================================================================

        /// <summary>
        /// 100ms마다 노드와 엣지 위치를 갱신합니다.
        /// 패닝/줌 후에도 미니맵이 올바른 위치를 표시합니다.
        ///
        /// 수정 (v1→v1.1):
        ///   초기화 지연 추가 — 생성 직후 노드 worldBound가 Rect(0,0,0,0)인 문제 해소.
        ///   k_InitDelay × k_RefreshMs = 10 × 100ms = 1초 대기 후 탐색 시작.
        /// </summary>
        private void RefreshData()
        {
            // ── 초기화 지연 ─────────────────────────────────────────────────────
            // 생성 직후에는 BehaviorGraphView의 Layout 계산이 완료되지 않아
            // BehaviorNodeUI들의 worldBound가 모두 Rect(0,0,0,0)입니다.
            // k_InitDelay 횟수(1초) 동안 RefreshData를 스킵합니다.
            if (_initDelayCount < k_InitDelay)
            {
                _initDelayCount++;
                return;
            }

            if (_graphView == null)
            {
                _graphView = _bge?.Q<VisualElement>(className: k_GraphViewClass);
                if (_graphView == null) return;
            }

            _nodes.Clear();
            _edges.Clear();

            // 전체 bounds 초기화
            bool first = true;
            float xMin = 0, yMin = 0, xMax = 0, yMax = 0;
            int nodeCount = 0;

            // 노드 수집
            _graphView.Query<VisualElement>()
                      .Where(e => e.GetType().Name == k_NodeUITypeName)
                      .ForEach(nodeUI =>
                      {
                          var wb = nodeUI.worldBound;
                          if (wb.width < 1 || wb.height < 1) return;

                          nodeCount++;

                          // 전체 bounds 확장
                          if (first) { xMin = wb.xMin; yMin = wb.yMin; xMax = wb.xMax; yMax = wb.yMax; first = false; }
                          else
                          {
                              xMin = Mathf.Min(xMin, wb.xMin); yMin = Mathf.Min(yMin, wb.yMin);
                              xMax = Mathf.Max(xMax, wb.xMax); yMax = Mathf.Max(yMax, wb.yMax);
                          }

                          bool isRunning = nodeUI.ClassListContains(k_RunningClass);
                          bool isFailure = nodeUI.ClassListContains(k_FailureClass);

                          _nodes.Add(new MinimapNode
                          {
                              WorldBound = wb,
                              IsRunning = isRunning,
                              Color = isRunning ? k_NodeRunning
                                                     : isFailure ? k_NodeFailure
                                                     : GetNodeColor(nodeUI),
                          });

                          // 엣지 수집
                          CollectEdgesForNode(nodeUI);
                      });

            // ── 진단 로그 (첫 3회만 출력) ──────────────────────────────────────
            if (_diagLogCount < 3)
            {
                Debug.Log(
                    $"[GraphMinimap] RefreshData: 노드 {nodeCount}개 처리 | " +
                    $"first={first} | totalBounds={_totalBounds} | " +
                    $"edges={_edges.Count}개");
                _diagLogCount++;
            }

            if (!first)
                _totalBounds = Rect.MinMaxRect(xMin - 20, yMin - 20, xMax + 20, yMax + 20);

            MarkDirtyRepaint();
        }

        private void CollectEdgesForNode(VisualElement nodeUI)
        {
            var inputPort = GetFirstInputPort(nodeUI);
            if (inputPort == null) return;

            var rawEdges = GetEdges(inputPort);
            if (rawEdges == null) return;

            // CS1503 수정: GetEdges()가 System.Collections.IEnumerable(비제네릭)을 반환하므로
            // foreach의 각 항목은 object 타입입니다.
            // GetEdgeEndpoints()는 VisualElement를 요구하므로 명시적 캐스트가 필요합니다.
            foreach (var obj in rawEdges)
            {
                if (obj is not VisualElement edge) continue;   // object → VisualElement 캐스트
                var (from, to) = GetEdgeEndpoints(edge);
                if (from != Vector2.zero)
                    _edges.Add((from, to));
            }
        }

        // =====================================================================
        // 렌더링
        // =====================================================================

        private void Draw(MeshGenerationContext ctx)
        {
            var p = ctx.painter2D;

            // ── 배경 ─────────────────────────────────────────────────────────
            p.fillColor = k_BgColor;
            p.BeginPath();
            p.MoveTo(new Vector2(0, 0));
            p.LineTo(new Vector2(k_MapW, 0));
            p.LineTo(new Vector2(k_MapW, k_MapH));
            p.LineTo(new Vector2(0, k_MapH));
            p.ClosePath();
            p.Fill();

            // ── 헤더 ─────────────────────────────────────────────────────────
            p.fillColor = k_HeaderBg;
            p.BeginPath();
            p.MoveTo(new Vector2(0, 0));
            p.LineTo(new Vector2(k_MapW, 0));
            p.LineTo(new Vector2(k_MapW, 16));
            p.LineTo(new Vector2(0, 16));
            p.ClosePath();
            p.Fill();

            // ── 테두리 ───────────────────────────────────────────────────────
            p.strokeColor = k_BorderColor;
            p.lineWidth = 1f;
            p.BeginPath();
            p.MoveTo(new Vector2(0, 0));
            p.LineTo(new Vector2(k_MapW - 1, 0));
            p.LineTo(new Vector2(k_MapW - 1, k_MapH - 1));
            p.LineTo(new Vector2(0, k_MapH - 1));
            p.ClosePath();
            p.Stroke();

            // bounds가 유효한 경우만 노드·엣지 그리기
            if (_totalBounds.width < 1 || _totalBounds.height < 1) return;

            var mapRect = new Rect(4, 20, k_MapW - 8, k_MapH - 24);

            // ── 엣지 ─────────────────────────────────────────────────────────
            p.strokeColor = k_EdgeLine;
            p.lineWidth = 0.8f;
            foreach (var (from, to) in _edges)
            {
                var mf = WorldToMap(from, mapRect);
                var mt = WorldToMap(to, mapRect);
                p.BeginPath();
                p.MoveTo(mf);
                p.LineTo(mt);
                p.Stroke();
            }

            // ── 노드 ─────────────────────────────────────────────────────────
            foreach (var node in _nodes)
            {
                var mr = WorldRectToMap(node.WorldBound, mapRect);
                // 최소 크기 보장
                mr.width = Mathf.Max(mr.width, 3f);
                mr.height = Mathf.Max(mr.height, 2f);

                p.fillColor = node.Color;
                p.BeginPath();
                p.MoveTo(new Vector2(mr.xMin, mr.yMin));
                p.LineTo(new Vector2(mr.xMax, mr.yMin));
                p.LineTo(new Vector2(mr.xMax, mr.yMax));
                p.LineTo(new Vector2(mr.xMin, mr.yMax));
                p.ClosePath();
                p.Fill();
            }

            // ── 뷰포트 표시 ──────────────────────────────────────────────────
            if (_graphView != null)
            {
                var viewWB = _graphView.worldBound;
                var vr = WorldRectToMap(viewWB, mapRect);
                p.strokeColor = k_ViewportBorder;
                p.lineWidth = 1.2f;
                p.BeginPath();
                p.MoveTo(new Vector2(vr.xMin, vr.yMin));
                p.LineTo(new Vector2(vr.xMax, vr.yMin));
                p.LineTo(new Vector2(vr.xMax, vr.yMax));
                p.LineTo(new Vector2(vr.xMin, vr.yMax));
                p.ClosePath();
                p.Stroke();

                p.fillColor = k_ViewportColor;
                p.Fill();
            }
        }

        // =====================================================================
        // 클릭 처리 (뷰포트 이동)
        // =====================================================================

        private void OnClick(ClickEvent evt)
        {
            // 클릭 시 Background.FrameAll() — 전체 그래프를 보이도록
            // (클릭 좌표 기반 pan 설정은 GraphFramework 내부 접근 필요 — 향후 확장)
            try
            {
                s_backgroundProp ??= FindPropInHierarchy(
                    _graphView.GetType(), "Background", k_BF);
                var bg = s_backgroundProp?.GetValue(_graphView);
                if (bg == null) return;

                s_frameAllMethod ??= bg.GetType().GetMethod("FrameAll", k_BF);
                s_frameAllMethod?.Invoke(bg, null);
            }
            catch (Exception ex)
            {
                Debug.LogWarning($"[GraphMinimap] FrameAll 실패: {ex.Message}");
            }

            evt.StopPropagation();
        }

        // =====================================================================
        // 좌표 변환
        // =====================================================================

        /// <summary>worldBound 좌표를 미니맵 로컬 좌표로 변환합니다.</summary>
        private Vector2 WorldToMap(Vector2 world, Rect mapRect)
        {
            if (_totalBounds.width < 1 || _totalBounds.height < 1) return Vector2.zero;
            float nx = (world.x - _totalBounds.x) / _totalBounds.width;
            float ny = (world.y - _totalBounds.y) / _totalBounds.height;
            return new Vector2(
                mapRect.x + nx * mapRect.width,
                mapRect.y + ny * mapRect.height);
        }

        /// <summary>worldBound Rect를 미니맵 로컬 Rect로 변환합니다.</summary>
        private Rect WorldRectToMap(Rect wr, Rect mapRect)
        {
            var tl = WorldToMap(new Vector2(wr.xMin, wr.yMin), mapRect);
            var br = WorldToMap(new Vector2(wr.xMax, wr.yMax), mapRect);
            return Rect.MinMaxRect(tl.x, tl.y, br.x, br.y);
        }

        // =====================================================================
        // 노드 색상
        // =====================================================================

        private static Color GetNodeColor(VisualElement nodeUI)
        {
            string typeName = nodeUI.GetType().Name;
            if (typeName.Contains("Start")) return k_NodeStart;
            if (typeName.Contains("Composite") ||
                typeName.Contains("Modifier")) return k_NodeComposite;
            return k_NodeDefault;
        }

        // =====================================================================
        // Reflection 헬퍼 (EdgeFlowOverlay와 동일한 패턴)
        // =====================================================================

        private static VisualElement GetFirstInputPort(VisualElement nodeUI)
        {
            try
            {
                var type = nodeUI.GetType();

                // 타입별 독립 캐시 (null도 저장하여 불필요한 재탐색 방지)
                if (!s_inputPortMethodCache.TryGetValue(type, out var method))
                {
                    method = FindMethodInHierarchy(type, "GetFirstInputPort", k_BF);
                    s_inputPortMethodCache[type] = method;
                }

                if (method == null) return null;
                return method.Invoke(nodeUI, null) as VisualElement;
            }
            catch { return null; }
        }

        private static System.Collections.IEnumerable GetEdges(VisualElement port)
        {
            try
            {
                s_edgesProp ??= FindPropInHierarchy(port.GetType(), "Edges", k_BF);
                return s_edgesProp?.GetValue(port) as System.Collections.IEnumerable;
            }
            catch { return null; }
        }

        private static (Vector2 from, Vector2 to) GetEdgeEndpoints(VisualElement edge)
        {
            try
            {
                var type = edge.GetType();
                if (!s_edgePropCache.TryGetValue(type, out var props))
                {
                    props = (FindPropInHierarchy(type, "Start", k_BF),
                             FindPropInHierarchy(type, "End", k_BF));
                    s_edgePropCache[type] = props;
                }
                VisualElement sp = null, ep = null;
                try { sp = props.start?.GetValue(edge) as VisualElement; } catch { }
                try { ep = props.end?.GetValue(edge) as VisualElement; } catch { }

                if (sp != null && ep != null)
                    return (sp.worldBound.center, ep.worldBound.center);
            }
            catch { }
            return (Vector2.zero, Vector2.zero);
        }

        private static MethodInfo FindMethodInHierarchy(Type t, string n, BindingFlags f)
        {
            for (; t != null && t != typeof(object); t = t.BaseType)
            { var m = t.GetMethod(n, f); if (m != null) return m; }
            return null;
        }

        private static PropertyInfo FindPropInHierarchy(Type t, string n, BindingFlags f)
        {
            for (; t != null && t != typeof(object); t = t.BaseType)
            { var p = t.GetProperty(n, f); if (p != null) return p; }
            return null;
        }

        // =====================================================================
        // 정리
        // =====================================================================

        /// <summary>미니맵 오버레이를 제거합니다.</summary>
        public void Dispose()
        {
            _nodes.Clear();
            _edges.Clear();
            if (parent != null) RemoveFromHierarchy();
        }
    }
}
#endif