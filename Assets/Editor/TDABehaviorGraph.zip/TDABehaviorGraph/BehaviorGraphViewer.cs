// =============================================================================
// BehaviorGraphViewer.cs  |  TDA Project
// Window > AI > Behavior Graph Viewer
//
// 런타임 Behavior Graph를 커스텀 렌더링하는 EditorWindow.
//
// 동작 원리:
//   BehaviorGraphAgent.Graph(BehaviorGraph)에서 런타임 노드 트리를 Reflection으로
//   읽어 IMGUI로 직접 그립니다. Unity 내장 GraphView에 의존하지 않습니다.
//
// 기능:
//   - 노드 트리 자동 레이아웃 (Top-Down)
//   - 노드 타입별 색상 (Start=초록, Composite=보라, Modifier=주황, Action=회색)
//   - 실행 상태 강조 (Running=청록 테두리+펄스, Failure=빨강, Success=초록)
//   - 베지어 커브 연결선 (Active=밝게, Inactive=희미하게)
//   - 패닝/줌 지원
//   - 우측 블랙보드 오버레이 패널
//   - 매 프레임 자동 갱신 (플레이 모드)
// =============================================================================
#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using System.Reflection;
using UnityEditor;
using UnityEngine;
using Unity.Behavior;

namespace TDA.Editor
{
    public class BehaviorGraphViewer : EditorWindow
    {
        // ── 레이아웃 상수 ──────────────────────────────────────────────────────
        private const float NODE_W = 180f;
        private const float NODE_H = 52f;
        private const float H_GAP = 36f;   // 수평 간격
        private const float V_GAP = 72f;   // 수직 간격
        private const float BB_PANEL_W = 210f;  // 우측 BB 패널 너비
        private const float TOOLBAR_H = 24f;

        // ── 색상 정의 ──────────────────────────────────────────────────────────
        private static readonly Color c_bg = new Color(0.13f, 0.13f, 0.13f);
        private static readonly Color c_grid = new Color(1f, 1f, 1f, 0.04f);
        private static readonly Color c_gridMajor = new Color(1f, 1f, 1f, 0.09f);

        private static readonly Color c_start = new Color(0.10f, 0.55f, 0.28f);
        private static readonly Color c_composite = new Color(0.38f, 0.18f, 0.62f);
        private static readonly Color c_modifier = new Color(0.65f, 0.38f, 0.00f);
        private static readonly Color c_action = new Color(0.22f, 0.22f, 0.24f);
        private static readonly Color c_nodeBorder = new Color(1f, 1f, 1f, 0.12f);

        private static readonly Color c_running = new Color(0.00f, 0.90f, 0.63f);
        private static readonly Color c_success = new Color(0.27f, 0.86f, 0.50f);
        private static readonly Color c_failure = new Color(0.96f, 0.26f, 0.26f);
        private static readonly Color c_waiting = new Color(0.98f, 0.87f, 0.21f);
        private static readonly Color c_interrupted = new Color(0.98f, 0.57f, 0.18f);

        private static readonly Color c_edgeActive = new Color(0.00f, 0.80f, 0.60f, 0.85f);
        private static readonly Color c_edgeIdle = new Color(1f, 1f, 1f, 0.13f);

        private static readonly Color c_bbPanel = new Color(0.10f, 0.10f, 0.13f, 0.96f);
        private static readonly Color c_bbHeader = new Color(0.16f, 0.16f, 0.22f);

        // ── 타입 색 맵 ────────────────────────────────────────────────────────
        private static readonly Color c_bbStr = new Color(0.50f, 1.00f, 0.50f);
        private static readonly Color c_bbFlt = new Color(1.00f, 1.00f, 0.40f);
        private static readonly Color c_bbBool = new Color(0.40f, 0.90f, 1.00f);
        private static readonly Color c_bbObj = new Color(0.90f, 0.60f, 1.00f);

        // ── 상태 ──────────────────────────────────────────────────────────────
        private BehaviorGraphAgent _agent;
        private bool _autoSelect = true;
        private bool _showBBPanel = true;
        private Vector2 _pan = new Vector2(60f, 60f);
        private float _zoom = 1f;
        private bool _isPanning;
        private Vector2 _panStart;
        private Vector2 _panOrigin;

        // 계산된 노드 레이아웃 캐시
        private List<DrawNode> _drawNodes = new();
        private List<(DrawNode from, DrawNode to)> _edges = new();
        private Node _runtimeRoot;       // 마지막으로 읽은 루트 노드
        private double _lastLayoutTime;

        // 펄스 애니메이션용
        private double _time;

        // ── Reflection 캐시 ────────────────────────────────────────────────────
        private static FieldInfo s_graphsField;
        private static FieldInfo s_rootField;
        private static PropertyInfo s_childrenProp;   // Composite.Children
        private static PropertyInfo s_childProp;      // Modifier.Child / Join.Child

        // ── 노드 데이터 ────────────────────────────────────────────────────────
        private class DrawNode
        {
            public Node Runtime;
            public Rect Rect;           // 캔버스 좌표 (zoom 적용 전)
            public string Label;
            public string TypeName;
            public Color BaseColor;
            public Node.Status Status;
            public int Depth;
            public int Index;          // 같은 깊이에서의 인덱스
            public float SubtreeWidth;   // 서브트리 총 너비 (레이아웃용)
        }

        // ──────────────────────────────────────────────────────────────────────
        [MenuItem("Window/AI/Behavior Graph Viewer")]
        static void Open()
        {
            var w = GetWindow<BehaviorGraphViewer>("BG Viewer");
            w.minSize = new Vector2(600, 400);
        }

        void OnEnable()
        {
            InitReflection();
            EditorApplication.update += OnEditorUpdate;
        }

        void OnDisable()
        {
            EditorApplication.update -= OnEditorUpdate;
        }

        void OnEditorUpdate()
        {
            if (Application.isPlaying) Repaint();
        }

        // ──────────────────────────────────────────────────────────────────────
        // 메인 OnGUI
        // ──────────────────────────────────────────────────────────────────────
        void OnGUI()
        {
            _time = EditorApplication.timeSinceStartup;

            DrawToolbar();

            // 에이전트 자동 선택
            if (_autoSelect && Selection.activeGameObject != null)
            {
                var a = Selection.activeGameObject.GetComponent<BehaviorGraphAgent>();
                if (a != null && a != _agent)
                {
                    _agent = a;
                    _runtimeRoot = null;
                    _drawNodes.Clear();
                    _edges.Clear();
                    ResetView();
                }
            }

            Rect canvas = new Rect(0, TOOLBAR_H, position.width - (_showBBPanel ? BB_PANEL_W : 0f), position.height - TOOLBAR_H);

            if (!Application.isPlaying)
            {
                DrawPlaceholderMessage(canvas, "▶  플레이 모드에서 에이전트를 선택하세요");
                if (_showBBPanel) DrawBBPanel();
                return;
            }

            if (_agent == null || _agent.Graph == null)
            {
                DrawPlaceholderMessage(canvas, "BehaviorGraphAgent가 있는 오브젝트를 씬에서 선택하세요");
                if (_showBBPanel) DrawBBPanel();
                return;
            }

            // 입력 처리 (패닝/줌)
            HandleInput(canvas);

            // 그래프 읽기 + 레이아웃
            var root = GetRootNode(_agent.Graph);
            if (root != _runtimeRoot || EditorApplication.timeSinceStartup - _lastLayoutTime > 0.5)
            {
                _runtimeRoot = root;
                RebuildLayout(root);
                _lastLayoutTime = EditorApplication.timeSinceStartup;
            }
            else
            {
                // 상태만 갱신 (레이아웃 재계산 없이)
                foreach (var dn in _drawNodes)
                    dn.Status = dn.Runtime.CurrentStatus;
            }

            // 캔버스 렌더링
            GUI.BeginClip(canvas);
            DrawGrid(new Rect(0, 0, canvas.width, canvas.height));
            DrawEdges();
            DrawNodes();
            GUI.EndClip();

            // 에이전트 이름 표시
            var labelStyle = new GUIStyle(EditorStyles.boldLabel)
            {
                fontSize = 12,
                normal = { textColor = new Color(0.4f, 1f, 0.7f) }
            };
            GUI.Label(new Rect(canvas.x + 10, canvas.y + 8, 300, 20), $"🤖  {_agent.name}", labelStyle);

            if (_showBBPanel) DrawBBPanel();
        }

        // ──────────────────────────────────────────────────────────────────────
        // 툴바
        // ──────────────────────────────────────────────────────────────────────
        void DrawToolbar()
        {
            using var h = new EditorGUILayout.HorizontalScope(EditorStyles.toolbar, GUILayout.Height(TOOLBAR_H));

            _autoSelect = GUILayout.Toggle(_autoSelect, "자동 선택", EditorStyles.toolbarButton, GUILayout.Width(70));
            _showBBPanel = GUILayout.Toggle(_showBBPanel, "BB 패널", EditorStyles.toolbarButton, GUILayout.Width(60));

            if (GUILayout.Button("뷰 리셋", EditorStyles.toolbarButton, GUILayout.Width(60)))
                ResetView();

            GUILayout.Label($"줌: {_zoom:F2}x", EditorStyles.miniLabel, GUILayout.Width(65));

            if (GUILayout.Button("-", EditorStyles.toolbarButton, GUILayout.Width(22)))
                _zoom = Mathf.Clamp(_zoom - 0.1f, 0.3f, 2.5f);
            if (GUILayout.Button("+", EditorStyles.toolbarButton, GUILayout.Width(22)))
                _zoom = Mathf.Clamp(_zoom + 0.1f, 0.3f, 2.5f);

            GUILayout.FlexibleSpace();

            // 범례
            DrawLegendItem("Running", c_running);
            DrawLegendItem("Success", c_success);
            DrawLegendItem("Failure", c_failure);
            DrawLegendItem("Waiting", c_waiting);
        }

        void DrawLegendItem(string label, Color color)
        {
            var prev = GUI.color;
            GUI.color = color;
            GUILayout.Label("●", EditorStyles.miniLabel, GUILayout.Width(14));
            GUI.color = prev;
            GUILayout.Label(label, EditorStyles.miniLabel, GUILayout.Width(50));
        }

        // ──────────────────────────────────────────────────────────────────────
        // 그리드
        // ──────────────────────────────────────────────────────────────────────
        void DrawGrid(Rect area)
        {
            EditorGUI.DrawRect(area, c_bg);

            float gridSize = 24f * _zoom;
            float major = gridSize * 5f;

            float ox = (_pan.x % major);
            float oy = (_pan.y % major);

            for (float x = ox - major; x < area.width + major; x += gridSize)
            {
                bool isMajor = Mathf.Abs((x - ox) % major) < 1f;
                DrawLine(new Vector2(x, 0), new Vector2(x, area.height), isMajor ? c_gridMajor : c_grid);
            }
            for (float y = oy - major; y < area.height + major; y += gridSize)
            {
                bool isMajor = Mathf.Abs((y - oy) % major) < 1f;
                DrawLine(new Vector2(0, y), new Vector2(area.width, y), isMajor ? c_gridMajor : c_grid);
            }
        }

        // ──────────────────────────────────────────────────────────────────────
        // 레이아웃 계산 (Top-Down Tree)
        // ──────────────────────────────────────────────────────────────────────
        void RebuildLayout(Node root)
        {
            _drawNodes.Clear();
            _edges.Clear();

            if (root == null) return;

            // 1단계: 트리 순회로 DrawNode 목록 생성 + 서브트리 너비 계산
            var nodeMap = new Dictionary<Node, DrawNode>();
            var rootDn = BuildDrawNode(root, 0, nodeMap);

            // 2단계: X 좌표 할당 (서브트리 너비 기반)
            AssignPositions(rootDn, 0f);

            // 3단계: 엣지 수집
            CollectEdges(rootDn, nodeMap);
        }

        DrawNode BuildDrawNode(Node node, int depth, Dictionary<Node, DrawNode> map)
        {
            string typeName = node.GetType().Name;
            typeName = typeName.Replace("Action", "").Replace("Composite", "").Replace("Modifier", "");

            var dn = new DrawNode
            {
                Runtime = node,
                Status = node.CurrentStatus,
                TypeName = node.GetType().Name,
                Label = MakeLabel(node),
                BaseColor = GetNodeColor(node),
                Depth = depth,
            };
            _drawNodes.Add(dn);
            map[node] = dn;

            // 자식 수집
            var children = GetChildren(node);
            if (children.Count == 0)
            {
                dn.SubtreeWidth = NODE_W;
                return dn;
            }

            float totalW = 0f;
            foreach (var child in children)
            {
                var childDn = BuildDrawNode(child, depth + 1, map);
                totalW += childDn.SubtreeWidth + H_GAP;
            }
            totalW -= H_GAP;
            dn.SubtreeWidth = Mathf.Max(NODE_W, totalW);
            return dn;
        }

        void AssignPositions(DrawNode dn, float left)
        {
            float x = left + (dn.SubtreeWidth - NODE_W) / 2f;
            float y = dn.Depth * (NODE_H + V_GAP);
            dn.Rect = new Rect(_pan.x + x * _zoom, _pan.y + y * _zoom, NODE_W * _zoom, NODE_H * _zoom);

            var children = GetChildren(dn.Runtime);
            if (children.Count == 0) return;

            // 자식 DrawNode 가져오기
            var childDns = new List<DrawNode>();
            foreach (var c in children)
            {
                foreach (var d in _drawNodes)
                    if (d.Runtime == c) { childDns.Add(d); break; }
            }

            float cursor = left;
            foreach (var cdn in childDns)
            {
                AssignPositions(cdn, cursor);
                cursor += cdn.SubtreeWidth + H_GAP;
            }
        }

        void CollectEdges(DrawNode dn, Dictionary<Node, DrawNode> map)
        {
            var children = GetChildren(dn.Runtime);
            foreach (var child in children)
            {
                if (map.TryGetValue(child, out var cdn))
                {
                    _edges.Add((dn, cdn));
                    CollectEdges(cdn, map);
                }
            }
        }

        // ──────────────────────────────────────────────────────────────────────
        // 렌더링
        // ──────────────────────────────────────────────────────────────────────
        void DrawEdges()
        {
            foreach (var (from, to) in _edges)
            {
                bool active = from.Status == Node.Status.Running ||
                              from.Status == Node.Status.Waiting ||
                              to.Status == Node.Status.Running;

                Color col = active ? c_edgeActive : c_edgeIdle;
                float thick = active ? 2.5f : 1.5f;

                Vector2 start = new Vector2(from.Rect.center.x, from.Rect.yMax);
                Vector2 end = new Vector2(to.Rect.center.x, to.Rect.yMin);
                float dy = (end.y - start.y) * 0.45f;

                DrawBezier(start, start + new Vector2(0, dy), end - new Vector2(0, dy), end, col, thick);
            }
        }

        void DrawNodes()
        {
            float pulse = (float)(Math.Sin(_time * 4.0) * 0.5 + 0.5); // 0~1 진동

            foreach (var dn in _drawNodes)
            {
                Rect r = dn.Rect;

                // ── 본체 배경 ──
                EditorGUI.DrawRect(r, dn.BaseColor);

                // ── 상태 테두리 ──
                Color borderColor = c_nodeBorder;
                float borderW = 1.5f;

                switch (dn.Status)
                {
                    case Node.Status.Running:
                        borderColor = Color.Lerp(c_running, Color.white, pulse * 0.4f);
                        borderW = 2.5f + pulse * 1.5f;
                        break;
                    case Node.Status.Success:
                        borderColor = c_success; borderW = 2f; break;
                    case Node.Status.Failure:
                        borderColor = c_failure; borderW = 2f; break;
                    case Node.Status.Waiting:
                        borderColor = c_waiting; borderW = 1.5f; break;
                    case Node.Status.Interrupted:
                        borderColor = c_interrupted; borderW = 2f; break;
                }

                DrawBorder(r, borderColor, borderW);

                // ── 상태 배지 (좌측 세로 띠) ──
                if (dn.Status != Node.Status.Uninitialized)
                {
                    Rect badge = new Rect(r.x, r.y, 4f * _zoom, r.height);
                    EditorGUI.DrawRect(badge, borderColor);
                }

                // ── 실행 중 글로우 효과 ──
                if (dn.Status == Node.Status.Running)
                {
                    Rect glow = new Rect(r.x - 4, r.y - 4, r.width + 8, r.height + 8);
                    EditorGUI.DrawRect(glow, new Color(c_running.r, c_running.g, c_running.b, 0.10f * pulse));
                }

                // ── 텍스트 ──
                float fontSize = Mathf.Clamp(11f * _zoom, 7f, 15f);

                var typeStyle = new GUIStyle(EditorStyles.miniLabel)
                {
                    fontSize = (int)(fontSize * 0.85f),
                    normal = { textColor = new Color(1f, 1f, 1f, 0.45f) },
                    alignment = TextAnchor.UpperCenter,
                    clipping = TextClipping.Clip,
                };
                var labelStyle = new GUIStyle(EditorStyles.boldLabel)
                {
                    fontSize = (int)fontSize,
                    wordWrap = false,
                    alignment = TextAnchor.MiddleCenter,
                    clipping = TextClipping.Clip,
                    normal = { textColor = Color.white },
                };
                var statusStyle = new GUIStyle(EditorStyles.miniLabel)
                {
                    fontSize = (int)(fontSize * 0.80f),
                    alignment = TextAnchor.LowerCenter,
                    normal = { textColor = borderColor },
                };

                float pad = 6f * _zoom;
                Rect inner = new Rect(r.x + pad, r.y + 2, r.width - pad * 2, r.height - 4);

                GUI.Label(new Rect(inner.x, inner.y, inner.width, inner.height * 0.25f),
                    GetShortTypeName(dn.TypeName), typeStyle);
                GUI.Label(new Rect(inner.x, inner.y + inner.height * 0.22f, inner.width, inner.height * 0.52f),
                    dn.Label, labelStyle);

                if (dn.Status != Node.Status.Uninitialized)
                    GUI.Label(new Rect(inner.x, inner.y + inner.height * 0.72f, inner.width, inner.height * 0.28f),
                        dn.Status.ToString(), statusStyle);

                // ── 포트 점 ──
                float dotR = 4f * _zoom;
                EditorGUI.DrawRect(new Rect(r.center.x - dotR / 2f, r.yMin - dotR / 2f, dotR, dotR),
                    new Color(1f, 1f, 1f, 0.3f));
                EditorGUI.DrawRect(new Rect(r.center.x - dotR / 2f, r.yMax - dotR / 2f, dotR, dotR),
                    new Color(1f, 1f, 1f, 0.3f));
            }
        }

        // ──────────────────────────────────────────────────────────────────────
        // 블랙보드 패널
        // ──────────────────────────────────────────────────────────────────────
        void DrawBBPanel()
        {
            Rect panel = new Rect(position.width - BB_PANEL_W, TOOLBAR_H,
                                  BB_PANEL_W, position.height - TOOLBAR_H);
            EditorGUI.DrawRect(panel, c_bbPanel);
            EditorGUI.DrawRect(new Rect(panel.x, panel.y, 1, panel.height),
                new Color(1f, 1f, 1f, 0.1f));

            Rect header = new Rect(panel.x, panel.y, panel.width, 22f);
            EditorGUI.DrawRect(header, c_bbHeader);
            GUI.Label(new Rect(header.x + 8, header.y + 3, header.width, 16),
                "Blackboard", EditorStyles.boldLabel);

            if (_agent == null || !Application.isPlaying)
            {
                GUI.Label(new Rect(panel.x + 8, panel.y + 30, panel.width - 16, 20),
                    "에이전트 미선택", EditorStyles.miniLabel);
                return;
            }

            var bbRef = _agent?.BlackboardReference;
            if (bbRef?.Blackboard == null) return;

            float y = panel.y + 28f;
            foreach (var v in bbRef.Blackboard.Variables)
            {
                if (y + 18 > panel.y + panel.height) break;

                Color tc = GetBBTypeColor(v.Type);
                string val = FormatBBValue(v.ObjectValue);

                var nameStyle = new GUIStyle(EditorStyles.miniLabel)
                { normal = { textColor = new Color(0.8f, 0.8f, 0.8f) } };
                var valStyle = new GUIStyle(EditorStyles.miniLabel)
                { normal = { textColor = tc }, alignment = TextAnchor.MiddleRight };

                GUI.Label(new Rect(panel.x + 6, y, 100, 16), v.Name, nameStyle);
                GUI.Label(new Rect(panel.x + 105, y, panel.width - 112, 16), val, valStyle);

                y += 17f;
                EditorGUI.DrawRect(new Rect(panel.x + 4, y - 1, panel.width - 8, 1),
                    new Color(1f, 1f, 1f, 0.05f));
            }
        }

        // ──────────────────────────────────────────────────────────────────────
        // 입력 처리
        // ──────────────────────────────────────────────────────────────────────
        void HandleInput(Rect canvas)
        {
            Event e = Event.current;

            if (!canvas.Contains(e.mousePosition)) return;

            // 줌 (마우스 휠)
            if (e.type == EventType.ScrollWheel)
            {
                float delta = -e.delta.y * 0.05f;
                _zoom = Mathf.Clamp(_zoom + delta, 0.3f, 2.5f);
                e.Use();
            }

            // 패닝 (중간 버튼 또는 Alt+드래그)
            if (e.type == EventType.MouseDown && (e.button == 2 || (e.button == 0 && e.alt)))
            {
                _isPanning = true;
                _panStart = e.mousePosition;
                _panOrigin = _pan;
                e.Use();
            }
            if (_isPanning && e.type == EventType.MouseDrag)
            {
                _pan = _panOrigin + (e.mousePosition - _panStart);
                RebuildLayout(_runtimeRoot);
                e.Use();
            }
            if (e.type == EventType.MouseUp)
                _isPanning = false;
        }

        void ResetView()
        {
            _pan = new Vector2(60f, 60f);
            _zoom = 1f;
            if (_runtimeRoot != null) RebuildLayout(_runtimeRoot);
        }

        // ──────────────────────────────────────────────────────────────────────
        // Reflection — 런타임 그래프 접근
        // ──────────────────────────────────────────────────────────────────────
        static void InitReflection()
        {
            var btFlags = BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.Public;

            var bgType = typeof(BehaviorGraph);
            s_graphsField = bgType.GetField("Graphs", btFlags)
                         ?? bgType.GetField("m_Graphs", btFlags);

            // BehaviorGraphModule.Root
            var moduleType = bgType.Assembly.GetType("Unity.Behavior.BehaviorGraphModule");
            if (moduleType != null)
                s_rootField = moduleType.GetField("Root", btFlags);

            // Composite.Children (public property)
            s_childrenProp = typeof(Composite).GetProperty("Children", btFlags
                | BindingFlags.Public);

            // Modifier.Child (public property)
            s_childProp = typeof(Modifier).GetProperty("Child", btFlags
                | BindingFlags.Public);
        }

        static Node GetRootNode(BehaviorGraph graph)
        {
            if (s_graphsField == null || s_rootField == null) return null;
            var graphs = s_graphsField.GetValue(graph) as System.Collections.IList;
            if (graphs == null || graphs.Count == 0) return null;
            return s_rootField.GetValue(graphs[0]) as Node;
        }

        static List<Node> GetChildren(Node node)
        {
            var list = new List<Node>();

            // Composite.Children
            if (node is Composite comp)
            {
                list.AddRange(comp.Children);
                return list;
            }

            // Modifier.Child — Modifier 타입 직접 접근 (캐스트 안전)
            if (node is Modifier mod)
            {
                if (mod.Child != null) list.Add(mod.Child);
                return list;
            }

            // Join 등 그 외 타입 — 실제 런타임 타입에서 Child 프로퍼티 직접 조회
            // ※ s_childProp(Modifier용 캐시)를 다른 타입에 재사용하면
            //   내부에서 (Modifier)obj 캐스트 실패 → InvalidCastException 발생
            try
            {
                var childProp = node.GetType().GetProperty("Child",
                    BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);
                if (childProp != null)
                {
                    var child = childProp.GetValue(node) as Node;
                    if (child != null) list.Add(child);
                }
            }
            catch { /* 해당 타입에 Child 없음 — 무시 */ }

            return list;
        }

        // ──────────────────────────────────────────────────────────────────────
        // 헬퍼
        // ──────────────────────────────────────────────────────────────────────
        static Color GetNodeColor(Node node)
        {
            string t = node.GetType().Name;
            if (t.Contains("Start") || t.Contains("Root")) return c_start;
            if (node is Composite) return c_composite;
            if (node is Modifier) return c_modifier;
            return c_action;
        }

        static string MakeLabel(Node node)
        {
            // NodeDescription 어트리뷰트에서 스토리 텍스트 추출
            var attr = node.GetType()
                .GetCustomAttribute(typeof(NodeDescriptionAttribute), true)
                as NodeDescriptionAttribute;
            if (attr != null)
            {
                string story = attr.Story;
                if (!string.IsNullOrEmpty(story) && story.Length > 28)
                    story = story[..26] + "…";
                if (!string.IsNullOrEmpty(story)) return story;
            }
            // 어트리뷰트 없으면 타입 이름
            return GetShortTypeName(node.GetType().Name);
        }

        static string GetShortTypeName(string fullName)
        {
            return fullName
                .Replace("Action", "")
                .Replace("Composite", "")
                .Replace("Modifier", "")
                .Replace("Node", "")
                .Trim();
        }

        static Color GetBBTypeColor(Type t)
        {
            if (t == typeof(string)) return c_bbStr;
            if (t == typeof(float) || t == typeof(double)) return c_bbFlt;
            if (t == typeof(bool)) return c_bbBool;
            if (!t.IsValueType) return c_bbObj;
            return Color.white;
        }

        static string FormatBBValue(object v)
        {
            if (v == null) return "(null)";
            if (v is bool b) return b ? "✓ true" : "✗ false";
            if (v is float f) return f.ToString("F2");
            if (v is string s) return string.IsNullOrEmpty(s) ? "(빈값)" : $"\"{s}\"";
            if (v is Vector3 v3) return $"({v3.x:F1},{v3.y:F1},{v3.z:F1})";
            if (v is UnityEngine.Object uo) return uo == null ? "(null)" : uo.name;
            return v.ToString();
        }

        static void DrawPlaceholderMessage(Rect area, string msg)
        {
            EditorGUI.DrawRect(area, c_bg);
            var style = new GUIStyle(EditorStyles.centeredGreyMiniLabel) { fontSize = 12 };
            GUI.Label(new Rect(area.x, area.y + area.height / 2f - 10, area.width, 20), msg, style);
        }

        // ── 드로우 프리미티브 ────────────────────────────────────────────────
        static void DrawLine(Vector2 a, Vector2 b, Color col)
        {
            var prev = Handles.color;
            Handles.color = col;
            Handles.DrawLine(new Vector3(a.x, a.y), new Vector3(b.x, b.y));
            Handles.color = prev;
        }

        static void DrawBezier(Vector2 p0, Vector2 p1, Vector2 p2, Vector2 p3, Color col, float width)
        {
            Handles.DrawBezier(
                new Vector3(p0.x, p0.y), new Vector3(p3.x, p3.y),
                new Vector3(p1.x, p1.y), new Vector3(p2.x, p2.y),
                col, null, width);
        }

        static void DrawBorder(Rect r, Color col, float w)
        {
            // Top
            EditorGUI.DrawRect(new Rect(r.x, r.y, r.width, w), col);
            // Bottom
            EditorGUI.DrawRect(new Rect(r.x, r.yMax - w, r.width, w), col);
            // Left
            EditorGUI.DrawRect(new Rect(r.x, r.y, w, r.height), col);
            // Right
            EditorGUI.DrawRect(new Rect(r.xMax - w, r.y, w, r.height), col);
        }
    }
}
#endif
