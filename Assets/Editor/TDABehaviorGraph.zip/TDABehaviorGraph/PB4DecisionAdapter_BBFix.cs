// =============================================================================
// PB4DecisionAdapter_BBFix.cs  |  TDA Project — Patch
// Layer : L2 Router (Patch 파일 — 직접 교체하지 말고 원본에 병합하세요)
//
// ★ 이 파일은 PB4DecisionAdapter.cs 에 병합할 패치 코드 모음입니다.
//   파일 전체를 교체하는 것이 아니라 아래 표시된 부분만 수정하세요.
//
// 해결하는 문제:
//   [BB-1] 블랙보드 변수가 0 / false / 빈값으로 표시됨
//   [BB-2] combatProfile 미할당 시 StalkSpeed 등 전부 0
//   [BB-3] BehaviorGraphAgent 초기화 타이밍 불일치
//   [BB-4] Inspector에 런타임 값 미반영 (m_BlackboardOverrides 갱신 누락)
// =============================================================================

/*
   ───────────────────────────────────────────────────────────────────────────
   PATCH 1 — [BB-3] BehaviorGraphAgent 초기화 타이밍 보장
   ───────────────────────────────────────────────────────────────────────────
   
   원본 Start() 코드 (동기 실행):
   
       private void Start()
       {
           ... 컴포넌트 탐색 ...
           if (btAgent == null) Debug.LogWarning(...);
       }
   
   → BehaviorGraphAgent 의 그래프 초기화는 자신의 Awake/Start 에서 이뤄지며,
     실행 순서가 보장되지 않습니다.
   
   수정 후 (코루틴으로 교체):
*/

// ── [병합 위치] PB4DecisionAdapter 클래스 내부, Start() 메서드 교체 ──

// BEFORE (제거):
// private void Start() { ... }

// AFTER (교체):
/*
private IEnumerator Start()
{
    // [BB-3] BehaviorGraphAgent 초기화 대기 (최대 5프레임)
    // BehaviorGraphAgent.Start() 가 그래프를 Init() 하므로
    // 최소 1프레임 대기 후 btAgent 탐색을 완료합니다.
    for (int i = 0; i < 5; i++)
    {
        yield return null;
        
        if (btAgent == null)
            btAgent = GetComponent<BehaviorGraphAgent>();
        
        if (btAgent != null && btAgent.Graph != null)
            break;  // 초기화 완료 확인
    }

    // 컴포넌트 자동 탐색 (원본 코드 유지)
    if (mobBrain == null)       mobBrain       = GetComponent<MobAIBrain>();
    if (humanoidBrain == null)  humanoidBrain  = GetComponent<HumanoidAIBrain>();
    if (aiManager == null)      aiManager      = GetComponent<AICharacterManager>();

    // [Bug 2] externallyTicked 플래그
    if (mobBrain != null)      mobBrain.externallyTicked      = true;
    if (humanoidBrain != null) humanoidBrain.externallyTicked = true;

    if (btAgent == null || btAgent.Graph == null)
    {
        Debug.LogError($"[PB4Adapter] {name}: BehaviorGraphAgent 또는 Graph 를 찾을 수 없습니다. " +
                       "GameObject에 BehaviorGraphAgent 컴포넌트가 있고, " +
                       "Behavior Graph 에셋이 할당되어 있는지 확인하세요.");
        yield break;
    }

    // 초기화 성공 — BB 초기값 설정
    InitializeBlackboard();
    _bbInitialized = true;

    if (debugLog)
        Debug.Log($"[PB4Adapter] {name}: Start() 완료. BehaviorGraph 초기화 확인됨.");
}
*/

/*
   ───────────────────────────────────────────────────────────────────────────
   PATCH 2 — [BB-2] CombatProfile 미할당 시 명시적 경고 + 기본값 안전 처리
   ───────────────────────────────────────────────────────────────────────────
   
   원본 InitializeBlackboard() 내부의 combatProfile 처리:
   
       if (combatProfile != null) { SetBB(...); }
       else { Debug.LogWarning(...); }
   
   문제: 경고만 출력하고 기본값을 설정하지 않아서 BB 변수가 0으로 남음.
   
   추가할 코드 (else 블록 교체):
*/

// AFTER (else 블록 교체):
/*
else
{
    Debug.LogError(
        $"[PB4Adapter] {name}: ⛔ FactionCombatProfileSO 가 미할당입니다!\n" +
        "  → Inspector 에서 Combat Profile 필드에 SO 를 할당하세요.\n" +
        "  → 예: Skeleton_T1_CombatProfile.asset\n" +
        "  → 임시로 안전한 기본값을 BB 에 설정합니다.");
    
    // 안전한 기본값 (BT 노드가 0 으로 작동하지 않도록)
    SetBB("StalkSpeed",          3.5f);   // 기본 이동 속도
    SetBB("EngageRange",         5.0f);   // 기본 교전 범위
    SetBB("OrbitRadius",         3.0f);   // 기본 선회 반경
    SetBB("StrafeAngularSpeed", 60.0f);   // 기본 선회 각속도
    SetBB("StrikeTriggerTime",   1.5f);   // 기본 공격 트리거
    SetBB("FleeSprintSpeed",     6.0f);   // 기본 도주 속도
}
*/

/*
   ───────────────────────────────────────────────────────────────────────────
   PATCH 3 — [BB-1] Update() 에서 _bbInitialized 중복 초기화 제거
   ───────────────────────────────────────────────────────────────────────────
   
   Patch 1 을 적용하면 Start() 코루틴이 InitializeBlackboard() 를 직접 호출하고
   _bbInitialized = true 를 설정합니다.
   
   따라서 Update() 내부의 지연 초기화 블록은 제거합니다:
*/

// BEFORE (제거):
/*
if (!_bbInitialized && btAgent != null)
{
    InitializeBlackboard();
    _bbInitialized = true;
}
*/

// AFTER (제거 후 단순 가드로 교체):
/*
if (!_bbInitialized) return;  // 코루틴 초기화 완료 전 조기 반환
*/

/*
   ───────────────────────────────────────────────────────────────────────────
   PATCH 4 — [BB-4] Inspector 실시간 표시를 위한 추가 진단 헬퍼
   ───────────────────────────────────────────────────────────────────────────
   
   아래 메서드를 PB4DecisionAdapter 클래스에 추가합니다.
   Inspector 상단에 "진단 실행" 버튼 없이도 OnValidate 에서 자동 확인합니다.
*/

// PB4DecisionAdapter 클래스 내부에 추가:
/*
#if UNITY_EDITOR
/// <summary>
/// Inspector 에서 "Diagnose BB" 버튼 클릭 시 또는 컨텍스트 메뉴에서 실행.
/// 플레이 모드 중 BB 상태를 Console 에 상세 출력합니다.
/// </summary>
[ContextMenu("Diagnose Blackboard")]
private void DiagnoseBlackboard()
{
    if (!Application.isPlaying)
    {
        Debug.LogWarning("[PB4Adapter] DiagnoseBlackboard 는 플레이 모드에서만 실행 가능합니다.");
        return;
    }
    
    if (btAgent == null)
    {
        Debug.LogError($"[PB4Adapter] {name}: btAgent 가 null 입니다.");
        return;
    }
    
    var bbRef = btAgent.BlackboardReference;
    if (bbRef?.Blackboard == null)
    {
        Debug.LogError($"[PB4Adapter] {name}: BlackboardReference 또는 Blackboard 가 null 입니다.");
        return;
    }
    
    Debug.Log($"[BB진단] ===== {name} 블랙보드 상태 =====");
    Debug.Log($"[BB진단] Graph 초기화: {(btAgent.Graph != null ? "✓" : "✗ NULL")}");
    Debug.Log($"[BB진단] _bbInitialized: {_bbInitialized}");
    Debug.Log($"[BB진단] combatProfile: {(combatProfile != null ? combatProfile.name : "✗ NULL — Inspector 할당 필요")}");
    Debug.Log($"[BB진단] mobBrain: {(mobBrain != null ? "✓ " + mobBrain.name : "없음 (humanoidBrain 사용?)")}");
    
    Debug.Log("[BB진단] --- 변수 목록 ---");
    foreach (var v in bbRef.Blackboard.Variables)
    {
        string valStr = v.ObjectValue?.ToString() ?? "(null)";
        bool isEmpty = v.ObjectValue == null 
                    || valStr == "0" 
                    || valStr == "False" 
                    || valStr == "";
        string flag = isEmpty ? " ⚠️ 기본값" : " ✓";
        Debug.Log($"[BB진단]   {v.Type.Name,-15} {v.Name,-20} = {valStr}{flag}");
    }
    
    Debug.Log("[BB진단] ===================");
}
#endif
*/
