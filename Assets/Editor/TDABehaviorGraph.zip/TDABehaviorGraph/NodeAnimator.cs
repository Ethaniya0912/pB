// =============================================================================
// NodeAnimator.cs  |  TDA Project
// Layer  : Editor Tooling
// Phase  : 3 (상태 아이콘 애니메이션)
//
// 역할:
//   Unity Behavior Graph 에디터에서 실행 중인 노드의 DebugIcon에
//   opacity sin파 애니메이션을 적용합니다.
//   Running 상태 노드가 정적으로 보이는 문제를 해결합니다.
//
// 설계 원칙 (이중 비판·재검증 반영):
//   [D-A]  독립 파일 유지 — inner class 통합 시 SRP 위반
//   [C-06] 이벤트 기반 노드 목록 관리 — 매 프레임 O(n) 전체 트리 순회 제거
//          ViewState.ViewStateUpdated 구독 → 노드 추가/삭제 시에만 목록 갱신
//   [C-07] _toRemove 재사용 리스트 — GC 할당 최소화
//   [C-08] panel null 체크 — Until() 람다 안전
//   [D-04] _toRemove 재사용 List<int> — 매 호출마다 ToList() GC 방지
//
// 애니메이션 방식:
//   - CSS @keyframes 미지원 → C# IVisualElementScheduledItem 사용
//   - opacity만 변경 (layout dirty 없음, 성능 영향 최소)
//   - scale은 Success/Failure에 한해 USS transition으로만 처리
//
// 접근 방식:
//   BehaviorNodeUI는 internal → GetType().Name 문자열 비교로 탐색
//   ViewState는 internal → Reflection으로 ViewStateUpdated 이벤트 구독
//   DebugIcon은 Q("DebugIcon") 이름 탐색 (USS #DebugIcon 확인)
//
// 의존성:
//   - BehaviorGraphEditorEnhancer.cs 가 생성·보유합니다
//   - CustomBehaviorTheme.uss의 Success/Failure CSS transition과 병행 동작
// =============================================================================

#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using System.Reflection;
using UnityEditor;
using UnityEngine;
using UnityEngine.UIElements;

namespace TDA.Editor
{
    /// <summary>
    /// Behavior Graph 에디터의 노드 상태 아이콘에 동적 애니메이션을 적용합니다.
    /// Running 상태 노드의 DebugIcon에 opacity sin파를 적용하여
    /// 현재 실행 중인 노드를 시각적으로 강조합니다.
    /// </summary>
    /// <remarks>
    /// BehaviorGraphEditorEnhancer가 BehaviorGraphEditor VisualElement를
    /// 발견했을 때 인스턴스를 생성합니다.
    /// </remarks>
    public sealed class NodeAnimator
    {
        // ─────────────────────────────────────────────────────────────────────
        // 상수
        // ─────────────────────────────────────────────────────────────────────

        /// <summary>
        /// BehaviorNodeUI 타입 이름 (internal 클래스 — 문자열 비교로 탐색).
        /// Unity Behavior 패키지 버전 업 시 변경될 수 있습니다.
        /// </summary>
        private const string k_NodeUITypeName = "BehaviorNodeUI";

        /// <summary>
        /// Running 상태를 나타내는 CSS 클래스명.
        /// BehaviorNodeUI.UpdateStatus()에서 EnableInClassList로 토글됩니다.
        /// </summary>
        private const string k_RunningClass = "NodeStatus_Running";

        /// <summary>
        /// DebugIcon VisualElement의 이름 (USS #DebugIcon 및 소스 Q("DebugIcon") 확인).
        /// </summary>
        private const string k_DebugIconName = "DebugIcon";

        /// <summary>
        /// 상태 스캔 주기 (ms). Running 여부를 감지합니다.
        /// BT 상태 변경이 0.5초 단위이므로 50ms는 충분히 빠릅니다.
        /// </summary>
        private const int k_ScanIntervalMs = 50;

        /// <summary>
        /// opacity 애니메이션 주기 (ms). ~60fps에 해당합니다.
        /// </summary>
        private const int k_AnimIntervalMs = 16;

        /// <summary>
        /// opacity sin파 최솟값. 너무 낮으면 아이콘이 사라져 보일 수 있습니다.
        /// </summary>
        private const float k_OpacityMin = 0.45f;

        /// <summary>
        /// opacity sin파 최댓값.
        /// </summary>
        private const float k_OpacityMax = 1.00f;

        /// <summary>
        /// sin파 속도 계수. 값이 클수록 빠르게 진동합니다.
        /// </summary>
        private const float k_AnimSpeed = 0.28f;

        // ─────────────────────────────────────────────────────────────────────
        // 상태 필드
        // ─────────────────────────────────────────────────────────────────────

        /// <summary>BehaviorGraphEditor VisualElement (루트).</summary>
        private readonly VisualElement _bge;

        /// <summary>BehaviorGraphView VisualElement (캔버스).</summary>
        private VisualElement _graphView;

        /// <summary>
        /// ViewStateUpdated 이벤트 구독 해제 델리게이트.
        /// Dispose 시 구독을 정리합니다.
        /// </summary>
        private Action _unsubscribeViewState;

        /// <summary>
        /// 현재 에디터에서 알려진 BehaviorNodeUI 목록.
        /// ViewStateUpdated 이벤트에서만 갱신합니다 (이벤트 기반 — C-06 수정).
        /// </summary>
        private readonly List<VisualElement> _knownNodes = new();

        /// <summary>
        /// 노드 VisualElement 해시 → 스케줄러 매핑.
        /// GetHashCode()는 참조 기반이므로 같은 인스턴스는 같은 해시를 반환합니다.
        /// </summary>
        private readonly Dictionary<int, IVisualElementScheduledItem> _animTasks = new();

        /// <summary>
        /// 스캔 루프에서 제거할 ID 목록.
        /// 매 호출마다 재사용하여 GC 할당을 방지합니다 (D-04 수정).
        /// </summary>
        private readonly List<int> _toRemove = new();

        /// <summary>sin파 타이머 카운터. 애니메이션 콜백마다 증가합니다.</summary>
        private float _t;

        /// <summary>스캔 스케줄러 인스턴스. Dispose 시 중단합니다.</summary>
        private IVisualElementScheduledItem _scanTask;

        // ─────────────────────────────────────────────────────────────────────
        // Reflection 캐시
        // ─────────────────────────────────────────────────────────────────────

        /// <summary>GraphView.ViewState 프로퍼티 (1회 캐시).</summary>
        private static PropertyInfo s_viewStateProp;

        /// <summary>ViewState.ViewStateUpdated 이벤트 (1회 캐시).</summary>
        private static EventInfo s_viewStateUpdatedEvt;

        /// <summary>ViewState.Nodes 프로퍼티 (1회 캐시).</summary>
        private static PropertyInfo s_nodesProp;

        // ─────────────────────────────────────────────────────────────────────
        // 생성자
        // ─────────────────────────────────────────────────────────────────────

        /// <summary>
        /// NodeAnimator를 초기화합니다.
        /// BehaviorGraphView를 탐색하고 ViewStateUpdated 이벤트를 구독합니다.
        /// 이후 주기적 스캔 스케줄러를 시작합니다.
        /// </summary>
        /// <param name="bge">BehaviorGraphEditor VisualElement.</param>
        /// <exception cref="ArgumentNullException"><paramref name="bge"/>가 null인 경우.</exception>
        public NodeAnimator(VisualElement bge)
        {
            _bge = bge ?? throw new ArgumentNullException(nameof(bge));

            // BehaviorGraphView 탐색
            _graphView = FindGraphView(bge);
            if (_graphView == null)
            {
                Debug.LogWarning(
                    "[NodeAnimator] BehaviorGraphView를 찾을 수 없습니다.\n" +
                    "CSS 클래스 'BehaviorGraphView'가 없거나 탐색 시점이 너무 이릅니다.\n" +
                    "BehaviorGraphEditorEnhancer가 BGE 완전 초기화 후에 NodeAnimator를 생성하는지 확인하세요.");
                return;
            }

            // ViewStateUpdated 이벤트 구독 시도
            bool subscribed = TrySubscribeViewStateUpdated(_graphView);
            if (!subscribed)
            {
                Debug.LogWarning(
                    "[NodeAnimator] ViewStateUpdated 이벤트 구독 실패.\n" +
                    "GraphFramework 버전이 변경됐을 수 있습니다.\n" +
                    "초기 노드 목록을 전체 탐색으로 구성합니다.");
            }

            // 초기 노드 목록 구성 (이벤트 구독 성공 여부와 관계없이 실행)
            RefreshKnownNodes();

            // 주기적 스캔 시작 (Running 상태 변화 감지)
            _scanTask = _bge.schedule
                .Execute(ScanKnownNodes)
                .Every(k_ScanIntervalMs);

            Debug.Log(
                $"[NodeAnimator] 초기화 완료. " +
                $"알려진 노드: {_knownNodes.Count}개, " +
                $"ViewStateUpdated 구독: {(subscribed ? "성공" : "실패 (폴링 폴백)")}");
        }

        // ─────────────────────────────────────────────────────────────────────
        // ViewStateUpdated 이벤트 구독
        // ─────────────────────────────────────────────────────────────────────

        /// <summary>
        /// BehaviorGraphView의 ViewState.ViewStateUpdated 이벤트에 구독합니다.
        /// 노드 추가/삭제 시에만 _knownNodes 목록을 갱신하여
        /// 매 스캔마다 O(n) 전체 트리 순회를 피합니다.
        /// </summary>
        /// <param name="graphView">BehaviorGraphView VisualElement.</param>
        /// <returns>구독 성공 여부.</returns>
        private bool TrySubscribeViewStateUpdated(VisualElement graphView)
        {
            try
            {
                var flags = BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance;

                // ViewState 프로퍼티 획득 (GraphView 기반 클래스에 있음)
                s_viewStateProp ??= FindPropertyInHierarchy(
                    graphView.GetType(), "ViewState", flags);

                if (s_viewStateProp == null) return false;

                var viewState = s_viewStateProp.GetValue(graphView);
                if (viewState == null) return false;

                // ViewStateUpdated 이벤트 획득
                // 소스 확인: OnGraphViewUpdated() — 파라미터 없음 → Action 시그니처
                s_viewStateUpdatedEvt ??= viewState.GetType()
                    .GetEvent("ViewStateUpdated", flags);

                if (s_viewStateUpdatedEvt == null) return false;

                // 핸들러 생성 및 구독
                // ViewStateUpdated는 Action이므로 파라미터 없는 메서드로 바인딩
                var handler = Delegate.CreateDelegate(
                    s_viewStateUpdatedEvt.EventHandlerType,
                    this,
                    nameof(OnViewStateUpdated));

                s_viewStateUpdatedEvt.AddEventHandler(viewState, handler);

                // Dispose를 위해 구독 해제 람다 저장
                _unsubscribeViewState = () =>
                {
                    try
                    {
                        var vs = s_viewStateProp?.GetValue(graphView);
                        if (vs != null)
                            s_viewStateUpdatedEvt?.RemoveEventHandler(vs, handler);
                    }
                    catch { /* 창이 닫힌 후 호출될 수 있음 — 무시 */ }
                };

                return true;
            }
            catch (Exception ex)
            {
                Debug.LogWarning(
                    $"[NodeAnimator] ViewStateUpdated 구독 중 예외 발생: {ex.Message}\n" +
                    "폴링 방식으로 폴백합니다.");
                return false;
            }
        }

        /// <summary>
        /// 타입 계층을 따라 올라가며 지정된 이름의 프로퍼티를 탐색합니다.
        /// GraphFramework의 base class에 ViewState가 있을 수 있으므로 필요합니다.
        /// </summary>
        private static PropertyInfo FindPropertyInHierarchy(
            Type type, string name, BindingFlags flags)
        {
            while (type != null && type != typeof(object))
            {
                var prop = type.GetProperty(name, flags);
                if (prop != null) return prop;
                type = type.BaseType;
            }
            return null;
        }

        // ─────────────────────────────────────────────────────────────────────
        // 노드 목록 관리
        // ─────────────────────────────────────────────────────────────────────

        /// <summary>
        /// ViewStateUpdated 이벤트 핸들러.
        /// 노드가 추가 또는 삭제될 때 호출됩니다.
        /// 이 시점에만 O(n) 전체 트리 순회를 수행합니다.
        /// </summary>
        private void OnViewStateUpdated()
        {
            RefreshKnownNodes();
        }

        /// <summary>
        /// BehaviorGraphView에서 모든 BehaviorNodeUI를 탐색하여
        /// _knownNodes 목록을 최신화합니다.
        /// ViewStateUpdated 이벤트에서 호출되므로 호출 빈도가 낮습니다.
        /// </summary>
        private void RefreshKnownNodes()
        {
            _knownNodes.Clear();

            if (_graphView == null) return;

            // BehaviorNodeUI는 internal → 타입명 문자열 비교
            _graphView.Query<VisualElement>()
                .Where(e => e.GetType().Name == k_NodeUITypeName)
                .ForEach(n => _knownNodes.Add(n));
        }

        // ─────────────────────────────────────────────────────────────────────
        // 주기적 스캔 (50ms)
        // ─────────────────────────────────────────────────────────────────────

        /// <summary>
        /// _knownNodes만 순회하여 Running 상태 변화를 감지하고
        /// 애니메이션 스케줄러를 시작/중단합니다.
        /// ViewStateUpdated 실패 시 이 메서드에서 직접 노드를 폴링합니다.
        /// </summary>
        private void ScanKnownNodes()
        {
            // ViewStateUpdated 구독에 실패한 경우 폴링 폴백
            // (이미 구독에 성공했다면 _knownNodes는 이벤트로 갱신되므로 여기서 갱신 불필요)
            if (_unsubscribeViewState == null)
                RefreshKnownNodes();

            var liveHashes = new HashSet<int>(); // 이번 스캔에서 살아있는 노드 해시

            foreach (var nodeUI in _knownNodes)
            {
                // 패널에서 분리된 노드 스킵 (삭제되거나 숨겨진 경우)
                if (nodeUI?.panel == null) continue;

                int id = nodeUI.GetHashCode();
                liveHashes.Add(id);

                bool isRunning = nodeUI.ClassListContains(k_RunningClass);

                if (isRunning && !_animTasks.ContainsKey(id))
                    StartPulse(nodeUI, id);
                else if (!isRunning && _animTasks.ContainsKey(id))
                    StopPulse(id, nodeUI);
            }

            // 사라진 노드(재생성·삭제)의 스케줄러 정리 — 메모리 누수 방지 (C-07 수정)
            _toRemove.Clear();
            foreach (var id in _animTasks.Keys)
                if (!liveHashes.Contains(id))
                    _toRemove.Add(id);

            foreach (var id in _toRemove)
            {
                _animTasks[id]?.Pause();
                _animTasks.Remove(id);
            }
        }

        // ─────────────────────────────────────────────────────────────────────
        // 애니메이션 시작 / 중단
        // ─────────────────────────────────────────────────────────────────────

        /// <summary>
        /// 지정된 노드의 DebugIcon에 opacity sin파 애니메이션을 시작합니다.
        /// </summary>
        /// <param name="nodeUI">대상 BehaviorNodeUI VisualElement.</param>
        /// <param name="id">nodeUI.GetHashCode() — 딕셔너리 키.</param>
        private void StartPulse(VisualElement nodeUI, int id)
        {
            // DebugIcon 탐색 (USS에서 #DebugIcon 이름 확인)
            var icon = nodeUI.Q(k_DebugIconName);
            if (icon == null)
            {
                // DebugIconContainer → DebugIcon 순서로 재탐색
                var container = nodeUI.Q("DebugIconContainer");
                icon = container?.Q(k_DebugIconName);
            }

            if (icon == null) return;

            // sin파 타이머 초기화 (각 노드 독립적으로 관리)
            // 모든 노드가 같은 위상이면 동기화된 느낌이 나므로 약간의 오프셋 추가
            float phaseOffset = (id % 13) * 0.5f; // 해시 기반 위상 오프셋

            // 애니메이션 스케줄러 (약 60fps)
            // Until 조건: 패널에서 분리되거나 Running 상태가 아닐 때 자동 중단 (C-08 수정)
            var task = icon.schedule.Execute(() =>
            {
                // panel null 체크 — 분리된 VisualElement 접근 방지 (C-08 수정)
                if (icon.panel == null) return;

                float v = Mathf.Sin((_t + phaseOffset) * k_AnimSpeed);
                float opacity = Mathf.Lerp(k_OpacityMin, k_OpacityMax, v * 0.5f + 0.5f);
                icon.style.opacity = opacity;
                _t += 1f;
            })
            .Every(k_AnimIntervalMs)
            .Until(() =>
                icon.panel == null ||
                !nodeUI.ClassListContains(k_RunningClass));

            _animTasks[id] = task;
        }

        /// <summary>
        /// 지정된 노드의 DebugIcon 애니메이션을 중단하고 opacity를 복원합니다.
        /// </summary>
        /// <param name="id">딕셔너리 키.</param>
        /// <param name="nodeUI">대상 VisualElement (opacity 복원용).</param>
        private void StopPulse(int id, VisualElement nodeUI)
        {
            _animTasks[id]?.Pause();
            _animTasks.Remove(id);

            // opacity 복원 — 완전 불투명으로 되돌림
            var icon = nodeUI?.Q(k_DebugIconName)
                    ?? nodeUI?.Q("DebugIconContainer")?.Q(k_DebugIconName);

            if (icon != null && icon.panel != null)
                icon.style.opacity = 1f;
        }

        // ─────────────────────────────────────────────────────────────────────
        // 탐색 헬퍼
        // ─────────────────────────────────────────────────────────────────────

        /// <summary>
        /// BehaviorGraphEditor 내에서 BehaviorGraphView를 탐색합니다.
        /// CSS 클래스 'BehaviorGraphView'를 기준으로 탐색합니다
        /// (BehaviorGraphView.cs 53번 줄: AddToClassList("BehaviorGraphView") 확인).
        /// </summary>
        private static VisualElement FindGraphView(VisualElement bge)
        {
            return bge?.Q<VisualElement>(className: "BehaviorGraphView");
        }

        // ─────────────────────────────────────────────────────────────────────
        // 정리
        // ─────────────────────────────────────────────────────────────────────

        /// <summary>
        /// 모든 스케줄러와 이벤트 구독을 정리합니다.
        /// BehaviorGraphEditorEnhancer가 창을 닫을 때 호출해야 합니다.
        /// </summary>
        public void Dispose()
        {
            // 스캔 스케줄러 중단
            _scanTask?.Pause();

            // 모든 애니메이션 스케줄러 중단
            foreach (var task in _animTasks.Values)
                task?.Pause();
            _animTasks.Clear();

            // ViewStateUpdated 구독 해제
            _unsubscribeViewState?.Invoke();
            _unsubscribeViewState = null;

            _knownNodes.Clear();
        }
    }
}
#endif
