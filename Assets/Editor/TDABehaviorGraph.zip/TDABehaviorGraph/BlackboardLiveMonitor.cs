// =============================================================================
// BlackboardLiveMonitor.cs  |  TDA Project
// Layer : Editor Tooling (Window > AI > Blackboard Live Monitor)
//
// 역할:
//   플레이 모드 중 BehaviorGraphAgent의 Blackboard 변수 값을
//   실시간으로 모니터링하는 EditorWindow.
//
// 기능:
//   - 선택한 GameObject의 BehaviorGraphAgent BB 변수 전체 표시
//   - 타입별 색상 구분 (string=초록, float=노랑, bool=청록, 나머지=흰색)
//   - 값 변경 시 1초간 행 강조 (변경 감지)
//   - 유틸리티 점수 (UtilityWinner / Fear / HasTarget) 상단 고정 표시
//   - SetVariableValue 실패 감지 경고
//   - 변수 필터 검색 박스
//   - 자동 선택 모드 (플레이 중 선택 변경 시 자동 전환)
//
// 사용:
//   상단 메뉴 Window > AI > Blackboard Live Monitor
//   플레이 모드 진입 후 Skeleton_01 등 AI 오브젝트를 씬에서 선택하면 표시
// =============================================================================
using System;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;
using Unity.Behavior;

namespace TDA.Editor
{
    public class BlackboardLiveMonitor : EditorWindow
    {
        // ── UI 상태 ──
        private BehaviorGraphAgent _target;
        private string _filterText = "";
        private Vector2 _scroll;
        private bool _autoSelect = true;
        private bool _showTypeColumn = true;

        // ── 변경 감지용 ──
        private readonly Dictionary<string, object> _prevValues = new();
        private readonly Dictionary<string, double> _changedAt = new();
        private const double k_HighlightDuration = 1.0;

        // ── 타입별 색상 ──
        private static readonly Color c_String = new Color(0.5f, 1.0f, 0.5f);
        private static readonly Color c_Float = new Color(1.0f, 1.0f, 0.4f);
        private static readonly Color c_Int = new Color(1.0f, 0.8f, 0.4f);
        private static readonly Color c_Bool = new Color(0.4f, 0.9f, 1.0f);
        private static readonly Color c_Object = new Color(0.9f, 0.6f, 1.0f);
        private static readonly Color c_Default = Color.white;

        // ── 우선 표시 변수 (상단 고정) ──
        private static readonly HashSet<string> k_PriorityVars = new()
        {
            "UtilityWinner", "HasTarget", "Fear", "Target",
            "PolicyType", "EngageRange", "StalkSpeed"
        };

        [MenuItem("Window/AI/Blackboard Live Monitor")]
        static void Open()
        {
            var w = GetWindow<BlackboardLiveMonitor>("BB Monitor");
            w.minSize = new Vector2(380, 300);
        }

        // ─────────────────────────────────────────────────────────────────────
        // 헤더 + 컨트롤
        // ─────────────────────────────────────────────────────────────────────
        void OnGUI()
        {
            DrawToolbar();

            if (!Application.isPlaying)
            {
                DrawCenteredMessage("▶ 플레이 모드에서만 동작합니다");
                return;
            }

            // 자동 선택
            if (_autoSelect && Selection.activeGameObject != null)
            {
                var agent = Selection.activeGameObject.GetComponent<BehaviorGraphAgent>();
                if (agent != null && agent != _target)
                {
                    _target = agent;
                    _prevValues.Clear();
                    _changedAt.Clear();
                }
            }

            if (_target == null)
            {
                DrawCenteredMessage("BehaviorGraphAgent 가 있는 오브젝트를 씬에서 선택하세요");
                return;
            }

            DrawTargetHeader();
            DrawVariableTable();

            Repaint();  // 매 프레임 갱신
        }

        // ─────────────────────────────────────────────────────────────────────
        // Toolbar
        // ─────────────────────────────────────────────────────────────────────
        void DrawToolbar()
        {
            using var h = new EditorGUILayout.HorizontalScope(EditorStyles.toolbar);

            // 자동 선택 토글
            _autoSelect = GUILayout.Toggle(_autoSelect, "자동 선택", EditorStyles.toolbarButton, GUILayout.Width(70));

            // 타입 컬럼 토글
            _showTypeColumn = GUILayout.Toggle(_showTypeColumn, "타입 표시", EditorStyles.toolbarButton, GUILayout.Width(70));

            GUILayout.FlexibleSpace();

            // 검색 필터
            GUILayout.Label("필터:", EditorStyles.miniLabel, GUILayout.Width(30));
            _filterText = EditorGUILayout.TextField(_filterText, EditorStyles.toolbarSearchField, GUILayout.Width(150));

            // 수동 선택 버튼
            if (GUILayout.Button("대상 고정", EditorStyles.toolbarButton, GUILayout.Width(60)))
            {
                if (Selection.activeGameObject != null)
                    _target = Selection.activeGameObject.GetComponent<BehaviorGraphAgent>();
                _autoSelect = false;
            }

            // 클리어
            if (GUILayout.Button("클리어", EditorStyles.toolbarButton, GUILayout.Width(50)))
            {
                _target = null;
                _prevValues.Clear();
                _changedAt.Clear();
            }
        }

        // ─────────────────────────────────────────────────────────────────────
        // 대상 헤더
        // ─────────────────────────────────────────────────────────────────────
        void DrawTargetHeader()
        {
            EditorGUILayout.Space(4);
            var agentStyle = new GUIStyle(EditorStyles.boldLabel) { fontSize = 13 };
            Color prev = GUI.color;
            GUI.color = new Color(0.4f, 1f, 0.7f);
            EditorGUILayout.LabelField($"🤖  {_target.name}", agentStyle);
            GUI.color = prev;

            // Graph 초기화 여부 확인
            if (_target.Graph == null)
            {
                EditorGUILayout.HelpBox("Graph가 아직 초기화되지 않았습니다 (첫 Update 대기 중)", MessageType.Warning);
                return;
            }

            EditorGUILayout.Space(2);
        }

        // ─────────────────────────────────────────────────────────────────────
        // 변수 테이블
        // ─────────────────────────────────────────────────────────────────────
        void DrawVariableTable()
        {
            var bbRef = _target.BlackboardReference;
            if (bbRef?.Blackboard == null)
            {
                EditorGUILayout.HelpBox("BlackboardReference 가 null입니다.", MessageType.Error);
                return;
            }

            var variables = bbRef.Blackboard.Variables;
            if (variables == null || variables.Count == 0)
            {
                EditorGUILayout.HelpBox("Blackboard에 변수가 없습니다.", MessageType.Info);
                return;
            }

            // 컬럼 헤더
            DrawColumnHeader();

            _scroll = EditorGUILayout.BeginScrollView(_scroll);

            // 1) 우선 표시 변수 (priority 섹션)
            bool drewSection = false;
            foreach (var variable in variables)
            {
                if (!k_PriorityVars.Contains(variable.Name)) continue;
                if (!PassFilter(variable.Name)) continue;
                if (!drewSection) { DrawSectionLabel("▶  핵심 변수 (UtilityAI)"); drewSection = true; }
                DrawVariableRow(variable, priority: true);
            }

            // 2) 나머지 변수
            drewSection = false;
            foreach (var variable in variables)
            {
                if (k_PriorityVars.Contains(variable.Name)) continue;
                if (!PassFilter(variable.Name)) continue;
                if (!drewSection) { DrawSectionLabel("▶  기타 변수"); drewSection = true; }
                DrawVariableRow(variable, priority: false);
            }

            EditorGUILayout.EndScrollView();
        }

        // ─────────────────────────────────────────────────────────────────────
        // 컬럼 헤더 행
        // ─────────────────────────────────────────────────────────────────────
        void DrawColumnHeader()
        {
            var headerStyle = new GUIStyle(EditorStyles.miniLabel)
            {
                fontStyle = FontStyle.Bold,
                normal = { textColor = new Color(0.7f, 0.7f, 0.7f) }
            };
            using var h = new EditorGUILayout.HorizontalScope();
            if (_showTypeColumn)
                GUILayout.Label("타입", headerStyle, GUILayout.Width(80));
            GUILayout.Label("변수명", headerStyle, GUILayout.Width(160));
            GUILayout.Label("현재 값", headerStyle);
            EditorGUILayout.Space(2);
        }

        // ─────────────────────────────────────────────────────────────────────
        // 섹션 레이블
        // ─────────────────────────────────────────────────────────────────────
        void DrawSectionLabel(string text)
        {
            EditorGUILayout.Space(6);
            var s = new GUIStyle(EditorStyles.miniLabel)
            {
                fontStyle = FontStyle.Bold,
                normal = { textColor = new Color(0.5f, 0.8f, 1f) }
            };
            EditorGUILayout.LabelField(text, s);
            var rect = GUILayoutUtility.GetLastRect();
            rect.y += rect.height;
            rect.height = 1;
            EditorGUI.DrawRect(rect, new Color(0.5f, 0.8f, 1f, 0.25f));
            EditorGUILayout.Space(2);
        }

        // ─────────────────────────────────────────────────────────────────────
        // 개별 변수 행
        // ─────────────────────────────────────────────────────────────────────
        void DrawVariableRow(BlackboardVariable variable, bool priority)
        {
            string name = variable.Name;
            object value = variable.ObjectValue;
            Type type = variable.Type;

            // 변경 감지
            bool changed = false;
            if (_prevValues.TryGetValue(name, out var prev))
            {
                if (!Equals(prev, value))
                {
                    _changedAt[name] = EditorApplication.timeSinceStartup;
                    changed = true;
                }
            }
            _prevValues[name] = value;

            // 변경 하이라이트 여부
            bool isHighlighted = _changedAt.TryGetValue(name, out double changedTime) &&
                                  (EditorApplication.timeSinceStartup - changedTime) < k_HighlightDuration;

            // 배경 색
            var rowRect = EditorGUILayout.BeginHorizontal();
            if (isHighlighted)
            {
                float t = 1f - (float)((EditorApplication.timeSinceStartup - changedTime) / k_HighlightDuration);
                EditorGUI.DrawRect(rowRect, new Color(1f, 0.9f, 0.2f, 0.15f * t));
            }
            else if (priority)
            {
                EditorGUI.DrawRect(rowRect, new Color(1f, 1f, 1f, 0.03f));
            }

            Color typeColor = GetTypeColor(type);
            Color prevColor = GUI.color;

            // 타입 컬럼
            if (_showTypeColumn)
            {
                GUI.color = typeColor * 0.8f;
                GUILayout.Label($"[{GetShortTypeName(type)}]",
                    EditorStyles.miniLabel, GUILayout.Width(80));
            }

            // 변수명
            GUI.color = priority ? new Color(1f, 1f, 0.8f) : Color.white;
            GUILayout.Label(name, EditorStyles.miniLabel, GUILayout.Width(160));

            // 값
            GUI.color = isHighlighted ? new Color(1f, 0.9f, 0.3f) : typeColor;
            string displayValue = FormatValue(value);
            GUILayout.Label(displayValue, EditorStyles.miniLabel);

            GUI.color = prevColor;
            EditorGUILayout.EndHorizontal();
        }

        // ─────────────────────────────────────────────────────────────────────
        // 헬퍼
        // ─────────────────────────────────────────────────────────────────────
        bool PassFilter(string name) =>
            string.IsNullOrEmpty(_filterText) ||
            name.IndexOf(_filterText, StringComparison.OrdinalIgnoreCase) >= 0;

        static Color GetTypeColor(Type t)
        {
            if (t == typeof(string)) return c_String;
            if (t == typeof(float) ||
                t == typeof(double)) return c_Float;
            if (t == typeof(int) ||
                t == typeof(long)) return c_Int;
            if (t == typeof(bool)) return c_Bool;
            if (!t.IsValueType) return c_Object;  // 참조 타입 (GameObject, Transform 등)
            return c_Default;
        }

        static string GetShortTypeName(Type t)
        {
            if (t == typeof(string)) return "str";
            if (t == typeof(float)) return "float";
            if (t == typeof(double)) return "double";
            if (t == typeof(int)) return "int";
            if (t == typeof(bool)) return "bool";
            if (t == typeof(GameObject)) return "GO";
            if (t == typeof(Transform)) return "Tfm";
            return t.Name.Length > 8 ? t.Name[..8] : t.Name;
        }

        static string FormatValue(object v)
        {
            if (v == null) return "(null)";
            if (v is bool b) return b ? "✓ true" : "✗ false";
            if (v is float f) return f.ToString("F3");
            if (v is double d) return d.ToString("F3");
            if (v is string s) return string.IsNullOrEmpty(s) ? "(빈 문자열)" : $"\"{s}\"";
            if (v is UnityEngine.Object uo) return uo == null ? "(destroyed)" : uo.name;
            return v.ToString();
        }

        static void DrawCenteredMessage(string msg)
        {
            GUILayout.FlexibleSpace();
            using var h = new EditorGUILayout.HorizontalScope();
            GUILayout.FlexibleSpace();
            GUILayout.Label(msg, EditorStyles.centeredGreyMiniLabel);
            GUILayout.FlexibleSpace();
            GUILayout.FlexibleSpace();
        }
    }
}