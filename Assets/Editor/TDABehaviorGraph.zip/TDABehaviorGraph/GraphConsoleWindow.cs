// =============================================================================
// GraphConsoleWindow.cs  |  TDA Project
// Layer  : Editor Tooling
// Phase  : 5 (Graph Console — 실패 노드 탐색)
//
// 역할:
//   플레이 모드 중 Behavior Graph에서 Failure·Interrupted 상태인 노드를
//   실시간으로 목록에 표시하고, 클릭 시 해당 노드로 뷰포트를 이동합니다.
//   NodeCanvas의 Graph Console 기능을 참고한 Unity Behavior Graph 전용 구현입니다.
//
// 열기: Window > AI > Graph Console
//
// 기능:
//   - 선택된 BehaviorGraphAgent의 그래프를 자동 추적
//   - Failure/Interrupted/Waiting 노드를 상태별 색상으로 구분 표시
//   - 목록 항목 클릭 → BehaviorGraphView.Background.FrameElement() 호출로 뷰포트 이동
//   - 노드 선택 상태도 함께 업데이트
//   - 200ms 폴링으로 상태 변화 실시간 감지
//
// 기술 접근:
//   BehaviorNodeUI (internal) → GetType().Name 비교로 탐색
//   Background.FrameElement   → Reflection (GraphView.Background 프로퍼티)
//   ViewState.SetSelected     → Reflection (선택 상태 동기화)
//   노드 이름 표시            → nodeUI.Q("NodeTitle")?.text 또는 GetType().Name 폴백
//
// 이중 비판·재검증 반영:
//   [C-05] OnGraphStatusChange 대신 폴링 방식 채택
//          (이벤트 시그니처 불확실 + 폴링이 더 단순·안정적)
//   노드 이름: nodeUI.Q("#NodeTitleLabel")?.text 우선 시도, 실패 시 타입명 폴백
// =============================================================================

#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using System.Reflection;
using UnityEditor;
using UnityEngine;
using UnityEngine.UIElements;

namespace TDA.Editor
{
    /// <summary>
    /// Behavior Graph 실행 중 실패·중단 노드를 실시간으로 표시하고
    /// 클릭 시 해당 노드로 뷰포트를 이동하는 EditorWindow입니다.
    /// </summary>
    public sealed class GraphConsoleWindow : EditorWindow
    {
        // =====================================================================
        // 상수
        // =====================================================================

        private const string k_NodeUITypeName     = "BehaviorNodeUI";
        private const string k_FailureClass       = "NodeStatus_Failure";
        private const string k_InterruptedClass   = "NodeStatus_Interrupted";
        private const string k_WaitingClass       = "NodeStatus_Waiting";
        private const string k_RunningClass       = "NodeStatus_Running";
        private const string k_GraphViewClass     = "BehaviorGraphView";

        /// <summary>상태 폴링 주기 (ms).</summary>
        private const double k_PollIntervalSec = 0.2;

        // =====================================================================
        // 내부 상태
        // =====================================================================

        /// <summary>탐지된 노드 항목 목록.</summary>
        private readonly List<NodeEntry> _entries = new();

        /// <summary>스크롤 위치.</summary>
        private Vector2 _scroll;

        /// <summary>마지막 폴링 시각.</summary>
        private double _lastPollTime;

        /// <summary>자동 선택 모드 (Selection 변경 시 자동 추적).</summary>
        private bool _autoTrack = true;

        /// <summary>현재 추적 중인 BehaviorGraphView VisualElement.</summary>
        private VisualElement _trackedGraphView;

        // ── Reflection 캐시 ────────────────────────────────────────────────────
        private static PropertyInfo s_backgroundProp;
        private static MethodInfo   s_frameElementMethod;
        private static PropertyInfo s_viewStateProp;
        private static MethodInfo   s_setSelectedMethod;

        private static readonly BindingFlags k_BF =
            BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance;

        // =====================================================================
        // 노드 항목 데이터
        // =====================================================================

        /// <summary>Console 목록에 표시할 노드 하나의 데이터.</summary>
        private struct NodeEntry
        {
            /// <summary>BehaviorNodeUI VisualElement 참조.</summary>
            public VisualElement NodeUI;
            /// <summary>표시할 노드 이름.</summary>
            public string Label;
            /// <summary>현재 상태 문자열.</summary>
            public string Status;
            /// <summary>상태에 따른 색상.</summary>
            public Color Color;
        }

        // =====================================================================
        // 메뉴 등록 및 창 열기
        // =====================================================================

        /// <summary>
        /// 메뉴에서 Graph Console 창을 엽니다.
        /// </summary>
        [MenuItem("Window/AI/Graph Console")]
        public static void Open()
        {
            var win = GetWindow<GraphConsoleWindow>("Graph Console");
            win.minSize = new Vector2(320, 250);
        }

        // =====================================================================
        // Unity 생명주기
        // =====================================================================

        private void OnEnable()
        {
            // Selection 변경 감지 (자동 추적)
            Selection.selectionChanged += OnSelectionChanged;
        }

        private void OnDisable()
        {
            Selection.selectionChanged -= OnSelectionChanged;
            _trackedGraphView           = null;
        }

        private void OnSelectionChanged()
        {
            if (!_autoTrack) return;

            // 선택된 GameObject에 연결된 BehaviorGraphView 탐색
            var go = Selection.activeGameObject;
            if (go == null) { _trackedGraphView = null; return; }

            _trackedGraphView = FindGraphViewForAgent(go);
            Repaint();
        }

        // =====================================================================
        // IMGUI 렌더링
        // =====================================================================

        private void OnGUI()
        {
            // 툴바
            DrawToolbar();

            if (!Application.isPlaying)
            {
                DrawCentered("▶  플레이 모드에서만 동작합니다");
                return;
            }

            if (_trackedGraphView == null)
            {
                DrawCentered("BehaviorGraphAgent가 있는 오브젝트를 씬에서 선택하세요");
                return;
            }

            // 폴링: 200ms마다 상태 갱신
            if (EditorApplication.timeSinceStartup - _lastPollTime >= k_PollIntervalSec)
            {
                PollNodeStatuses();
                _lastPollTime = EditorApplication.timeSinceStartup;
            }

            // 목록 헤더
            DrawHeader();

            // 항목 목록
            _scroll = EditorGUILayout.BeginScrollView(_scroll);
            DrawEntries();
            EditorGUILayout.EndScrollView();

            // 매 프레임 리페인트 (애니메이션처럼 부드럽게)
            Repaint();
        }

        // =====================================================================
        // 툴바
        // =====================================================================

        private void DrawToolbar()
        {
            using var h = new EditorGUILayout.HorizontalScope(EditorStyles.toolbar);

            _autoTrack = GUILayout.Toggle(_autoTrack, "자동 추적",
                EditorStyles.toolbarButton, GUILayout.Width(70));

            if (GUILayout.Button("수동 연결", EditorStyles.toolbarButton, GUILayout.Width(70)))
            {
                var go = Selection.activeGameObject;
                if (go != null) _trackedGraphView = FindGraphViewForAgent(go);
            }

            GUILayout.FlexibleSpace();

            // 상태 요약
            if (_trackedGraphView != null && Application.isPlaying)
            {
                int fc = 0, ic = 0;
                foreach (var e in _entries)
                {
                    if (e.Status == "Failure")     fc++;
                    if (e.Status == "Interrupted") ic++;
                }
                if (fc > 0) GUILayout.Label($"✗ {fc}", new GUIStyle(EditorStyles.miniLabel)
                    { normal = { textColor = new Color(0.96f, 0.26f, 0.26f) } });
                if (ic > 0) GUILayout.Label($"⚡ {ic}", new GUIStyle(EditorStyles.miniLabel)
                    { normal = { textColor = new Color(0.98f, 0.57f, 0.18f) } });
            }

            if (GUILayout.Button("클리어", EditorStyles.toolbarButton, GUILayout.Width(50)))
            {
                _entries.Clear();
                _trackedGraphView = null;
            }
        }

        // =====================================================================
        // 컬럼 헤더
        // =====================================================================

        private void DrawHeader()
        {
            var hStyle = new GUIStyle(EditorStyles.miniLabel)
            {
                fontStyle = FontStyle.Bold,
                normal    = { textColor = new Color(0.6f, 0.6f, 0.6f) },
            };

            using var h = new EditorGUILayout.HorizontalScope();
            GUILayout.Label("상태",   hStyle, GUILayout.Width(80));
            GUILayout.Label("노드명", hStyle);
        }

        // =====================================================================
        // 항목 목록
        // =====================================================================

        private void DrawEntries()
        {
            if (_entries.Count == 0)
            {
                var style = new GUIStyle(EditorStyles.centeredGreyMiniLabel);
                GUILayout.Label("이상 없음  ✓", style);
                return;
            }

            var prevBg  = GUI.backgroundColor;
            var rowNorm = new GUIStyle(EditorStyles.miniButton)
            {
                alignment = TextAnchor.MiddleLeft,
                fontSize  = 11,
            };

            for (int i = 0; i < _entries.Count; i++)
            {
                var entry = _entries[i];
                if (entry.NodeUI?.panel == null) continue; // 분리된 노드 스킵

                using var h = new EditorGUILayout.HorizontalScope();

                // 상태 배지
                var badgeStyle = new GUIStyle(EditorStyles.miniLabel)
                {
                    fontStyle = FontStyle.Bold,
                    normal    = { textColor = entry.Color },
                    fixedWidth = 80,
                };
                GUILayout.Label(entry.Status, badgeStyle, GUILayout.Width(80));

                // 노드명 버튼 — 클릭 시 뷰포트 이동
                GUI.backgroundColor = new Color(entry.Color.r, entry.Color.g, entry.Color.b, 0.15f);
                if (GUILayout.Button(entry.Label, rowNorm))
                    NavigateTo(entry.NodeUI);
                GUI.backgroundColor = prevBg;
            }
        }

        // =====================================================================
        // 상태 폴링
        // =====================================================================

        /// <summary>
        /// BehaviorGraphView에서 문제 상태 노드를 탐색하여 _entries를 갱신합니다.
        /// 200ms마다 호출됩니다.
        /// </summary>
        private void PollNodeStatuses()
        {
            _entries.Clear();
            if (_trackedGraphView == null) return;

            _trackedGraphView.Query<VisualElement>()
                .Where(e => e.GetType().Name == k_NodeUITypeName)
                .ForEach(CollectNodeEntry);
        }

        /// <summary>노드 상태를 확인하고 문제 상태면 _entries에 추가합니다.</summary>
        private void CollectNodeEntry(VisualElement nodeUI)
        {
            if (nodeUI?.panel == null) return;

            string status = null;
            Color  color  = Color.white;

            if      (nodeUI.ClassListContains(k_FailureClass))
            {
                status = "Failure";
                color  = new Color(0.96f, 0.26f, 0.26f); // 빨강
            }
            else if (nodeUI.ClassListContains(k_InterruptedClass))
            {
                status = "Interrupted";
                color  = new Color(0.98f, 0.57f, 0.18f); // 주황
            }
            else if (nodeUI.ClassListContains(k_WaitingClass))
            {
                status = "Waiting";
                color  = new Color(0.98f, 0.87f, 0.21f); // 노랑
            }
            else if (nodeUI.ClassListContains(k_RunningClass))
            {
                status = "Running";
                color  = new Color(0.00f, 0.90f, 0.63f); // 청록
            }

            if (status == null) return; // 정상(Uninitialized/Success) 노드는 표시 안 함

            _entries.Add(new NodeEntry
            {
                NodeUI = nodeUI,
                Label  = GetNodeLabel(nodeUI),
                Status = status,
                Color  = color,
            });
        }

        // =====================================================================
        // 노드 레이블 획득
        // =====================================================================

        /// <summary>
        /// 노드의 표시 이름을 획득합니다.
        /// 우선순위: #NodeTitleLabel 텍스트 → nodeUI.tooltip → 타입명 정제
        /// </summary>
        private static string GetNodeLabel(VisualElement nodeUI)
        {
            // 1순위: #NodeTitleLabel VisualElement의 텍스트
            // USS에서 #NodeTitleLabel은 노드 제목 레이블로 확인됨
            if (nodeUI.Q("NodeTitleLabel") is Label titleLabel &&
                !string.IsNullOrWhiteSpace(titleLabel.text))
                return titleLabel.text;

            // 2순위: #NodeTitle 내부 Label
            var nodeTitle = nodeUI.Q("NodeTitle");
            if (nodeTitle != null)
            {
                foreach (var child in nodeTitle.Children())
                {
                    if (child is Label lbl && !string.IsNullOrWhiteSpace(lbl.text))
                        return lbl.text;
                }
            }

            // 3순위: 타입명에서 Action/Composite/Modifier/Node 제거
            return PrettifyTypeName(nodeUI.GetType().Name);
        }

        private static string PrettifyTypeName(string name)
        {
            return name
                .Replace("ActionUI",    "")
                .Replace("Action",      "")
                .Replace("Composite",   "")
                .Replace("Modifier",    "")
                .Replace("NodeUI",      "")
                .Replace("Node",        "")
                .Trim();
        }

        // =====================================================================
        // 뷰포트 이동 (FrameElement)
        // =====================================================================

        /// <summary>
        /// 지정된 노드로 BehaviorGraphView 뷰포트를 이동하고 선택합니다.
        /// BehaviorGraphEditor.cs 1236번 줄:
        ///   BehaviorGraphView.Background.FrameElement(targetNodeUi);
        ///   BehaviorGraphView.ViewState.SetSelected(new[] { targetNodeUi });
        /// </summary>
        private void NavigateTo(VisualElement nodeUI)
        {
            if (_trackedGraphView == null || nodeUI?.panel == null) return;

            try
            {
                // Background 프로퍼티 획득 (GraphView base class)
                s_backgroundProp ??= FindPropInHierarchy(_trackedGraphView.GetType(), "Background", k_BF);
                var background = s_backgroundProp?.GetValue(_trackedGraphView);
                if (background == null) { LogNavigationFail("Background null"); return; }

                // Background.FrameElement(VisualElement) 호출
                s_frameElementMethod ??= background.GetType()
                    .GetMethod("FrameElement", k_BF, null, new[] { typeof(VisualElement) }, null);

                if (s_frameElementMethod == null)
                {
                    // FrameElement(VisualElement) 오버로드가 없을 때 단일 파라미터 버전 탐색
                    s_frameElementMethod = background.GetType().GetMethod("FrameElement", k_BF);
                }

                s_frameElementMethod?.Invoke(background, new object[] { nodeUI });

                // ViewState.SetSelected 로 선택 상태 동기화
                s_viewStateProp ??= FindPropInHierarchy(_trackedGraphView.GetType(), "ViewState", k_BF);
                var viewState = s_viewStateProp?.GetValue(_trackedGraphView);
                if (viewState != null)
                {
                    s_setSelectedMethod ??= viewState.GetType()
                        .GetMethod("SetSelected", k_BF);
                    // SetSelected는 IEnumerable<NodeUI>를 받으므로 배열 전달
                    var nodeUIs = Array.CreateInstance(typeof(VisualElement), 1);
                    nodeUIs.SetValue(nodeUI, 0);
                    s_setSelectedMethod?.Invoke(viewState, new object[] { nodeUIs });
                }
            }
            catch (Exception ex)
            {
                LogNavigationFail(ex.Message);
            }
        }

        private static void LogNavigationFail(string reason) =>
            Debug.LogWarning($"[GraphConsole] 노드 위치 이동 실패: {reason}\n" +
                             "Background.FrameElement 또는 ViewState.SetSelected API가 변경됐을 수 있습니다.");

        // =====================================================================
        // BehaviorGraphView 탐색
        // =====================================================================

        /// <summary>
        /// 선택된 GameObject와 연결된 BehaviorGraphView를 찾습니다.
        /// 현재 열린 모든 EditorWindow에서 탐색합니다.
        /// </summary>
        private static VisualElement FindGraphViewForAgent(GameObject go)
        {
            foreach (var win in Resources.FindObjectsOfTypeAll<EditorWindow>())
            {
                if (win?.rootVisualElement == null) continue;
                var gv = win.rootVisualElement.Q<VisualElement>(className: k_GraphViewClass);
                if (gv != null) return gv;
            }
            return null;
        }

        // =====================================================================
        // Reflection 헬퍼
        // =====================================================================

        private static PropertyInfo FindPropInHierarchy(Type type, string name, BindingFlags flags)
        {
            for (; type != null && type != typeof(object); type = type.BaseType)
            {
                var p = type.GetProperty(name, flags);
                if (p != null) return p;
            }
            return null;
        }

        // =====================================================================
        // UI 유틸리티
        // =====================================================================

        private static void DrawCentered(string msg)
        {
            GUILayout.FlexibleSpace();
            EditorGUILayout.LabelField(msg, EditorStyles.centeredGreyMiniLabel);
            GUILayout.FlexibleSpace();
        }
    }
}
#endif
