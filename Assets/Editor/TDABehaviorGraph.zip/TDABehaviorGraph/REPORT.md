# Unity Behavior Graph 1.0.15 — 커스터마이징 최종 보고서
> TDA Project · 2026-04-09

---

## 📚 공식 레퍼런스 학습 요약

Unity Behavior 1.0.15는 `com.unity.behavior` 패키지로 제공되는 그래프 기반 행동 트리 시스템입니다.  
1.0.15의 핵심 신기능: **ObserverAbort 지원**, Inspector 디버그 개선, 열거형 Blackboard 버그 수정.

UI 레이어는 **Unity UI Toolkit (USS/UXML)** 으로 완전히 구성되며,  
C# 노드 정의 → `BehaviorAuthoringGraph` → `BehaviorGraphAgent` → 런타임 실행의 구조를 갖습니다.

---

## 🔬 커스터마이징 가능 범위 (소스 직접 분석 결과)

### ✅ 즉시 가능 — USS 오버라이드

소스 분석 결과 `BehaviorNodeStylesheet.uss`의 모든 색상이 CSS 변수(`--behavior-ui-node-*-bg`)로 추상화되어 있습니다.  
`BehaviorGraphEditorEnhancer.cs`가 에디터 창에 `CustomBehaviorTheme.uss`를 후순위로 주입하면 패키지 수정 없이 완전 오버라이드됩니다.

**개선 항목:**
| 항목 | 변경 내용 |
|------|-----------|
| 노드 배경색 | 채도·명도 강화 (어두운 배경에서 구분 명확) |
| 그리드 | 배경 어둡게, 선 간격 넓힘, 굵은 가이드선 5줄마다 |
| 디버그 상태 | Running=청록/Success=초록/Failure=빨강 테두리 + CSS transition |
| 노드 크기 | min-width 180px (텍스트 잘림 방지) |
| 블랙보드 패널 | 호버 효과, 섹션 헤더 강조 |

### ✅ 즉시 가능 — BlackboardLiveMonitor EditorWindow

플레이 모드 중 실시간 BB 값 표시. 기본 Blackboard 패널이 Authoring 기본값만 보여주는 한계를 완전 해결.

**기능:**
- 타입별 색상 구분 (string=초록, float=노랑, bool=청록, GameObject=보라)
- 값 변경 시 1초간 행 황색 하이라이트
- 우선 변수(UtilityWinner/Fear/HasTarget) 상단 고정
- 변수명 필터 검색
- 자동 선택 모드

**열기:** `Window > AI > Blackboard Live Monitor`

### ✅ 코드 패치 필요 — 블랙보드 0/false/빈값 해결

---

## 🚨 블랙보드 값 0/false/빈값 — 근본 원인 및 해결

### 원인 분석 (소스 코드 직접 확인)

`PB4DecisionAdapter.cs` 코드 내부에 다음 주석이 명시되어 있습니다:

```
// Awake에서 SetVariableValue를 호출하면 실패합니다.
// BehaviorGraphAgent는 Awake 또는 첫 Update에서 그래프를 초기화하므로...
```

즉 **3가지 원인이 복합적으로 작용**합니다:

1. **[BB-3] 타이밍 문제**: `BehaviorGraphAgent`의 그래프 Init()보다 먼저 `SetVariableValue()`가 호출되어 조용히 실패
2. **[BB-2] SO 미할당**: `combatProfile`이 Inspector에서 비어 있으면 StalkSpeed/EngageRange 등 전부 0
3. **[BB-4] Inspector 표시 채널 불일치**: Editor BB 패널은 Authoring 기본값을 표시, 런타임 값은 Debug 모드 연결 필요
4. **[BB-1] `m_BlackboardOverrides` 미갱신**: `SetVariableValue()`는 런타임 그래프에는 기록하지만 Inspector 표시용 overrides 딕셔너리는 갱신하지 않음 (이미 `SyncBlackboardOverrideForInspector()`로 Fix-C 적용됨)

### 해결 방법 (우선순위 순)

#### 즉시 적용 — Inspector 확인

```
Skeleton_01 > PB4DecisionAdapter 컴포넌트
├── Combat Profile : [Skeleton_T1_CombatProfile 할당 필요] ← 가장 흔한 원인
├── Bt Agent       : [BehaviorGraphAgent 자동 탐색 or 수동 할당]
└── Mob Brain      : [MobAIBrain 자동 탐색 or 수동 할당]
```

#### 코드 패치 — `PB4DecisionAdapter.cs`

**PATCH 1**: `private void Start()` → `private IEnumerator Start()`로 교체

```csharp
private IEnumerator Start()
{
    // BehaviorGraphAgent 그래프 초기화 대기 (최대 5프레임)
    for (int i = 0; i < 5; i++)
    {
        yield return null;
        if (btAgent == null) btAgent = GetComponent<BehaviorGraphAgent>();
        if (btAgent != null && btAgent.Graph != null) break;
    }
    
    // 컴포넌트 탐색
    if (mobBrain == null)      mobBrain      = GetComponent<MobAIBrain>();
    if (aiManager == null)     aiManager     = GetComponent<AICharacterManager>();
    if (mobBrain != null)      mobBrain.externallyTicked = true;
    
    if (btAgent?.Graph == null)
    {
        Debug.LogError($"[PB4Adapter] {name}: BehaviorGraph 초기화 실패");
        yield break;
    }
    
    InitializeBlackboard();
    _bbInitialized = true;
}
```

**PATCH 2**: `Update()` 내 지연 초기화 블록 교체

```csharp
// BEFORE:
if (!_bbInitialized && btAgent != null) { InitializeBlackboard(); _bbInitialized = true; }

// AFTER:
if (!_bbInitialized) return;
```

**PATCH 3**: `combatProfile == null` 시 안전한 기본값 설정

```csharp
else  // combatProfile == null 블록
{
    Debug.LogError($"[PB4Adapter] {name}: ⛔ FactionCombatProfileSO 미할당! 기본값 사용.");
    SetBB("StalkSpeed",         3.5f);
    SetBB("EngageRange",        5.0f);
    SetBB("OrbitRadius",        3.0f);
    SetBB("StrafeAngularSpeed", 60.0f);
    SetBB("StrikeTriggerTime",  1.5f);
    SetBB("FleeSprintSpeed",    6.0f);
}
```

**PATCH 4**: 진단 컨텍스트 메뉴 추가

```csharp
[ContextMenu("Diagnose Blackboard")]
private void DiagnoseBlackboard()
{
    // Skeleton_01 우클릭 > PB4DecisionAdapter > Diagnose Blackboard
    // Console에 모든 BB 변수 상태 출력
}
```

---

## 📁 제공 파일 목록

```
Assets/
├── Editor/
│   ├── CustomBehaviorTheme.uss          ← 커스텀 USS 테마
│   ├── BehaviorGraphEditorEnhancer.cs   ← USS 자동 주입 (InitializeOnLoad)
│   └── BlackboardLiveMonitor.cs         ← 실시간 BB 모니터링 창
└── (병합 참고)
    └── Patches/PB4DecisionAdapter_BBFix.cs  ← 패치 코드 주석 모음
```

---

## 🗺️ 추가 개선 로드맵

| 항목 | 설명 | 난이도 |
|------|------|--------|
| UtilityWinner 배지 | 실행 중 노드 위에 "Attack/Flee" 텍스트 표시 | 중 |
| 속도 기반 엣지 두께 | fear 값에 따라 연결선 두께 변동 | 높음 (embed 필요) |
| 노드 자동 색상 분류 | PolicyType 별 노드 배경색 자동 지정 | 중 |
| 그래프 미니맵 | 우하단 미니맵 오버레이 (GraphFramework 확장) | 높음 |

---

## ⚠️ 1차 비판 → 재검증 → 2차 비판 → 재검증 요약

**1차 비판**: USS 오버라이드만으로 충분하다는 것은 낙관적. `ResourceLoadAPI.Load()` 방식은 VisualElement에 직접 추가되므로 우선순위 보장이 불명확.

**1차 재검증**: 실제로 `styleSheets.Add()`는 배열 후순위가 같은 specificity에서 우선 적용됨을 UI Toolkit 스펙에서 확인. `BehaviorGraphEditorEnhancer`가 에디터 창의 `rootVisualElement`에 추가하므로 **전역 범위에서 우선 적용됨** → 가능.

**2차 비판**: 소스 파일이 제공된 이상 패키지를 embed 로컬 수정하면 훨씬 강력하다. 이를 "불가능"으로 분류한 것은 불완전한 분석.

**2차 재검증**: embed 방식은 `manifest.json`의 `"com.unity.behavior": "file:../LocalPackages/..."` 한 줄로 가능하며 소스 직접 수정이 열림. 단 Unity 공식 업데이트를 수동 병합해야 하며 패키지 서명 경고 발생 가능. **권장하지 않음** — 대신 USS 오버라이드 + C# Editor 확장 조합이 유지보수 관점에서 최적.

**최종 결론**: USS 오버라이드 (Layer 1) + BlackboardLiveMonitor (Layer 2) + PB4DecisionAdapter 코루틴 패치 (Layer 2)의 3-레이어 전략이 **가장 안전하고 효과적**.
