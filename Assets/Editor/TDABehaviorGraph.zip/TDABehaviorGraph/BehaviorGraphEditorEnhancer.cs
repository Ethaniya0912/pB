// =============================================================================
// BehaviorGraphEditorEnhancer.cs  |  TDA Project — v5
// Layer  : Editor Tooling
// Phase  : 1 (기반 설정)
//
// 역할:
//   Unity Behavior Graph 에디터 창에 커스텀 시각 테마를 자동 주입하고,
//   NodeAnimator·EdgeFlowOverlay·GraphMinimapOverlay 인스턴스의 생명주기를 관리합니다.
//
// v5 변경사항 (스크린샷 진단 + 4단계 비판·재검증 반영):
//   [전략 0 신규] ForceBlackboardVisible()에 가장 신뢰도 높은 전략 추가:
//                GraphEditor base class의 "Blackboard"/"Inspector" 프로퍼티를
//                타입 계층 Reflection으로 직접 접근하여 표시 제어
//                소스 근거:
//                  BehaviorGraphEditor.cs 28번 줄:
//                    internal BehaviorGraphBlackboardView BehaviorBlackboardView
//                      => Blackboard as BehaviorGraphBlackboardView;
//                  BehaviorGraphEditor.cs 132번 줄:
//                    if (Inspector is BehaviorInspectorView behaviorInspector)
//                  → "Blackboard"와 "Inspector" 모두 GraphEditor base 프로퍼티 이름 확인됨
//   [전략 A] ShowBlackboard() 등 후보 메서드 Reflection
//   [전략 B] BehaviorGraphBlackboardView 타입명/요소명 트리 탐색
//   [전략 C] BlackboardLiveMonitor 창 안내
//   [진단]   DiagnoseEditorStructure() 메뉴 — 전체 VisualElement 트리 Console 출력
//
// v3/v4에서 유지되는 사항:
//   [C-01] GetFirstAncestorWhere() → hierarchy.parent 수동 순회 + depth limit 32
//   [C-08] 블랙보드 EditorPrefs 초기화 키 목록
//   [D-A]  NodeAnimator·EdgeFlowOverlay 독립 파일 (SRP 준수)
//
// 의존성:
//   - NodeAnimator.cs            (Phase 3)
//   - EdgeFlowOverlay.cs         (Phase 4)
//   - GraphMinimapOverlay.cs     (Phase 5)
//   - CustomBehaviorTheme.uss
//
// 소스 근거 요약:
//   BehaviorLayout.uxml: BehaviorToolbar + EditorPanel(BehaviorGraphView)만 정의.
//   #LeftPanel / #Blackboard는 GraphEditor base(GraphFramework)가 C#으로 동적 추가.
//   GraphEditor base에 "Blackboard" 프로퍼티(BlackboardView 반환),
//   "Inspector" 프로퍼티(InspectorView 반환) 모두 소스에서 확인됨.
// =============================================================================

#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using System.Reflection;
using UnityEditor;
using UnityEngine;
using UnityEngine.UIElements;

namespace TDA.Editor
{
    /// <summary>
    /// Unity Behavior Graph 에디터 창에 커스텀 시각 테마와 애니메이션 컴포넌트를
    /// 자동으로 주입하는 에디터 초기화 클래스입니다.
    /// </summary>
    /// <remarks>
    /// [InitializeOnLoad] 특성으로 Unity 에디터 시작 시 자동 실행됩니다.
    /// EditorApplication.update 폴링으로 열린 모든 에디터 창을 감시하며,
    /// BehaviorGraphEditor 요소를 발견하면 즉시 커스터마이징을 적용합니다.
    /// </remarks>
    [InitializeOnLoad]
    public static class BehaviorGraphEditorEnhancer
    {
        // ─────────────────────────────────────────────────────────────────────
        // 상수
        // ─────────────────────────────────────────────────────────────────────

        /// <summary>커스텀 USS 파일의 Assets 기준 경로.</summary>
        private const string k_UssPath =
            "Assets/Editor/TDABehaviorGraph/CustomBehaviorTheme.uss";

        /// <summary>
        /// BehaviorGraphEditor 클래스 이름 (internal 타입이므로 문자열로 탐색).
        /// Unity Behavior 패키지 버전 업 시 변경될 수 있습니다.
        /// </summary>
        private const string k_BgeTypeName = "BehaviorGraphEditor";

        /// <summary>
        /// BehaviorGraphView CSS 클래스명 (BehaviorGraphView.cs 53번 줄: AddToClassList 확인).
        /// BehaviorGraphEditor 탐색 실패 시 폴백으로 사용합니다.
        /// </summary>
        private const string k_BgvClassName = "BehaviorGraphView";

        /// <summary>
        /// hierarchy.parent 순회 시 최대 깊이 제한.
        /// Unity Panel 계층의 무한 루프를 방지합니다 (D-A 비판 수용, depth limit 32).
        /// </summary>
        private const int k_AncestorSearchDepth = 32;

        /// <summary>PrintTree 진단의 최대 출력 깊이.</summary>
        private const int k_PrintTreeMaxDepth = 7;

        // ─────────────────────────────────────────────────────────────────────
        // 블랙보드 EditorPrefs 키 목록
        // BehaviorGraphEditor.k_PreferencesPrefix = "Muse.Behavior" (소스 확인)
        // 실제 키 이름은 DumpBlackboardPrefs() 메뉴로 확인 후 목록 갱신 필요.
        // ─────────────────────────────────────────────────────────────────────

        /// <summary>
        /// 블랙보드 패널 상태를 저장하는 EditorPrefs 키 목록.
        /// 에디터 창 열기 전에 삭제하여 블랙보드가 접힌 상태로 시작하지 않도록 합니다.
        /// 실제 키 이름은 Dump Blackboard Prefs 메뉴로 확인하세요.
        /// </summary>
        private static readonly string[] k_BlackboardPrefKeys =
        {
            "Muse.Behavior.BlackboardWidth",
            "Muse.Behavior.BlackboardCollapsed",
            "Muse.Behavior.LeftPanelWidth",
            "Muse.Behavior.LeftPanelCollapsed",
            "Muse.Behavior.PanelState",
            "Muse.Behavior.SplitViewPos",
            "Unity.Behavior.BlackboardCollapsed",
            "Unity.Behavior.LeftPanelWidth",
        };

        // ─────────────────────────────────────────────────────────────────────
        // 전략 0: GraphEditor base 프로퍼티명 후보
        //
        // 소스 확인:
        //   BehaviorGraphEditor.cs 28번 줄:
        //     BehaviorBlackboardView => Blackboard as BehaviorGraphBlackboardView
        //     → "Blackboard" 프로퍼티가 GraphEditor base에 존재함
        //   BehaviorGraphEditor.cs 132번 줄:
        //     if (Inspector is BehaviorInspectorView ...)
        //     → "Inspector" 프로퍼티가 GraphEditor base에 존재함
        // ─────────────────────────────────────────────────────────────────────

        /// <summary>
        /// GraphEditor base class의 Blackboard 프로퍼티 후보 이름 목록.
        /// 첫 번째 후보인 "Blackboard"가 소스에서 확인됩니다.
        /// </summary>
        private static readonly string[] k_BlackboardPropertyNames =
        {
            "Blackboard",           // GraphEditor base class 소스에서 확인
            "BehaviorBlackboardView", // BehaviorGraphEditor 래퍼 프로퍼티
            "BlackboardView",
            "BlackboardPanel",
        };

        /// <summary>
        /// GraphEditor base class의 Inspector 프로퍼티 후보 이름 목록.
        /// 소스에서 "Inspector"가 확인됩니다.
        /// </summary>
        private static readonly string[] k_InspectorPropertyNames =
        {
            "Inspector",            // GraphEditor base class 소스에서 확인
            "InspectorView",
            "NodeInspector",
        };

        // ─────────────────────────────────────────────────────────────────────
        // 전략 A: ShowBlackboard() 메서드 후보
        // GraphFramework GraphEditor base class에 있을 것으로 추정되는 메서드들.
        // ─────────────────────────────────────────────────────────────────────
        private static readonly string[] k_ShowBlackboardMethods =
        {
            "ShowBlackboard",
            "ToggleBlackboard",
            "OpenBlackboard",
            "SetBlackboardVisible",
            "ShowHideBlackboard",
        };

        // ─────────────────────────────────────────────────────────────────────
        // 전략 B: 타입명/요소명 탐색 후보
        // ─────────────────────────────────────────────────────────────────────
        private static readonly string[] k_BlackboardTypeNames =
        {
            "BehaviorGraphBlackboardView",  // 소스에서 확인된 실제 클래스명
            "BlackboardView",
            "BehaviorBlackboardView",
        };

        private static readonly string[] k_BlackboardElementNames =
        {
            "Blackboard",
            "BlackboardView",
            "BlackboardPanel",
            "BlackboardContainer",
        };

        // ─────────────────────────────────────────────────────────────────────
        // 상태 추적
        // ─────────────────────────────────────────────────────────────────────

        /// <summary>이미 USS가 주입된 EditorWindow의 InstanceID 집합.</summary>
        private static readonly HashSet<int> s_InjectedWindowIds = new();

        /// <summary>창 ID → NodeAnimator 인스턴스 매핑.</summary>
        private static readonly Dictionary<int, object> s_Animators = new();

        /// <summary>창 ID → EdgeFlowOverlay 인스턴스 매핑.</summary>
        private static readonly Dictionary<int, object> s_Overlays = new();

        /// <summary>창 ID → GraphMinimapOverlay 인스턴스 매핑.</summary>
        private static readonly Dictionary<int, object> s_Minimaps = new();

        /// <summary>USS 로드 시도 횟수. 5회 초과 시 경고 출력.</summary>
        private static int s_LoadAttempts;

        /// <summary>USS 미발견 경고 중복 방지 플래그.</summary>
        private static bool s_WarnedAboutMissingUss;

        /// <summary>GC 방지용 재사용 제거 ID 목록.</summary>
        private static readonly List<int> s_ToRemove = new();

        // ─────────────────────────────────────────────────────────────────────
        // Reflection 공통 플래그
        // ─────────────────────────────────────────────────────────────────────

        private static readonly BindingFlags k_BF =
            BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance;

        // ─────────────────────────────────────────────────────────────────────
        // 초기화
        // ─────────────────────────────────────────────────────────────────────

        /// <summary>에디터 로드 시 자동 실행됩니다. update 폴링을 등록합니다.</summary>
        static BehaviorGraphEditorEnhancer()
        {
            EditorApplication.update += Tick;
        }

        // ─────────────────────────────────────────────────────────────────────
        // 폴링 루프
        // ─────────────────────────────────────────────────────────────────────

        /// <summary>
        /// EditorApplication.update 콜백.
        /// 열린 모든 EditorWindow를 순회하여 BehaviorGraphEditor를 탐색하고
        /// 아직 처리되지 않은 창에 커스터마이징을 적용합니다.
        /// </summary>
        private static void Tick()
        {
            // USS 로드 시도 (임포트 직후에는 null일 수 있으므로 매 Tick 재시도)
            var sheet = AssetDatabase.LoadAssetAtPath<StyleSheet>(k_UssPath);
            if (sheet == null)
            {
                if (++s_LoadAttempts > 5 && !s_WarnedAboutMissingUss)
                {
                    s_WarnedAboutMissingUss = true;
                    Debug.LogWarning(
                        $"[BehaviorEnhancer] CustomBehaviorTheme.uss를 찾을 수 없습니다.\n" +
                        $"경로를 확인하세요: {k_UssPath}");
                }
                return;
            }
            s_LoadAttempts = 0;
            s_WarnedAboutMissingUss = false;

            // 열린 모든 EditorWindow 순회
            foreach (var win in Resources.FindObjectsOfTypeAll<EditorWindow>())
            {
                if (win == null || win.rootVisualElement == null) continue;

                int winId = win.GetInstanceID();
                if (s_InjectedWindowIds.Contains(winId)) continue;

                // BehaviorGraphEditor VisualElement 탐색
                var bge = FindBehaviorGraphEditor(win.rootVisualElement);
                if (bge == null) continue;

                // 커스터마이징 적용
                ApplyCustomization(win, winId, bge, sheet);
            }

            // 닫힌 창 정리
            CleanupClosedWindows();
        }

        // ─────────────────────────────────────────────────────────────────────
        // 커스터마이징 적용
        // ─────────────────────────────────────────────────────────────────────

        /// <summary>
        /// 발견된 BehaviorGraphEditor 창에 USS 주입, 블랙보드 표시 시도(4전략),
        /// 컴포넌트 인스턴스 생성을 순서대로 적용합니다.
        /// </summary>
        private static void ApplyCustomization(
            EditorWindow win, int winId,
            VisualElement bge, StyleSheet sheet)
        {
            // 1) USS 주입 (창 루트 + BGE 양쪽에 주입하여 확실히 적용)
            InjectStyleSheet(win.rootVisualElement, sheet);
            InjectStyleSheet(bge, sheet);
            Debug.Log(
                $"[BehaviorEnhancer] ✓ USS 주입 완료\n" +
                $"  창: {win.GetType().Name}\n" +
                $"  BGE 타입: {bge.GetType().Name}\n" +
                $"  USS: {sheet.name}");

            // 2) 블랙보드 EditorPrefs 초기화 (패널이 접힌 상태로 저장된 경우 대응)
            ResetBlackboardPrefs();

            // 3) 블랙보드 표시 시도 (4전략 순차)
            //
            //    BehaviorLayout.uxml 소스 직접 확인:
            //      → #LeftPanel / #Blackboard 요소 없음
            //      → GraphEditor base(GraphFramework)가 C#으로 동적 추가
            //    GraphEditor base 프로퍼티:
            //      → "Blackboard" (BlackboardView 반환) ← 소스 28번 줄 확인
            //      → "Inspector"  (InspectorView 반환) ← 소스 132번 줄 확인
            ForceBlackboardVisible(bge);

            // 4) NodeAnimator 생성 (Phase 3)
            TryAttachNodeAnimator(winId, bge);

            // 5) EdgeFlowOverlay 생성 (Phase 4)
            TryAttachEdgeFlowOverlay(winId, bge);

            // 6) GraphMinimapOverlay 생성 (Phase 5)
            TryAttachMinimap(winId, bge);

            // 처리 완료 기록
            s_InjectedWindowIds.Add(winId);
            Debug.Log("[BehaviorEnhancer] ✓ 초기화 완료.");
        }

        // ─────────────────────────────────────────────────────────────────────
        // USS 주입
        // ─────────────────────────────────────────────────────────────────────

        /// <summary>
        /// 지정된 VisualElement의 styleSheets에 StyleSheet를 추가합니다.
        /// 이미 포함된 경우 중복 추가하지 않습니다.
        /// </summary>
        private static void InjectStyleSheet(VisualElement element, StyleSheet sheet)
        {
            if (element == null || sheet == null) return;
            if (!element.styleSheets.Contains(sheet))
                element.styleSheets.Add(sheet);
        }

        // ─────────────────────────────────────────────────────────────────────
        // 블랙보드 표시 — 4전략 순차 시도
        // ─────────────────────────────────────────────────────────────────────

        /// <summary>
        /// BehaviorGraphBlackboardView를 에디터 창에 표시합니다.
        /// 4가지 전략을 신뢰도 높은 순서대로 시도합니다.
        ///
        /// 전략 0 (가장 신뢰도 높음):
        ///   GraphEditor base class의 "Blackboard" 프로퍼티를 타입 계층 Reflection으로
        ///   직접 접근하여 반환된 BlackboardView를 표시합니다.
        ///   소스 확인: BehaviorGraphEditor.cs 28번 줄에서 "Blackboard" 프로퍼티명 확인.
        ///   동시에 "Inspector" 프로퍼티로 InspectorView를 찾아 크기를 축소합니다.
        ///
        /// 전략 A:
        ///   GraphEditor.ShowBlackboard() 등의 내부 메서드를 Reflection으로 호출합니다.
        ///
        /// 전략 B:
        ///   BehaviorGraphBlackboardView 타입명으로 VisualElement 트리를 탐색합니다.
        ///
        /// 전략 C:
        ///   위 전략이 모두 실패한 경우 BlackboardLiveMonitor 창으로 안내합니다.
        /// </summary>
        private static void ForceBlackboardVisible(VisualElement bge)
        {
            Debug.Log("[BehaviorEnhancer] 블랙보드 표시 시도 시작...");

            // ── 공통 전처리: LeftPanel 강제 표시 ──────────────────────────────
            // LeftPanel은 GraphEditor base가 C#으로 추가. 스크린샷에서 존재 확인.
            // 실제 이름이 다를 경우 DiagnoseEditorStructure()로 확인하세요.
            var leftPanel = bge.Q("LeftPanel");
            if (leftPanel != null)
            {
                leftPanel.style.display = DisplayStyle.Flex;
                leftPanel.style.minWidth = 240f;
                leftPanel.style.flexBasis = new StyleLength(260f);
                Debug.Log("[BehaviorEnhancer] ✓ #LeftPanel 발견 및 표시 강제");
            }
            else
            {
                Debug.LogWarning(
                    "[BehaviorEnhancer] ⚠ #LeftPanel을 찾을 수 없습니다.\n" +
                    "실제 이름이 다를 수 있습니다.\n" +
                    "Window > AI > TDA Behavior Tools > Diagnose Editor Structure 실행 후\n" +
                    "Console 출력에서 LeftPanel 역할의 요소 이름을 확인하세요.");
            }

            // ── 전략 0: GraphEditor.Blackboard 프로퍼티 직접 Reflection ───────
            if (TryDirectPropertyAccess(bge))
            {
                Debug.Log("[BehaviorEnhancer] ✓ 전략 0 성공: Blackboard 프로퍼티 직접 접근");
                return;
            }
            Debug.Log("[BehaviorEnhancer] 전략 0 실패 → 전략 A 시도");

            // ── 전략 A: ShowBlackboard() 메서드 Reflection ────────────────────
            if (TryShowBlackboardReflection(bge))
            {
                Debug.Log("[BehaviorEnhancer] ✓ 전략 A 성공: ShowBlackboard() 호출");
                return;
            }
            Debug.Log("[BehaviorEnhancer] 전략 A 실패 → 전략 B 시도");

            // ── 전략 B: 타입명/요소명으로 VisualElement 트리 탐색 ─────────────
            if (TryForceBlackboardViewVisible(bge))
            {
                Debug.Log("[BehaviorEnhancer] ✓ 전략 B 성공: BlackboardView 표시 강제");
                return;
            }
            Debug.Log("[BehaviorEnhancer] 전략 B 실패 → 전략 C: BlackboardLiveMonitor 안내");

            // ── 전략 C: BlackboardLiveMonitor 안내 ────────────────────────────
            Debug.LogWarning(
                "[BehaviorEnhancer] ⚠ 블랙보드 자동 표시 실패.\n\n" +
                "【해결 방법 1】 Diagnose Editor Structure 실행:\n" +
                "  Window > AI > TDA Behavior Tools > Diagnose Editor Structure\n" +
                "  Console 출력에서 ★ 표시된 Blackboard 요소의 이름을 확인 후\n" +
                "  k_BlackboardPropertyNames / k_BlackboardTypeNames 배열에 추가하세요.\n\n" +
                "【해결 방법 2】 BlackboardLiveMonitor 창 사용:\n" +
                "  Window > AI > Blackboard Live Monitor\n\n" +
                "【해결 방법 3】 수동 확인:\n" +
                "  Project 뷰에서 BehaviorGraph 에셋을 선택하면\n" +
                "  Inspector 하단에 블랙보드 변수가 표시됩니다.");
        }

        // ─────────────────────────────────────────────────────────────────────
        // 전략 0: GraphEditor.Blackboard / Inspector 프로퍼티 직접 Reflection
        // ─────────────────────────────────────────────────────────────────────

        /// <summary>
        /// 전략 0: GraphEditor base class의 "Blackboard" 프로퍼티를 타입 계층에서
        /// Reflection으로 직접 접근하여 BlackboardView를 표시합니다.
        ///
        /// 소스 근거:
        ///   BehaviorGraphEditor.cs 28번 줄:
        ///     internal BehaviorGraphBlackboardView BehaviorBlackboardView
        ///       => Blackboard as BehaviorGraphBlackboardView;
        ///   → "Blackboard" 프로퍼티가 GraphEditor base에 반드시 존재
        ///
        ///   BehaviorGraphEditor.cs 132번 줄:
        ///     if (Inspector is BehaviorInspectorView behaviorInspector)
        ///   → "Inspector" 프로퍼티가 GraphEditor base에 반드시 존재
        ///
        /// 동작 (v5 → v5.1 수정):
        ///   1. "Blackboard" 프로퍼티로 BlackboardView(VisualElement) 획득
        ///   2. BlackboardView.display = flex, flexGrow = 3 (3/4 공간 차지)
        ///   3. "Inspector" 프로퍼티로 InspectorView(VisualElement) 획득
        ///   4. InspectorView.flexGrow = 1 (1/4 공간으로 축소)
        ///      ← v5에서 maxHeight:0 사용했으나 overflow:visible로 텍스트 겹침 발생
        ///      ← display:none은 GraphEditor 내부 로직 파괴 위험
        ///      ← flexGrow 배분이 가장 안전한 방법
        ///   5. 두 View의 공통 부모(LeftPanel)를 flexDirection=column으로 설정
        /// </summary>
        private static bool TryDirectPropertyAccess(VisualElement bge)
        {
            try
            {
                // ── Blackboard 프로퍼티 획득 ────────────────────────────────────
                VisualElement bbView = null;
                foreach (var propName in k_BlackboardPropertyNames)
                {
                    var prop = FindPropertyInHierarchy(bge.GetType(), propName, k_BF);
                    if (prop == null) continue;

                    var val = prop.GetValue(bge);
                    if (val is VisualElement ve)
                    {
                        bbView = ve;
                        Debug.Log(
                            $"[BehaviorEnhancer] 전략 0: '{propName}' 프로퍼티로 " +
                            $"BlackboardView 획득 ({ve.GetType().Name})");
                        break;
                    }
                }

                if (bbView == null)
                {
                    Debug.Log(
                        "[BehaviorEnhancer] 전략 0: BlackboardView 프로퍼티를 찾을 수 없습니다.\n" +
                        $"  시도한 프로퍼티: {string.Join(", ", k_BlackboardPropertyNames)}");
                    return false;
                }

                // ── BlackboardView 표시 강제 ─────────────────────────────────
                bbView.style.display = DisplayStyle.Flex;
                bbView.style.flexGrow = 3;   // LeftPanel 공간의 3/4 차지
                bbView.style.minHeight = 80f; // 최소 높이 보장
                bbView.RemoveFromClassList("unity-hidden");

                // ── Inspector 프로퍼티로 InspectorView 획득 + flexGrow 축소 ───
                // 수정 (v5→v5.1):
                //   ❌ 제거: inspectorView.style.maxHeight = new StyleLength(0f);
                //      이유: maxHeight:0 + display:flex + overflow:visible 조합이
                //            Inspector 내 텍스트를 0높이 상자 밖으로 흘려보내
                //            인접 요소와 겹치는 문제 발생 (스크린샷 확인)
                //   ✅ 대체: flexGrow = 1 (1/4 공간으로 축소, 내용 클리핑 없음)
                foreach (var propName in k_InspectorPropertyNames)
                {
                    var prop = FindPropertyInHierarchy(bge.GetType(), propName, k_BF);
                    if (prop == null) continue;

                    var val = prop.GetValue(bge);
                    if (val is VisualElement inspectorView && inspectorView != bbView)
                    {
                        // flexGrow를 낮춰 공간을 줄이되, display는 건드리지 않음
                        // GraphEditor 내부가 InspectorView의 display를 관리하므로
                        // 우리가 display를 변경하면 노드 선택 시 Inspector가 나오지 않음
                        inspectorView.style.flexGrow = 1; // 1/4 공간으로 축소
                        Debug.Log(
                            $"[BehaviorEnhancer] 전략 0: '{propName}' 프로퍼티로 " +
                            $"InspectorView flexGrow 축소 ({inspectorView.GetType().Name})");
                        break;
                    }
                }

                // ── 공통 부모 LeftPanel flexDirection 설정 ────────────────────
                var bbParent = bbView.hierarchy.parent;
                if (bbParent != null)
                {
                    bbParent.style.flexDirection = FlexDirection.Column;
                    bbParent.style.display = DisplayStyle.Flex;
                    bbParent.style.flexGrow = 1;
                    Debug.Log(
                        $"[BehaviorEnhancer] 전략 0: 부모 요소 설정 " +
                        $"({bbParent.name}|{bbParent.GetType().Name})");
                }

                return true;
            }
            catch (Exception ex)
            {
                Debug.Log($"[BehaviorEnhancer] 전략 0 예외: {ex.Message}");
                return false;
            }
        }

        // ─────────────────────────────────────────────────────────────────────
        // 전략 A: ShowBlackboard() 메서드 Reflection
        // ─────────────────────────────────────────────────────────────────────

        /// <summary>
        /// 전략 A: GraphEditor.ShowBlackboard() 등의 내부 메서드를 Reflection으로 호출합니다.
        /// k_ShowBlackboardMethods 목록을 순서대로 시도합니다.
        /// </summary>
        private static bool TryShowBlackboardReflection(VisualElement bge)
        {
            foreach (var methodName in k_ShowBlackboardMethods)
            {
                try
                {
                    var method = FindMethodInHierarchy(bge.GetType(), methodName, k_BF);
                    if (method == null) continue;

                    var parameters = method.GetParameters();
                    if (parameters.Length == 0)
                    {
                        method.Invoke(bge, null);
                        Debug.Log($"[BehaviorEnhancer] 전략 A: {methodName}() 호출 성공");
                        return true;
                    }
                    if (parameters.Length == 1 &&
                        parameters[0].ParameterType == typeof(bool))
                    {
                        method.Invoke(bge, new object[] { true });
                        Debug.Log($"[BehaviorEnhancer] 전략 A: {methodName}(true) 호출 성공");
                        return true;
                    }
                }
                catch (Exception ex)
                {
                    Debug.Log($"[BehaviorEnhancer] 전략 A: {methodName}() 예외: {ex.Message}");
                }
            }

            Debug.Log(
                $"[BehaviorEnhancer] 전략 A: 후보 메서드 목록에서 동작하는 것 없음.\n" +
                $"  시도: {string.Join(", ", k_ShowBlackboardMethods)}");
            return false;
        }

        // ─────────────────────────────────────────────────────────────────────
        // 전략 B: 타입명/요소명으로 VisualElement 트리 탐색
        // ─────────────────────────────────────────────────────────────────────

        /// <summary>
        /// 전략 B: BehaviorGraphBlackboardView 타입명으로 VisualElement를 탐색하여
        /// display:flex로 강제 표시합니다.
        /// LeftPanel 내부의 Inspector View를 최소화하여 공간을 확보합니다.
        /// </summary>
        private static bool TryForceBlackboardViewVisible(VisualElement bge)
        {
            VisualElement bbView = null;

            // 타입명으로 탐색
            foreach (var typeName in k_BlackboardTypeNames)
            {
                bbView = FindByTypeName(bge, typeName);
                if (bbView != null)
                {
                    Debug.Log($"[BehaviorEnhancer] 전략 B: 타입명 '{typeName}'으로 발견");
                    break;
                }
            }

            // 요소명(name)으로 폴백 탐색
            if (bbView == null)
            {
                foreach (var elemName in k_BlackboardElementNames)
                {
                    bbView = bge.Q(elemName);
                    if (bbView != null)
                    {
                        Debug.Log(
                            $"[BehaviorEnhancer] 전략 B: 요소명 '{elemName}'으로 발견 " +
                            $"(타입: {bbView.GetType().Name})");
                        break;
                    }
                }
            }

            if (bbView == null)
            {
                Debug.Log(
                    "[BehaviorEnhancer] 전략 B: BlackboardView를 찾을 수 없습니다.\n" +
                    $"  시도 타입명: {string.Join(", ", k_BlackboardTypeNames)}\n" +
                    $"  시도 요소명: {string.Join(", ", k_BlackboardElementNames)}\n" +
                    "  DiagnoseEditorStructure()로 실제 이름을 확인하세요.");
                return false;
            }

            // BlackboardView 표시 강제
            bbView.style.display = DisplayStyle.Flex;
            bbView.style.flexGrow = 3;   // 3/4 공간 차지
            bbView.style.minHeight = 80f;
            bbView.RemoveFromClassList("unity-hidden");

            // 부모 내의 다른 자식(Inspector)을 flexGrow:1로 축소
            // 수정 (v5→v5.1):
            //   ❌ 제거: sibling.style.maxHeight = new StyleLength(0f);
            //      이유: overflow:visible로 텍스트가 부모 밖으로 넘쳐 겹침 발생
            //   ✅ 대체: sibling.style.flexGrow = 1 (공간 줄이되 내용 유지)
            var parent = bbView.hierarchy.parent;
            if (parent != null)
            {
                parent.style.flexDirection = FlexDirection.Column;
                foreach (var sibling in parent.Children())
                {
                    if (sibling == bbView) continue;
                    sibling.style.flexGrow = 1; // 1/4 공간으로 줄이기
                    Debug.Log(
                        $"[BehaviorEnhancer] 전략 B: 형제 flexGrow=1 조정 " +
                        $"({sibling.name}|{sibling.GetType().Name})");
                }
            }

            Debug.Log(
                $"[BehaviorEnhancer] ✓ 전략 B: BlackboardView 표시 강제 완료 " +
                $"({bbView.GetType().Name})");
            return true;
        }

        // ─────────────────────────────────────────────────────────────────────
        // 블랙보드 EditorPrefs 초기화
        // ─────────────────────────────────────────────────────────────────────

        /// <summary>
        /// 블랙보드 패널 상태를 저장하는 EditorPrefs 키를 삭제합니다.
        /// 다음 번 BG 창 열기 시 블랙보드가 열린 상태로 초기화됩니다.
        ///
        /// 실제 키 이름은 Window > AI > TDA Behavior Tools > Dump Blackboard Prefs 메뉴로 확인하세요.
        /// 확인 후 k_BlackboardPrefKeys 배열을 업데이트하세요.
        /// </summary>
        private static void ResetBlackboardPrefs()
        {
            foreach (var key in k_BlackboardPrefKeys)
            {
                if (EditorPrefs.HasKey(key))
                {
                    EditorPrefs.DeleteKey(key);
                    Debug.Log($"[BehaviorEnhancer] EditorPrefs 삭제: {key}");
                }
            }
        }

        // ─────────────────────────────────────────────────────────────────────
        // 컴포넌트 연결
        // ─────────────────────────────────────────────────────────────────────

        /// <summary>NodeAnimator 인스턴스를 생성하고 BehaviorGraphEditor에 연결합니다.</summary>
        private static void TryAttachNodeAnimator(int winId, VisualElement bge)
        {
            if (s_Animators.ContainsKey(winId)) return;
            try
            {
                var animator = new NodeAnimator(bge);
                s_Animators[winId] = animator;
                Debug.Log("[BehaviorEnhancer] ✓ NodeAnimator 연결 완료.");
            }
            catch (Exception ex)
            {
                Debug.LogWarning(
                    $"[BehaviorEnhancer] NodeAnimator 생성 실패: {ex.Message}\n" +
                    "NodeAnimator.cs가 Assets/Editor/TDABehaviorGraph/ 에 있는지 확인하세요.");
            }
        }

        /// <summary>EdgeFlowOverlay 인스턴스를 생성하고 BehaviorGraphEditor에 연결합니다.</summary>
        private static void TryAttachEdgeFlowOverlay(int winId, VisualElement bge)
        {
            if (s_Overlays.ContainsKey(winId)) return;
            try
            {
                var overlay = new EdgeFlowOverlay(bge);
                s_Overlays[winId] = overlay;
                Debug.Log("[BehaviorEnhancer] ✓ EdgeFlowOverlay 연결 완료.");
            }
            catch (Exception ex)
            {
                Debug.LogWarning(
                    $"[BehaviorEnhancer] EdgeFlowOverlay 생성 실패: {ex.Message}\n" +
                    "EdgeFlowOverlay.cs가 Assets/Editor/TDABehaviorGraph/ 에 있는지 확인하세요.");
            }
        }

        /// <summary>GraphMinimapOverlay 인스턴스를 생성하고 BehaviorGraphEditor에 연결합니다.</summary>
        private static void TryAttachMinimap(int winId, VisualElement bge)
        {
            if (s_Minimaps.ContainsKey(winId)) return;
            try
            {
                var minimap = new GraphMinimapOverlay(bge);
                s_Minimaps[winId] = minimap;
                Debug.Log("[BehaviorEnhancer] ✓ GraphMinimapOverlay 연결 완료.");
            }
            catch (Exception ex)
            {
                Debug.LogWarning(
                    $"[BehaviorEnhancer] GraphMinimapOverlay 생성 실패: {ex.Message}\n" +
                    "GraphMinimapOverlay.cs가 Assets/Editor/TDABehaviorGraph/ 에 있는지 확인하세요.");
            }
        }

        // ─────────────────────────────────────────────────────────────────────
        // VisualElement 탐색
        // ─────────────────────────────────────────────────────────────────────

        /// <summary>
        /// VisualElement 트리에서 BehaviorGraphEditor 요소를 탐색합니다.
        ///
        /// 탐색 전략:
        ///   1순위: 타입명 "BehaviorGraphEditor" 직접 일치 (재귀 DFS)
        ///   2순위: BehaviorGraphView CSS 클래스로 BehaviorGraphView 탐색 →
        ///          hierarchy.parent 수동 순회로 BehaviorGraphEditor 탐색
        ///          (GetFirstAncestorWhere가 Unity에 없으므로 직접 구현 — C-01 수정)
        /// </summary>
        private static VisualElement FindBehaviorGraphEditor(VisualElement root)
        {
            // 1순위: 타입명 DFS 탐색
            var byType = FindByTypeName(root, k_BgeTypeName);
            if (byType != null) return byType;

            // 2순위: BehaviorGraphView CSS 클래스로 폴백
            var graphView = FindByClassName(root, k_BgvClassName);
            if (graphView == null) return null;

            // BehaviorGraphView에서 부모를 역방향 순회
            // C-01 수정: GetFirstAncestorWhere 대신 hierarchy.parent 수동 순회
            // depth limit 32 추가 (Panel 최상위 보호)
            return FindAncestorByTypeName(graphView, k_BgeTypeName, k_AncestorSearchDepth);
        }

        /// <summary>DFS로 지정한 타입명의 VisualElement를 탐색합니다.</summary>
        private static VisualElement FindByTypeName(VisualElement element, string typeName)
        {
            if (element == null) return null;
            if (element.GetType().Name == typeName) return element;
            foreach (var child in element.Children())
            {
                var result = FindByTypeName(child, typeName);
                if (result != null) return result;
            }
            return null;
        }

        /// <summary>DFS로 지정한 CSS 클래스를 가진 VisualElement를 탐색합니다.</summary>
        private static VisualElement FindByClassName(VisualElement element, string className)
        {
            if (element == null) return null;
            if (element.ClassListContains(className)) return element;
            foreach (var child in element.Children())
            {
                var result = FindByClassName(child, className);
                if (result != null) return result;
            }
            return null;
        }

        /// <summary>
        /// 지정된 요소의 부모를 역방향으로 순회하여 타입명이 일치하는 조상을 반환합니다.
        /// maxDepth로 무한 루프를 방지합니다 (D-A 비판 수용).
        /// </summary>
        private static VisualElement FindAncestorByTypeName(
            VisualElement element, string typeName, int maxDepth)
        {
            var current = element?.hierarchy.parent;
            int depth = 0;
            while (current != null && depth < maxDepth)
            {
                if (current.GetType().Name == typeName) return current;
                current = current.hierarchy.parent;
                depth++;
            }
            return null;
        }

        // ─────────────────────────────────────────────────────────────────────
        // Reflection 헬퍼
        // ─────────────────────────────────────────────────────────────────────

        /// <summary>타입 상속 계층에서 지정된 이름의 메서드를 탐색합니다.</summary>
        private static MethodInfo FindMethodInHierarchy(
            Type type, string name, BindingFlags flags)
        {
            for (var t = type; t != null && t != typeof(object); t = t.BaseType)
            {
                var m = t.GetMethod(name, flags);
                if (m != null) return m;
            }
            return null;
        }

        /// <summary>타입 상속 계층에서 지정된 이름의 프로퍼티를 탐색합니다.</summary>
        private static PropertyInfo FindPropertyInHierarchy(
            Type type, string name, BindingFlags flags)
        {
            for (var t = type; t != null && t != typeof(object); t = t.BaseType)
            {
                var p = t.GetProperty(name, flags);
                if (p != null) return p;
            }
            return null;
        }

        // ─────────────────────────────────────────────────────────────────────
        // 닫힌 창 정리
        // ─────────────────────────────────────────────────────────────────────

        private static void CleanupClosedWindows()
        {
            s_ToRemove.Clear();
            foreach (var id in s_InjectedWindowIds)
                if (EditorUtility.InstanceIDToObject(id) == null)
                    s_ToRemove.Add(id);

            foreach (var id in s_ToRemove)
            {
                s_InjectedWindowIds.Remove(id);

                // NodeAnimator Dispose — 스케줄러·이벤트 구독 정리
                if (s_Animators.TryGetValue(id, out var animator))
                {
                    (animator as NodeAnimator)?.Dispose();
                    s_Animators.Remove(id);
                }

                // EdgeFlowOverlay Dispose — 스케줄러 중단 + 오버레이 제거
                if (s_Overlays.TryGetValue(id, out var overlay))
                {
                    (overlay as EdgeFlowOverlay)?.Dispose();
                    s_Overlays.Remove(id);
                }

                // GraphMinimapOverlay Dispose
                if (s_Minimaps.TryGetValue(id, out var minimap))
                {
                    (minimap as GraphMinimapOverlay)?.Dispose();
                    s_Minimaps.Remove(id);
                }
            }
        }

        // ─────────────────────────────────────────────────────────────────────
        // 진단 유틸리티 메뉴
        // ─────────────────────────────────────────────────────────────────────

        /// <summary>
        /// BehaviorGraphEditor의 전체 VisualElement 트리를 Console에 출력합니다.
        /// 블랙보드 관련 요소의 실제 이름과 타입을 확인하는 데 사용합니다.
        ///
        /// 실행 후 Console에서 ★ 표시된 줄에서 실제 Blackboard 요소명을 확인하여
        /// k_BlackboardPropertyNames / k_BlackboardTypeNames에 추가하세요.
        /// </summary>
        [MenuItem("Window/AI/TDA Behavior Tools/Diagnose Editor Structure")]
        private static void DiagnoseEditorStructure()
        {
            bool found = false;
            foreach (var win in Resources.FindObjectsOfTypeAll<EditorWindow>())
            {
                if (win?.rootVisualElement == null) continue;
                var bge = FindBehaviorGraphEditor(win.rootVisualElement);
                if (bge == null) continue;

                found = true;
                Debug.Log(
                    $"[BehaviorEnhancer] ===== VisualElement 트리 진단 =====\n" +
                    $"창: {win.GetType().Name} | BGE: {bge.GetType().Name}\n" +
                    $"(최대 {k_PrintTreeMaxDepth}레벨 출력, ★ = Blackboard 관련)");

                PrintTree(bge, 0);

                // BGE에서 탐색 가능한 Blackboard/Inspector 프로퍼티 목록 출력
                Debug.Log("[BehaviorEnhancer] --- BGE 타입 계층의 Blackboard/Inspector 프로퍼티 ---");
                ReportPropertyHierarchy(bge.GetType());

                Debug.Log(
                    "[BehaviorEnhancer] ===== 진단 완료 =====\n" +
                    "★ 표시 줄의 요소명(| 왼쪽)을 k_BlackboardPropertyNames에 추가하세요.\n" +
                    "없으면 k_BlackboardTypeNames에 타입명을 추가하세요.");
            }

            if (!found)
            {
                Debug.LogWarning(
                    "[BehaviorEnhancer] BehaviorGraphEditor 창을 찾을 수 없습니다.\n" +
                    "Behavior Graph 창을 열고 BG 에셋을 로드한 후 다시 실행하세요.");
            }
        }

        /// <summary>
        /// VisualElement 트리를 재귀적으로 Console에 출력합니다.
        /// Blackboard 관련 요소에는 ★를 붙여 강조합니다.
        /// 형식: [들여쓰기] 요소명 | 타입명 | CSS클래스 | children:N
        /// </summary>
        private static void PrintTree(VisualElement e, int depth)
        {
            if (depth > k_PrintTreeMaxDepth || e == null) return;

            var indent = new string(' ', depth * 2);
            var name = string.IsNullOrEmpty(e.name) ? "(noname)" : e.name;
            var typeName = e.GetType().Name;
            var classes = string.Join(",", e.GetClasses());

            bool isBlackboard = name.ToLower().Contains("blackboard") ||
                                typeName.ToLower().Contains("blackboard");
            bool isInspector = name.ToLower().Contains("inspector") ||
                                typeName.ToLower().Contains("inspector");
            bool isLeft = name.ToLower().Contains("left") ||
                                name.ToLower().Contains("panel") ||
                                name.ToLower().Contains("split");

            string prefix = isBlackboard ? "★BB " : isInspector ? "◆IN " : isLeft ? "◎ " : "";

            Debug.Log(
                $"{indent}{prefix}{name} | {typeName} | [{classes}] | children:{e.childCount}");

            foreach (var child in e.Children())
                PrintTree(child, depth + 1);
        }

        /// <summary>
        /// 타입 계층에서 Blackboard/Inspector 관련 프로퍼티 목록을 출력합니다.
        /// 실제 프로퍼티명 확인에 사용합니다.
        /// </summary>
        private static void ReportPropertyHierarchy(Type type)
        {
            for (var t = type; t != null && t != typeof(object); t = t.BaseType)
            {
                var props = t.GetProperties(k_BF);
                foreach (var p in props)
                {
                    if (p.Name.ToLower().Contains("blackboard") ||
                        p.Name.ToLower().Contains("inspector") ||
                        p.Name.ToLower().Contains("left") ||
                        p.Name.ToLower().Contains("panel"))
                    {
                        Debug.Log(
                            $"[프로퍼티] {t.Name}.{p.Name} : {p.PropertyType.Name}");
                    }
                }
            }
        }

        /// <summary>
        /// EditorPrefs에서 "Muse.Behavior" 관련 키를 탐색하여 Console에 출력합니다.
        /// 블랙보드가 여전히 표시되지 않을 때 실행하여 실제 키 이름을 확인하세요.
        /// </summary>
        [MenuItem("Window/AI/TDA Behavior Tools/Dump Blackboard Prefs")]
        private static void DumpBlackboardPrefs()
        {
            Debug.Log("[BehaviorEnhancer] === 블랙보드 관련 EditorPrefs 탐색 ===");
            foreach (var key in k_BlackboardPrefKeys)
            {
                if (EditorPrefs.HasKey(key))
                    Debug.Log($"[FOUND] {key} = {EditorPrefs.GetString(key, "(비문자열)")}");
                else
                    Debug.Log($"[없음]  {key}");
            }
            Debug.Log(
                "[BehaviorEnhancer] 위 목록에 없는 키가 블랙보드를 제어하는 경우\n" +
                "Windows: HKCU\\Software\\Unity Technologies\\Unity Editor 5.x\\");
        }

        /// <summary>
        /// 모든 추적 상태를 초기화하고 다음 Tick에서 재탐색하도록 합니다.
        /// USS나 컴포넌트가 올바르게 적용되지 않을 때 사용하세요.
        /// 실행 후 Console에서 [BehaviorEnhancer] ✓ USS 주입 완료 메시지를 확인하세요.
        /// </summary>
        [MenuItem("Window/AI/TDA Behavior Tools/Force Re-Initialize")]
        private static void ForceReInitialize()
        {
            foreach (var kv in s_Animators) (kv.Value as NodeAnimator)?.Dispose();
            foreach (var kv in s_Overlays) (kv.Value as EdgeFlowOverlay)?.Dispose();
            foreach (var kv in s_Minimaps) (kv.Value as GraphMinimapOverlay)?.Dispose();

            s_InjectedWindowIds.Clear();
            s_Animators.Clear();
            s_Overlays.Clear();
            s_Minimaps.Clear();
            s_LoadAttempts = 0;
            s_WarnedAboutMissingUss = false;

            Debug.Log(
                "[BehaviorEnhancer] 초기화 상태 리셋 완료.\n" +
                "다음 프레임에 재탐색합니다.\n" +
                "완료 시 '[BehaviorEnhancer] ✓ 초기화 완료.' 메시지가 출력됩니다.");
        }
    }
}
#endif