using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using Unity.Netcode;
using SG;
using System;
using TDA.Character.Player;

#if UNITY_EDITOR
using UnityEditor;
#endif

public class WorldSaveGameManager : MonoBehaviour
{
    public PlayerManager player;
    public static WorldSaveGameManager Instance { get; set; }

    [Header("Debug Scene Warp")]
    [HideInInspector] public int selectedSceneIndex;
    [HideInInspector] public string[] sceneNames;

    [Header("Save/Load")]
    [SerializeField] bool saveGame;
    [SerializeField] bool loadGame;

    [Header("World Scene Index")]
    [SerializeField] int worldSceneIndex = 1;

    [Header("Save Data Writer")]
    private SaveFileDataWriter saveFileDataWriter;

    [Header("World Save Data")]
    // 드롭된 아이템 재생성 아이템 프리펩 정보
    [SerializeField] private WorldItemDatabase itemDatabase;

    [Header("Current Character Data")]
    public CharacterSlots currentCharacterSlotBeingUsed;
    public CharacterSaveData currentCharacterData;
    private string saveFileName;

    [Header("Current World Data")]
    public WorldSlots currentWorldSlotBeingUsed;
    public WorldSaveData currentWorldData;

    [Header("Character Slots")]
    public CharacterSaveData characterSlots01;
    public CharacterSaveData characterSlots02;
    public CharacterSaveData characterSlots03;
    public CharacterSaveData characterSlots04;
    public CharacterSaveData characterSlots05;

    private void Awake()
    {
        // 해당 스크립트의 인스턴스는 하나만 존재할 수 잇으며, 다른게 존재시 파괴.
        if (Instance == null)
        {
            Instance = this;
        }
        else
        {
            Destroy(gameObject);
        }
        DontDestroyOnLoad(gameObject);
    }

    private void Start()
    {
        DontDestroyOnLoad(gameObject);
        LoadAllCharacterProfiles();

        // [추가된 부분 시작] 늦게 참여한 클라이언트(난입)의 씬 동기화 및 데이터 로드를 위한 이벤트 구독
        SceneManager.sceneLoaded += OnSceneLoaded;
        // [추가된 부분 끝]
    }

    private void Update()
    {
        if (saveGame)
        {
            saveGame = false;
            SaveGame();
        }

        if (loadGame)
        {
            loadGame = false;
            LoadGame();
        }
    }

    // [추가된 부분 시작] 씬 전환 시 클라이언트 데이터 처리 로직
    private void OnDestroy()
    {
        // 메모리 누수 방지
        SceneManager.sceneLoaded -= OnSceneLoaded;
    }

    // 이름 충돌 방지를 위해 명시적으로 UnityEngine.SceneManagement.Scene 사용
    private void OnSceneLoaded(UnityEngine.SceneManagement.Scene scene, LoadSceneMode mode)
    {
        // 방금 로드된 씬이 메인 메뉴가 아닌 월드(게임) 씬인지 확인
        if (IsWorldScene(scene.buildIndex))
        {
            // 내가 호스트가 아니라 클라이언트로 이미 시작된 게임에 난입하여 NGO에 의해 씬이 강제 동기화된 경우
            if (NetworkManager.Singleton != null && NetworkManager.Singleton.IsClient && !NetworkManager.Singleton.IsServer)
            {
                Debug.Log("[WorldSaveGameManager] 이미 시작된 게임에 접속했습니다. 씬 동기화 및 로컬 데이터 로드를 진행합니다.");

                // 스팀 초대 등으로 슬롯 선택 화면을 건너뛰고 바로 들어온 경우 기본 슬롯(1번) 강제 지정
                if (currentCharacterSlotBeingUsed == CharacterSlots.No_Slot)
                {
                    currentCharacterSlotBeingUsed = CharacterSlots.CharacterSlots_01;
                    Debug.Log("[WorldSaveGameManager] 캐릭터 슬롯이 미지정되어 기본 슬롯(1번) 데이터를 로드합니다.");
                }

                // 1. 클라이언트 본인의 로컬 PC에서 세이브 파일을 읽어옵니다.
                saveFileName = DecideCharacterFileNameBasedOnCharacterSlotBeingUsed(currentCharacterSlotBeingUsed);
                saveFileDataWriter = new SaveFileDataWriter();
                saveFileDataWriter.saveDataDirectoryPath = Application.persistentDataPath;
                saveFileDataWriter.saveFileName = saveFileName;

                currentCharacterData = saveFileDataWriter.LoadSaveFile();

                if (currentCharacterData == null)
                {
                    currentCharacterData = new CharacterSaveData(); // 새로하기의 경우
                }

                // 2. 내 플레이어 객체에 로컬 세이브 데이터를 주입하여 캐릭터 정보 복구
                if (player != null)
                {
                    player.LoadGameDataFromCurrentCharacterData(ref currentCharacterData);
                }
            }
        }
    }
    // [추가된 부분 끝]

    // --[저장/로드 I/O]--
    public void SaveWorld()
    {
        // 월드 데이터는 서버(호소트)만 관리하고 저장.
        if (!NetworkManager.Singleton.IsServer) return;

        // 1. 저장할 파일 이름 결정 ( 예 : world_save_01)
        string saveFileName = DecideWorldFileNameBasedOnSlot(currentWorldSlotBeingUsed);

        // 2. Writer 초기화
        saveFileDataWriter = new SaveFileDataWriter();
        saveFileDataWriter.saveDataDirectoryPath = Application.persistentDataPath;
        saveFileDataWriter.saveFileName = saveFileName;

        // 3. 현재 월드 데이터를 파일로 씀
        saveFileDataWriter.CreateWorldSaveFile(currentWorldData);
        Debug.Log("[WorldSave] 데이터 저장 완료");
    }

    public void LoadWorld()
    {
        // 월드 상태 로딩은 서버(호스트)만 수행.
        // 클라이언트는 서버가 스폰해주는 오브젝트(NetworkObject)를 동기화받기만함.
        // 클라이언트가 로컬 파일을 읽어 스폰 시도시 충돌발생.
        if (!NetworkManager.Singleton.IsServer) return;

        // 1. 불러올 파일 이름 결정
        string saveFileName = DecideWorldFileNameBasedOnSlot(currentWorldSlotBeingUsed);
        // 2. Writer 초기화 및 로드
        saveFileDataWriter = new SaveFileDataWriter();
        saveFileDataWriter.saveDataDirectoryPath = Application.persistentDataPath;
        saveFileDataWriter.saveFileName = saveFileName;

        WorldSaveData loadedData = saveFileDataWriter.LoadWorldSaveFile();

        // 3. 데이터 적용(파일이 있으면 덮어쓰고, 엎으면 새 데이터 유지
        if (loadedData != null)
        {
            currentWorldData = loadedData;
            Debug.Log($"[WorldSave] 월드 데이터 로드 됨:{saveFileName}");
        }
        else
        {
            Debug.Log($"[WorldSave]저장된 월드 데이터가 없어 새로 시작합니다");
            currentWorldData = new WorldSaveData(); // 초기화
        }
        Debug.Log("[WorldSave] 월드 데이터 로드 완료 (Server Only");

        // 로드 직후 런타임 오브젝트(드롭아이템) 복구 실행
        SpawnDroppedItems();
    }

    public string DecideCharacterFileNameBasedOnCharacterSlotBeingUsed(CharacterSlots characterSlots)
    {
        string fileName = "";
        switch (characterSlots)
        {
            case CharacterSlots.CharacterSlots_01:
                fileName = "characterSlots_01";
                break;
            case CharacterSlots.CharacterSlots_02:
                fileName = "characterSlots_02";
                break;
            case CharacterSlots.CharacterSlots_03:
                fileName = "characterSlots_03";
                break;
            case CharacterSlots.CharacterSlots_04:
                fileName = "characterSlots_04";
                break;
            case CharacterSlots.CharacterSlots_05:
                fileName = "characterSlots_05";
                break;
            default:
                break;
        }

        return fileName;
    }

    // 슬롯 번호에 따른 월드 파일 이름 결정 규칙
    public string DecideWorldFileNameBasedOnSlot(WorldSlots worldSlot)
    {
        string fileName = "";
        switch (worldSlot)
        {
            case WorldSlots.WorldSlots_01:
                fileName = "worldSlots_01";
                break;
            default:
                break;
        }
        return fileName;
    }

    public void AttemptToCreateNewGame()
    {
        saveFileDataWriter = new SaveFileDataWriter();
        saveFileDataWriter.saveDataDirectoryPath = Application.persistentDataPath;

        // 새 파일을 만듬, 어떤 슬롯을 사용하는 지에 따라 파일 이름이 달림
        // Check to see if file exist first before create new file.
        saveFileDataWriter.saveFileName = DecideCharacterFileNameBasedOnCharacterSlotBeingUsed(CharacterSlots.CharacterSlots_01);

        if (!saveFileDataWriter.CheckToSeeIfFileExists())
        {
            // If this profile slot is not taken, make new one using this slot.
            currentCharacterSlotBeingUsed = CharacterSlots.CharacterSlots_01;
            currentCharacterData = new CharacterSaveData();
            NewGame();
            return;
        }

        saveFileDataWriter.saveFileName = DecideCharacterFileNameBasedOnCharacterSlotBeingUsed(CharacterSlots.CharacterSlots_02);

        if (!saveFileDataWriter.CheckToSeeIfFileExists())
        {
            // If this profile slot is not taken, make new one using this slot.
            currentCharacterSlotBeingUsed = CharacterSlots.CharacterSlots_02;
            currentCharacterData = new CharacterSaveData();
            NewGame();
            return;
        }

        // ?먯쑀 ?щ'???놁쓣?? ?뚮젅?댁뼱???명떚?뚯씠
        TitleScreenManager.Instance.DisplayNofreeCharacterSlotPopUp();

    }

    private void NewGame()
    {
        // 새게임 시작시 캐릭터 스탯과, 아이템을 저장함(캐릭터크링에이션씬 추가시)
        player.playerNetworkManager.vitality.Value = 15;
        player.playerNetworkManager.endurance.Value = 10;

        SaveGame();
        StartCoroutine(LoadWorldScene());
    }

    public void LoadGame()
    {
        // 이전 파일을 부름, 어떤 슬롯을 사용하는 지에 따라 파일 이름이 갈림.
        saveFileName = DecideCharacterFileNameBasedOnCharacterSlotBeingUsed(currentCharacterSlotBeingUsed);

        saveFileDataWriter = new SaveFileDataWriter();
        // 일반적으로 다양한 기계 타입에 작동됨(Application.persistentDataPath)
        saveFileDataWriter.saveDataDirectoryPath = Application.persistentDataPath;
        saveFileDataWriter.saveFileName = saveFileName;
        currentCharacterData = saveFileDataWriter.LoadSaveFile();

        StartCoroutine(LoadWorldScene());
    }

    public void SaveGame()
    {
        // 현재 파일을 저장함, 어떤 슬롯을 이용하고 있는지 파일 이름에 따라.
        saveFileName = DecideCharacterFileNameBasedOnCharacterSlotBeingUsed(currentCharacterSlotBeingUsed);

        saveFileDataWriter = new SaveFileDataWriter();
        saveFileDataWriter.saveDataDirectoryPath = Application.persistentDataPath;
        saveFileDataWriter.saveFileName = saveFileName;

        // 플레이어 인포를 넘겨주고, 세이브파일화함
        player.SaveGameDataToCurrentCharacterData(ref currentCharacterData);

        // saveFileDataWriter에 createCharacterSaveFile 을 불러오고, currentCharacterData을 넘김
        saveFileDataWriter.CreateCharacterSaveFile(currentCharacterData);
    }

    public void DeleteGame(CharacterSlots characterSlots)
    {
        // 선택한 파일을 삭제, 어떤 슬롯을 사용하는 지에 따라 파일 이름이 갈림.

        saveFileDataWriter = new SaveFileDataWriter();
        // 일반적으로 다양한 기계 타입에 작동됨(Application.persistentDataPath)
        saveFileDataWriter.saveDataDirectoryPath = Application.persistentDataPath;
        saveFileDataWriter.saveFileName = DecideCharacterFileNameBasedOnCharacterSlotBeingUsed(characterSlots);
        saveFileDataWriter.DeleteSaveFile();
        //currentCharacterData = saveFileDataWriter.LoadSaveFile();
    }

    // 게임을 시작하면 기계에 있는 모든 캐릭터 프로필을 불러오기
    private void LoadAllCharacterProfiles()
    {
        saveFileDataWriter = new SaveFileDataWriter();
        saveFileDataWriter.saveDataDirectoryPath = Application.persistentDataPath;

        saveFileDataWriter.saveFileName =
            DecideCharacterFileNameBasedOnCharacterSlotBeingUsed(CharacterSlots.CharacterSlots_01);
        characterSlots01 = saveFileDataWriter.LoadSaveFile();

        saveFileDataWriter.saveFileName =
            DecideCharacterFileNameBasedOnCharacterSlotBeingUsed(CharacterSlots.CharacterSlots_02);
        characterSlots02 = saveFileDataWriter.LoadSaveFile();

        saveFileDataWriter.saveFileName =
            DecideCharacterFileNameBasedOnCharacterSlotBeingUsed(CharacterSlots.CharacterSlots_03);
        characterSlots03 = saveFileDataWriter.LoadSaveFile();

        saveFileDataWriter.saveFileName =
            DecideCharacterFileNameBasedOnCharacterSlotBeingUsed(CharacterSlots.CharacterSlots_04);
        characterSlots04 = saveFileDataWriter.LoadSaveFile();

        saveFileDataWriter.saveFileName =
            DecideCharacterFileNameBasedOnCharacterSlotBeingUsed(CharacterSlots.CharacterSlots_05);
        characterSlots05 = saveFileDataWriter.LoadSaveFile();
    }

    // --[슬롯 조회 유틸리티]--

    /// <summary>
    /// 특정 슬롯의 캐시된 CharacterSaveData를 반환합니다.
    /// TitleScreenManager에서 슬롯 선택 시 currentCharacterData를 세팅하는 용도로 사용합니다.
    /// 해당 슬롯에 파일이 없으면 null을 반환합니다.
    /// </summary>
    public CharacterSaveData GetCharacterDataForSlot(CharacterSlots slot)
    {
        switch (slot)
        {
            case CharacterSlots.CharacterSlots_01: return characterSlots01;
            case CharacterSlots.CharacterSlots_02: return characterSlots02;
            case CharacterSlots.CharacterSlots_03: return characterSlots03;
            case CharacterSlots.CharacterSlots_04: return characterSlots04;
            case CharacterSlots.CharacterSlots_05: return characterSlots05;
            default:
                Debug.LogWarning($"[WorldSaveGameManager][GetCharacterDataForSlot] 알 수 없는 슬롯: {slot}");
                return null;
        }
    }

    // --[런타임 로직]--

    // 1. 제거 등록 (루팅)
    public void AddRemovedObject(int id)
    {
        if (!currentWorldData.removedInteractableIDs.Contains(id))
            currentWorldData.removedInteractableIDs.Add(id);
    }

    // 2. 상태/위치 업데이트 (문 열기, 상자 밀기)
    public void UpdateObjectState(int id, bool state, Vector3? pos = null, Quaternion? rot = null)
    {
        WorldObjectState data = new WorldObjectState
        {
            interactableID = id,
            boolValue = state,
            savePosition = pos.HasValue, // 위치값 전달되었으면 true
            position = pos ?? Vector3.zero,
            rotation = rot ?? Quaternion.identity,
        };

        if (currentWorldData.objectStates.ContainsKey(id))
            currentWorldData.objectStates[id] = data;
        else
            currentWorldData.objectStates.Add(id, data);
    }

    // 3. 드롭 아이템 등록
    public void AddDroppedItem(int itemID, int amount, Vector3 pos, Quaternion rot)
    {
        WorldItemSaveData data = new WorldItemSaveData
        {
            itemID = itemID,
            amount = amount,
            position = pos,
            rotation = rot
        };
        currentWorldData.droppedItems.Add(data);
    }

    // 4. 드롭 아이템 복구 (스폰)
    private void SpawnDroppedItems()
    {
        // 이 함수는 서버에서만 호출(IsServer)
        // late joiner 는 NetworkObject.Spawn되면 알아서 관리.
        foreach (var itemData in currentWorldData.droppedItems)
        {
            var prefab = WorldItemDatabase.Instance.GetItemPrefab(itemData.itemID);
            if (prefab != null)
            {
                // 1. 서버에서 아이템 인스턴스화 (위치/회전값 적용)
                GameObject obj = Instantiate(prefab, itemData.position, itemData.rotation);
                var netObj = obj.GetComponent<NetworkObject>();

                if (netObj != null)
                {
                    // 2. 네트워크 스폰 실행
                    // late joiner 처리 원리
                    // networkObject.Spawn()이 호출되면 netcode 시스템이 이 오브젝트 관리 시작.
                    // 나중에 클라 접속, 서버는 자동으로 현재 존재하는 모든 networkObject 정보를
                    // 그 클라이언트에 전송(Replication). 따라 별도 동기화 코드 없이도
                    // 나중에 들어온 유저는 해당 아이템이 해당 위치에 있는 것 확인 가능
                    // (단, 프리팹에 NetworkTransform이 있어야 위치 동기화가 정확)
                    netObj.Spawn();
                }
            }
        }
    }

    // 유틸리티 : 상태 조회
    public bool TryGetObjectState(int id, out WorldObjectState state)
    {
        return currentWorldData.objectStates.TryGetValue(id, out state);
    }

    // 코루틴 역할을 하는 IEnumerator을 사용.
    public IEnumerator LoadWorldScene()
    {
        // [수정된 부분 시작] 멀티플레이어 환경에서 클라이언트들의 씬이 함께 동기화되도록 분기 처리 추가
        if (NetworkManager.Singleton != null && NetworkManager.Singleton.IsListening && NetworkManager.Singleton.IsServer)
        {
            // 호스트(서버)인 경우 NGO 전용 씬 매니저를 사용해 씬을 로드합니다. (클라이언트 자동 동기화)
            // 빌드 인덱스를 바탕으로 씬의 실제 이름을 추출하여 넘겨줍니다.
            string sceneName = System.IO.Path.GetFileNameWithoutExtension(SceneUtility.GetScenePathByBuildIndex(worldSceneIndex));
            NetworkManager.Singleton.SceneManager.LoadScene(sceneName, LoadSceneMode.Single);
        }
        else
        {
            // 싱글플레이 환경일 경우 기존 유니티 기본 씬 로더를 사용합니다.
            // 씬 하나일 경우 아래 코드
            AsyncOperation loadOperation = SceneManager.LoadSceneAsync(worldSceneIndex);

            // 씬 여럿일 경우 아래코드
            // AsyncOperation loadOperation = SceneManager.LoadSceneAsync(currentCharacterData.sceneIndex);
        }
        // [수정된 부분 끝]

        player.LoadGameDataFromCurrentCharacterData(ref currentCharacterData);

        yield return null;
    }

    public int GetWorldSceneIndex()
    {
        return worldSceneIndex;
    }

    /// <summary>
    /// 특정 인덱스가 플레이 가능한 월드씬인지 판별.
    /// </summary>
    public bool IsWorldScene(int buildIndex)
    {
        // 기본 월드 씬이거나, 디버그용으로 등록된 다른 월드씬 인덱스 들을 체크
        // 필요시 List<int> worldScenes 형태로 관리 가능
        return buildIndex == worldSceneIndex || buildIndex > 0;
        // 보통 0번은 메인메뉴, 0보다 크면 월드로 간주하는 로직.
    }

    // NGO 2.0에서는 서버(호스트)가 씬 전환을 주도해야 모든 클라이언트가 동기화됩니다.
    public void DebugWarpToSelectedScene()
    {
        if (sceneNames == null || sceneNames.Length == 0) return;

        string targetSceneName = sceneNames[selectedSceneIndex];
        int targetIndex = -1;

        // 씬 이름을 통해 빌드 인덱스 찾기
        for (int i = 0; i < SceneManager.sceneCountInBuildSettings; i++)
        {
            string path = SceneUtility.GetScenePathByBuildIndex(i);
            if (path.Contains(targetSceneName))
            {
                targetIndex = i;
                break;
            }
        }

        if (targetIndex == -1) return;

        // NGO 2.0 네트워크 씬 로딩
        if (NetworkManager.Singleton != null && (NetworkManager.Singleton.IsServer || NetworkManager.Singleton.IsHost))
        {
            Debug.Log($"[Debug Warp] {targetSceneName} (Index: {targetIndex})으로 모든 클라이언트 이동");
            NetworkManager.Singleton.SceneManager.LoadScene(targetSceneName, LoadSceneMode.Single);
        }
        else
        {
            Debug.Log($"[Debug Warp] 오프라인 상태로 {targetSceneName} 이동");
            SceneManager.LoadScene(targetIndex);
        }
    }

    // --[로비 전용 슬롯 준비 로직]--

    /// <summary>
    /// 로비에서 슬롯 선택 없이 방을 만들 때 호출.
    /// 이미 슬롯이 선택되어 있으면 그대로 통과하고,
    /// 슬롯이 없으면 빈 슬롯을 자동으로 찾아 새 캐릭터 데이터를 생성하고 저장합니다.
    /// 슬롯을 성공적으로 준비했으면 true, 빈 슬롯이 없으면 false를 반환합니다.
    ///
    /// ※ 주의: 로비 씬에서는 PlayerManager(player)가 아직 존재하지 않습니다.
    ///   따라서 SaveGame()을 직접 호출하면 player.SaveGameDataToCurrentCharacterData()에서
    ///   NullReferenceException이 발생해 함수 전체가 조용히 실패합니다.
    ///   이 메서드는 player를 전혀 사용하지 않고 SaveFileDataWriter로 파일을 직접 기록합니다.
    /// </summary>
    public bool PrepareOrCreateSlotForLobby()
    {
        Debug.Log($"[WorldSaveGameManager][PrepareOrCreateSlotForLobby] ▶ 호출됨. " +
                  $"현재 슬롯={currentCharacterSlotBeingUsed}, " +
                  $"currentCharacterData={(currentCharacterData == null ? "NULL" : "존재함")}, " +
                  $"player={(player == null ? "NULL (정상 - 로비에는 없음)" : "존재함")}");

        // 이미 슬롯이 선택되어 있고 데이터도 있으면 그냥 통과
        if (currentCharacterSlotBeingUsed != CharacterSlots.No_Slot
            && currentCharacterData != null)
        {
            Debug.Log("[WorldSaveGameManager][PrepareOrCreateSlotForLobby] ✔ 이미 유효한 슬롯이 선택되어 있습니다. 통과합니다.");
            return true;
        }

        Debug.Log("[WorldSaveGameManager][PrepareOrCreateSlotForLobby] 슬롯 미지정 또는 데이터 없음. 빈 슬롯 탐색 시작...");
        Debug.Log($"[WorldSaveGameManager][PrepareOrCreateSlotForLobby] 저장 경로: \"{Application.persistentDataPath}\"");

        SaveFileDataWriter lobbyWriter = new SaveFileDataWriter();
        lobbyWriter.saveDataDirectoryPath = Application.persistentDataPath;

        // 슬롯 01~05 순서로 빈 슬롯 탐색
        CharacterSlots[] allSlots = {
            CharacterSlots.CharacterSlots_01,
            CharacterSlots.CharacterSlots_02,
            CharacterSlots.CharacterSlots_03,
            CharacterSlots.CharacterSlots_04,
            CharacterSlots.CharacterSlots_05
        };

        foreach (var slot in allSlots)
        {
            lobbyWriter.saveFileName = DecideCharacterFileNameBasedOnCharacterSlotBeingUsed(slot);
            bool fileExists = lobbyWriter.CheckToSeeIfFileExists();
            Debug.Log($"[WorldSaveGameManager][PrepareOrCreateSlotForLobby] 슬롯 {slot} → 파일명=\"{lobbyWriter.saveFileName}\", 파일 존재={fileExists}");

            if (!fileExists)
            {
                Debug.Log($"[WorldSaveGameManager][PrepareOrCreateSlotForLobby] ✔ 빈 슬롯 발견: {slot}. 새 캐릭터 데이터 생성 시작...");

                // 빈 슬롯 발견 → 새 CharacterSaveData 생성
                currentCharacterSlotBeingUsed = slot;
                currentCharacterData = new CharacterSaveData();

                // 기본 스탯을 데이터 오브젝트에 직접 기록합니다.
                // 로비 씬에서는 player가 null이므로 player를 통하지 않고
                // currentCharacterData 필드를 직접 설정한 뒤 파일로 씁니다.
                // (실제 플레이어 NetworkVariable에 반영은 월드 씬 로드 후
                //  LoadGameDataFromCurrentCharacterData()가 담당합니다.)
                currentCharacterData.vitality = 15;
                currentCharacterData.endurance = 10;

                Debug.Log($"[WorldSaveGameManager][PrepareOrCreateSlotForLobby] 기본 스탯 설정 완료. " +
                          $"vitality={currentCharacterData.vitality}, endurance={currentCharacterData.endurance}");

                // SaveGame() 대신 Writer로 직접 파일 저장
                // → SaveGame()은 내부에서 player.SaveGameDataToCurrentCharacterData()를 호출하므로
                //   player가 없는 로비 환경에서 사용하면 NullReferenceException이 발생합니다.
                try
                {
                    lobbyWriter.CreateCharacterSaveFile(currentCharacterData);
                    Debug.Log($"[WorldSaveGameManager][PrepareOrCreateSlotForLobby] ✔ 파일 저장 성공: \"{lobbyWriter.saveFileName}\"");
                }
                catch (Exception e)
                {
                    Debug.LogError($"[WorldSaveGameManager][PrepareOrCreateSlotForLobby] ✖ 파일 저장 중 예외 발생 → {e.GetType().Name}: {e.Message}\n{e.StackTrace}");
                    return false;
                }

                // 로비 슬롯 목록 캐시도 갱신해 UI에 반영될 수 있도록 합니다.
                switch (slot)
                {
                    case CharacterSlots.CharacterSlots_01: characterSlots01 = currentCharacterData; break;
                    case CharacterSlots.CharacterSlots_02: characterSlots02 = currentCharacterData; break;
                    case CharacterSlots.CharacterSlots_03: characterSlots03 = currentCharacterData; break;
                    case CharacterSlots.CharacterSlots_04: characterSlots04 = currentCharacterData; break;
                    case CharacterSlots.CharacterSlots_05: characterSlots05 = currentCharacterData; break;
                }

                Debug.Log($"[WorldSaveGameManager][PrepareOrCreateSlotForLobby] ✔ 슬롯 캐시 갱신 완료. 최종 결과: 슬롯={slot}, 데이터 준비 완료. true 반환.");
                return true;
            }
        }

        // 모든 슬롯이 꽉 찬 경우
        Debug.LogWarning("[WorldSaveGameManager][PrepareOrCreateSlotForLobby] ✖ 슬롯 01~05 모두 파일이 존재합니다. 사용 가능한 빈 슬롯이 없습니다! false 반환.");
        return false;
    }
}

#region Editor Customization
#if UNITY_EDITOR
[CustomEditor(typeof(WorldSaveGameManager))]
public class WorldSaveGameManagerEditor : Editor
{
    public override void OnInspectorGUI()
    {
        base.OnInspectorGUI();

        WorldSaveGameManager manager = (WorldSaveGameManager)target;

        EditorGUILayout.Space(20);
        EditorGUILayout.LabelField("DEBUG SCENE LOADER", EditorStyles.boldLabel);

        // 빌드 설정의 모든 씬 가져오기
        manager.sceneNames = GetBuildSceneNames();

        if (manager.sceneNames != null && manager.sceneNames.Length > 0)
        {
            // 현재 활성화된 씬 표시
            string currentScene = SceneManager.GetActiveScene().name;
            EditorGUILayout.HelpBox($"Current Scene: {currentScene}", MessageType.Info);

            // 드롭다운 메뉴
            manager.selectedSceneIndex = EditorGUILayout.Popup("Target Scene", manager.selectedSceneIndex, manager.sceneNames);

            // 워프 버튼
            GUI.color = Color.green;
            if (GUILayout.Button("Warp to Selected Scene"))
            {
                if (EditorApplication.isPlaying)
                {
                    manager.DebugWarpToSelectedScene();
                }
                else
                {
                    Debug.LogWarning("게임이 실행 중일 때만 워프가 가능합니다.");
                }
            }
            GUI.color = Color.white;
        }
        else
        {
            EditorGUILayout.HelpBox("Build Settings에 활성화된 씬이 없습니다.", MessageType.Error);
        }
    }

    private string[] GetBuildSceneNames()
    {
        List<string> tempScenes = new List<string>();
        foreach (EditorBuildSettingsScene scene in EditorBuildSettings.scenes)
        {
            if (scene.enabled)
            {
                string name = System.IO.Path.GetFileNameWithoutExtension(scene.path);
                tempScenes.Add(name);
            }
        }
        return tempScenes.ToArray();
    }
}
#endif
#endregion